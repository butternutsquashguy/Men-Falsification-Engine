
from __future__ import annotations
import numpy as np
from typing import Mapping, Iterable, Any
from dataclasses import dataclass

@dataclass(frozen=True)
class JobSpec:
    params: Mapping[str, Any]
    meta: Mapping[str, Any] | None = None

@dataclass(frozen=True)
class Result:
    metrics: Mapping[str, float]
    info: Mapping[str, Any] | None = None

class PluginImpl:
    name = "random_matrix"

    def enumerate_jobs(self, priors: Mapping[str, Any]) -> Iterable[JobSpec]:
        g = (priors or {}).get("grid", {})
        N_list = g.get("N", [256, 512])
        dist_list = g.get("dist", ["wigner"])
        seed_list = g.get("seed", [21])
        for N in N_list:
            for dist in dist_list:
                for seed in seed_list:
                    yield JobSpec(params={"N": int(N), "dist": str(dist), "seed": int(seed)})

    def evaluate(self, job: JobSpec, resources: Mapping[str, Any] | None = None) -> Result:
        N = int(job.params.get("N", 256))
        dist = str(job.params.get("dist", "wigner"))
        seed = int(job.params.get("seed", 21))
        rng = np.random.default_rng(seed)

        if dist == "wigner":
            M = rng.normal(0, 1/np.sqrt(N), size=(N, N))
            M = (M + M.T) / 2.0
        else:
            M = rng.normal(size=(N, N))
            M = (M + M.T)/2.0

        eigs = np.linalg.eigvalsh(M)
        mu, sigma = float(np.mean(eigs)), float(np.std(eigs))
        outliers = int(np.sum(np.abs(eigs - mu) > 3*sigma))
        edge = float(np.max(eigs))
        tw_proxy = float((edge - mu) / (sigma + 1e-12))

        return Result(
            metrics={"eig_mean": mu, "eig_std": sigma, "edge_score": tw_proxy, "outlier_count": float(outliers)},
            info={"N": N, "dist": dist, "seed": seed}
        )

plugin = PluginImpl()
