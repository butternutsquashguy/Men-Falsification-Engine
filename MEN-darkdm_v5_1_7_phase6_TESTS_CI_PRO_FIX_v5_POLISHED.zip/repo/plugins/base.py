from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Mapping, Protocol, Any, Optional
import importlib
import inspect

@dataclass(frozen=True)
class JobSpec:
    params: Mapping[str, Any]
    meta: Mapping[str, Any] = None

@dataclass(frozen=True)
class Result:
    metrics: Mapping[str, float]
    info: Mapping[str, Any] = None

class Plugin(Protocol):
    name: str
    def enumerate_jobs(self, priors: Mapping[str, Any]) -> Iterable[JobSpec]: ...
    def evaluate(self, job: JobSpec, resources: Optional[Mapping[str, Any]] = None) -> Result: ...

def load_plugin(dotted: str):
    if ":" in dotted:
        mod_name, obj_name = dotted.split(":", 1)
        mod = importlib.import_module(mod_name)
        obj = getattr(mod, obj_name)
    else:
        mod = importlib.import_module(dotted)
        obj = getattr(mod, "plugin", None) or getattr(mod, "PluginImpl", None)
    if obj is None:
        raise ImportError(f"Could not resolve plugin object from {dotted}")
    plugin = obj if not inspect.isclass(obj) else obj()
    for attr in ("enumerate_jobs", "evaluate"):
        if not hasattr(plugin, attr) or not callable(getattr(plugin, attr)):
            raise TypeError(f"Plugin {dotted} missing required method: {attr}")
    if not hasattr(plugin, "name"):
        plugin.name = dotted.rsplit(".", 1)[-1]
    return plugin