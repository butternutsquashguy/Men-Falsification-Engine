def enumerate_jobs(priors, mode="preferred"):
    pd=(priors.get("modules",{}).get("dark_baryon_bh",{}) or {}).get("params",{})
    def grid(k, default):
        v=pd.get(k,{}); 
        if mode=="preferred" and isinstance(v.get("preferred"),(list,tuple)): return list(v["preferred"])
        if "min" in v and "max" in v:
            mid=0.5*(v["min"]+v["max"]); return [v["min"], mid, v["max"]]
        if "preferred" in v:
            vv=v["preferred"]; return vv if isinstance(vv,(list,tuple)) else [vv]
        return default
    return [{
        "name":"dbbh_from_priors","module":"dbbh",
        "params":{"N":grid("N",[12,20,30]),"Lambda_conf":grid("Lambda_conf_GeV",[3.0,5.0]),
                  "mq":grid("mq_GeV",[0.5,1.0]),"T_dark":grid("T_dark_GeV",[0.3,0.8]),
                  "kappa":grid("rmt_tail_kappa",[3.0,3.5]),"seed":[123,456]}}]
def evaluate(params, seed):
    N=float(params.get("N",20)); kap=float(params.get("kappa",3.2)); Lam=float(params.get("Lambda_conf",3.0))
    collapse_prob=max(0.0, min(1.0, 0.01*N + 0.1/(kap+1e-6)))
    omega=0.02*N*(Lam**0.25)/(1.0+0.5*(kap-3.0))
    return {"Omega_dbbh": omega, "collapse_prob": collapse_prob}

# === Adapter tail for MEN Plugin Interface (dbbh) =============================
from typing import Any, Mapping
from dataclasses import dataclass
try:
    from plugins.base import JobSpec, Result  # type: ignore
except Exception:
    @dataclass(frozen=True)
    class JobSpec:
        params: Mapping[str, Any]
        meta: Mapping[str, Any] | None = None
    @dataclass(frozen=True)
    class Result:
        metrics: Mapping[str, float]
        info: Mapping[str, Any] | None = None
_g = globals()
_ENUM_CANDIDATES = ("enumerate_jobs","generate_jobs","make_jobs","job_grid","expand_priors")
_EVAL_CANDIDATES = ("evaluate","evaluate_job","run_job","process_job","run")
def _resolve_symbol(candidates):
    for name in candidates:
        fn = _g.get(name)
        if callable(fn):
            return fn
    return None
_ENUM_FN = _resolve_symbol(_ENUM_CANDIDATES)
_EVAL_FN = _resolve_symbol(_EVAL_CANDIDATES)
if _ENUM_FN is None:
    raise ImportError("[plugins.dbbh] Could not find a job enumerator.")
if _EVAL_FN is None:
    raise ImportError("[plugins.dbbh] Could not find an evaluator.")
def _coerce_to_jobspec(obj: Any) -> JobSpec:
    if isinstance(obj, JobSpec): return obj
    if isinstance(obj, dict):
        params = obj.get("params", obj); meta = obj.get("meta", None)
        return JobSpec(params=params, meta=meta)
    if isinstance(obj, (tuple, list)) and len(obj)==2 and isinstance(obj[1], dict):
        return JobSpec(params=obj[1], meta={{"tag": obj[0]}})
    return JobSpec(params={{"job": obj}})
def _coerce_to_result(obj: Any) -> Result:
    if isinstance(obj, Result): return obj
    if isinstance(obj, dict):
        metrics = obj.get("metrics", {})
        info = obj.get("info", {{k:v for k,v in obj.items() if k!='metrics'}})
        if metrics == {} and all(isinstance(v,(int,float)) for v in obj.values()):
            metrics = obj; info = {}
        return Result(metrics=metrics, info=info)
    return Result(metrics={}, info={{"raw": obj}})
class PluginImpl:
    name = "dbbh"
    def enumerate_jobs(self, priors: Mapping[str, Any]):
        jobs = _ENUM_FN(priors)
        for j in jobs:
            yield _coerce_to_jobspec(j)
    def evaluate(self, job: JobSpec, resources: Mapping[str, Any] | None = None) -> Result:
        try:
            out = _EVAL_FN(job.params, resources=resources)
        except TypeError:
            out = _EVAL_FN(job.params)
        return _coerce_to_result(out)
plugin = PluginImpl()
# ============================================================================
