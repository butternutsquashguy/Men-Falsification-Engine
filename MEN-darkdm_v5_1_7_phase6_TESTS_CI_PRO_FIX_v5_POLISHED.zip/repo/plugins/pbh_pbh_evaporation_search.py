
"""Plugin wrapper to expose PBH module to suite/orchestrator discovery."""
from research_pipeline.modules import pbh_evaporation_search as _mod

MODULE_NAME = "pbh_evaporation_search"

def list_modules():
    return [MODULE_NAME]

def run_module(config: dict, outdir: str) -> str:
    cfg = dict(config or {})
    cfg.setdefault("module_name", MODULE_NAME)
    return _mod.run(cfg, outdir)
