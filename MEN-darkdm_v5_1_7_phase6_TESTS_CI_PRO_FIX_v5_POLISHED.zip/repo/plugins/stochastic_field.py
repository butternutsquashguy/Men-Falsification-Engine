
from __future__ import annotations
import numpy as np
from typing import Mapping, Iterable, Any
from dataclasses import dataclass

@dataclass(frozen=True)
class JobSpec:
    params: Mapping[str, Any]
    meta: Mapping[str, Any] | None = None

@dataclass(frozen=True)
class Result:
    metrics: Mapping[str, float]
    info: Mapping[str, Any] | None = None

class PluginImpl:
    name = "stochastic_field"

    def enumerate_jobs(self, priors: Mapping[str, Any]) -> Iterable[JobSpec]:
        grid = (priors or {}).get("grid", {})
        N_list   = grid.get("N", [1000])
        seed_list= grid.get("seed", [42])
        corr_rho = grid.get("corr_rho", [0.0])  # amplitude-frequency correlation
        for N in N_list:
            for seed in seed_list:
                for rho in corr_rho:
                    yield JobSpec(params={"N": int(N), "seed": int(seed), "corr_rho": float(rho)})

    def evaluate(self, job: JobSpec, resources: Mapping[str, Any] | None = None) -> Result:
        N     = int(job.params.get("N", 1000))
        seed  = int(job.params.get("seed", 42))
        rho   = float(job.params.get("corr_rho", 0.0))

        rng = np.random.default_rng(seed)
        # Correlated amplitude & frequency via Gaussian copula (toy)
        u = rng.standard_normal((N,2))
        cov = np.array([[1.0, rho],[rho,1.0]])
        L = np.linalg.cholesky(cov)
        z = u @ L.T
        amp = z[:,0]
        freq = 1.0 + 9.0 * (z[:,1] - z[:,1].min()) / (z[:,1].ptp() + 1e-9)
        phase = rng.uniform(0, 2*np.pi, N)
        xi = amp * np.sin(freq + phase)

        m2 = float(np.mean(xi**2))
        m3 = float(np.mean(xi**3))
        m4 = float(np.mean(xi**4))
        eps = 1e-12
        skew = m3 / ((m2 + eps) ** 1.5)
        kurt = m4 / ((m2 + eps) ** 2) - 3.0

        return Result(
            metrics={"var": m2, "skew": skew, "kurt_excess": kurt},
            info={"N": N, "seed": seed, "corr_rho": rho}
        )

plugin = PluginImpl()
