
from __future__ import annotations
import numpy as np
from typing import Mapping, Iterable, Any
from dataclasses import dataclass

@dataclass(frozen=True)
class JobSpec:
    params: Mapping[str, Any]
    meta: Mapping[str, Any] | None = None

@dataclass(frozen=True)
class Result:
    metrics: Mapping[str, float]
    info: Mapping[str, Any] | None = None

def svd_compress(X, k):
    U, S, Vt = np.linalg.svd(X, full_matrices=False)
    k = max(1, min(k, len(S)))
    S_k = np.zeros_like(S); S_k[:k] = S[:k]
    Xk = (U * S_k) @ Vt
    var_ratio = float(np.sum(S[:k]**2) / (np.sum(S**2) + 1e-12))
    return Xk, var_ratio

class PluginImpl:
    name = "info_bottleneck"

    def enumerate_jobs(self, priors: Mapping[str, Any]) -> Iterable[JobSpec]:
        g = (priors or {}).get("grid", {})
        layers_list = g.get("layers", [3])
        width_list  = g.get("width", [64])
        samples_list= g.get("samples", [300])
        seed_list   = g.get("seed", [99])
        for L in layers_list:
            for W in width_list:
                for S in samples_list:
                    for seed in seed_list:
                        yield JobSpec(params={"layers": int(L), "width": int(W), "samples": int(S), "seed": int(seed)})

    def evaluate(self, job: JobSpec, resources: Mapping[str, Any] | None = None) -> Result:
        L = int(job.params.get("layers", 3))
        W = int(job.params.get("width", 64))
        S = int(job.params.get("samples", 300))
        seed = int(job.params.get("seed", 99))
        rng = np.random.default_rng(seed)
        X = rng.normal(size=(S, W))

        k = W
        ratios = []
        for _ in range(L):
            k = max(2, k // 2)
            X, r = svd_compress(X, k=k)
            ratios.append(r)
        diffs = np.diff(ratios)
        sharp_drop = float(np.min(diffs)) if len(diffs) else 0.0

        return Result(
            metrics={"var_ratio_L1": float(ratios[0]) if ratios else 0.0,
                     "var_ratio_Lend": float(ratios[-1]) if ratios else 0.0,
                     "min_delta": sharp_drop},
            info={"layers": L, "width": W, "samples": S, "seed": seed}
        )

plugin = PluginImpl()
