
from __future__ import annotations
import numpy as np
from typing import Mapping, Iterable, Any
from dataclasses import dataclass

@dataclass(frozen=True)
class JobSpec:
    params: Mapping[str, Any]
    meta: Mapping[str, Any] | None = None

@dataclass(frozen=True)
class Result:
    metrics: Mapping[str, float]
    info: Mapping[str, Any] | None = None

class PluginImpl:
    name = "tensor_network"

    def enumerate_jobs(self, priors: Mapping[str, Any]) -> Iterable[JobSpec]:
        g = (priors or {}).get("grid", {})
        D_list = g.get("bond_dim", [4, 8])
        N_list = g.get("nodes", [128])
        seed_list = g.get("seed", [123])
        for D in D_list:
            for N in N_list:
                for seed in seed_list:
                    yield JobSpec(params={"bond_dim": int(D), "nodes": int(N), "seed": int(seed)})

    def evaluate(self, job: JobSpec, resources: Mapping[str, Any] | None = None) -> Result:
        D = int(job.params.get("bond_dim", 4))
        N = int(job.params.get("nodes", 128))
        seed = int(job.params.get("seed", 123))
        rng = np.random.default_rng(seed)
        net = rng.normal(size=(N, D))
        s = np.linalg.svd(net, compute_uv=False)
        s_mean, s_std = float(np.mean(s)), float(np.std(s))
        outlier_flag = float(np.max(s) > s_mean + 3*s_std)
        p = (s/np.linalg.norm(s))**2
        ent_entropy = float(np.sum(p * -np.log(p + 1e-12)))
        return Result(
            metrics={"sv_mean": s_mean, "sv_std": s_std, "sv_outlier": outlier_flag, "ent_entropy": ent_entropy},
            info={"bond_dim": D, "nodes": N, "seed": seed}
        )

plugin = PluginImpl()
