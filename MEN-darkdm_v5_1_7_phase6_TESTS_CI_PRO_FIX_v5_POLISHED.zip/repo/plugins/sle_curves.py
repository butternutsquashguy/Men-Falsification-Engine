
from __future__ import annotations
import numpy as np
from typing import Mapping, Iterable, Any
from dataclasses import dataclass

@dataclass(frozen=True)
class JobSpec:
    params: Mapping[str, Any]
    meta: Mapping[str, Any] | None = None

@dataclass(frozen=True)
class Result:
    metrics: Mapping[str, float]
    info: Mapping[str, Any] | None = None

class PluginImpl:
    name = "sle_curves"

    def enumerate_jobs(self, priors: Mapping[str, Any]) -> Iterable[JobSpec]:
        g = (priors or {}).get("grid", {})
        kappa_list = g.get("kappa", [2.0, 4.0, 6.0])
        steps_list = g.get("steps", [2000])
        seed_list = g.get("seed", [7])
        for kap in kappa_list:
            for steps in steps_list:
                for seed in seed_list:
                    yield JobSpec(params={"kappa": float(kap), "steps": int(steps), "seed": int(seed)})

    def evaluate(self, job: JobSpec, resources: Mapping[str, Any] | None = None) -> Result:
        kappa = float(job.params.get("kappa", 4.0))
        steps = int(job.params.get("steps", 2000))
        seed = int(job.params.get("seed", 7))

        rng = np.random.default_rng(seed)
        dW = rng.normal(0.0, (1.0/steps)**0.5, size=steps)
        W = np.cumsum(dW)
        z = np.zeros(steps, dtype=np.complex128)
        for i in range(1, steps):
            z[i] = z[i-1] + np.exp(1j * np.sqrt(kappa) * W[i])

        path_len = float(np.sum(np.abs(np.diff(z))))
        xr, yr = z.real, z.imag
        def box_count(grid):
            xmin, xmax = xr.min(), xr.max()
            ymin, ymax = yr.min(), yr.max()
            nx = ny = grid
            dx = (xmax-xmin+1e-9)/nx; dy = (ymax-ymin+1e-9)/ny
            occ = set()
            for xi, yi in zip(xr, yr):
                ix = int((xi - xmin)/dx); iy = int((yi - ymin)/dy)
                occ.add((min(ix, nx-1), min(iy, ny-1)))
            return len(occ)
        n1 = box_count(64)
        n2 = box_count(128)
        roughness = float((n2 - n1) / max(n1,1))

        return Result(
            metrics={"path_length": path_len, "roughness": roughness, "kappa": kappa},
            info={"steps": steps, "seed": seed}
        )

plugin = PluginImpl()
