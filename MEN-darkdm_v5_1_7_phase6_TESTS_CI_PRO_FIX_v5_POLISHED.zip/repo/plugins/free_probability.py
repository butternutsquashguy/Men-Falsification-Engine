
from __future__ import annotations
import numpy as np
from typing import Mapping, Iterable, Any
from dataclasses import dataclass

@dataclass(frozen=True)
class JobSpec:
    params: Mapping[str, Any]
    meta: Mapping[str, Any] | None = None

@dataclass(frozen=True)
class Result:
    metrics: Mapping[str, float]
    info: Mapping[str, Any] | None = None

class PluginImpl:
    name = "free_probability"

    def enumerate_jobs(self, priors: Mapping[str, Any]) -> Iterable[JobSpec]:
        g = (priors or {}).get("grid", {})
        N_list   = g.get("N", [5000])
        alpha_ls = g.get("alpha", [0.0, 0.5])
        seed_list= g.get("seed", [11])
        for N in N_list:
            for a in alpha_ls:
                for seed in seed_list:
                    yield JobSpec(params={"N": int(N), "alpha": float(a), "seed": int(seed)})

    def evaluate(self, job: JobSpec, resources: Mapping[str, Any] | None = None) -> Result:
        N = int(job.params.get("N", 5000))
        alpha = float(job.params.get("alpha", 0.0))
        seed = int(job.params.get("seed", 11))
        rng = np.random.default_rng(seed)
        x = rng.normal(size=N)
        y = rng.standard_t(df=5, size=N)
        data = (1-alpha)*x + alpha*y

        m2 = float(np.mean(data**2))
        m3 = float(np.mean(data**3))
        m4 = float(np.mean(data**4))
        skew = m3 / (m2**1.5 + 1e-12)
        kurt = m4 / (m2**2 + 1e-12) - 3.0
        k4_free_proxy = float(m4 - 2*(m2**2))

        return Result(
            metrics={"var": m2, "skew": skew, "kurt_excess": kurt, "k4_free_proxy": k4_free_proxy},
            info={"N": N, "alpha": alpha, "seed": seed}
        )

plugin = PluginImpl()
