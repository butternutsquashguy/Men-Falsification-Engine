#!/usr/bin/env python3
"""
CLI to run quick MEN dark-DM sweeps and log results to CSV.
Usage examples:
  python -m examples.run_sweeps --mode dbbh --N 20 --Lambda_conf 5 --mq 1 --T_dark 0.5 --kappa 3.5 --out dbbh.csv
  python -m examples.run_sweeps --mode qds  --w -0.8 --T_end 1e9 --m_dm 1e5 --out qds.csv
"""
import argparse, csv, json, sys
import numpy as np
from men_dark_dm import (
    DBBHParams, QdSParams,
    compute_dbbh_abundance, compute_qds_abundance,
    anomaly_tail_summary, ib_feature_edge_score,
    forecast_sgwb_fast_expansion, forecast_sgwb_collapse_epoch
)

def run_dbbh(args):
    p = DBBHParams(N=args.N, Lambda_conf=args.Lambda_conf, mq=args.mq, T_dark=args.T_dark, rmt_tail_kappa=args.kappa, seed=args.seed)
    res = compute_dbbh_abundance(p)
    # SGWB: collapse-epoch toy forecast
    sgwb = forecast_sgwb_collapse_epoch(res["m_dark_baryon_GeV"], res["collapse_prob"])
    res["sgwb"] = {"peak_Hz": sgwb["peak_Hz"], "Omega_GW@peak": max(sgwb["Omega_GW"])}
    return res

def run_qds(args):
    p = QdSParams(w=args.w, T_end=args.T_end, m_dm=args.m_dm, seed=args.seed)
    res = compute_qds_abundance(p)
    # SGWB: fast expansion toy forecast
    sgwb = forecast_sgwb_fast_expansion(p.w)
    res["sgwb"] = {"alpha": sgwb["alpha"], "Omega_GW@1Hz": float(np.interp(1.0, sgwb["f_Hz"], sgwb["Omega_GW"]))}
    return res

def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["dbbh","qds"], required=True)
    ap.add_argument("--out", type=str, required=True)

    # DBBH params
    ap.add_argument("--N", type=int, default=20)
    ap.add_argument("--Lambda_conf", type=float, default=5.0)
    ap.add_argument("--mq", type=float, default=1.0)
    ap.add_argument("--T_dark", type=float, default=0.5)
    ap.add_argument("--kappa", type=float, default=3.0)

    # QdS params
    ap.add_argument("--w", type=float, default=-0.8)
    ap.add_argument("--T_end", type=float, default=1e9)
    ap.add_argument("--m_dm", type=float, default=1e5)

    ap.add_argument("--seed", type=int, default=1234)
    args = ap.parse_args(argv)

    if args.mode == "dbbh":
        res = run_dbbh(args)
    else:
        res = run_qds(args)

    # flat CSV log
    flat = {**{f"param.{k}": v for k,v in res["params"].items()},
            **{k:v for k,v in res.items() if k not in ("params","sgwb")},
            **{f"sgwb.{k}": v for k,v in res.get("sgwb",{}).items()}}

    fieldnames = list(flat.keys())
    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerow(flat)

    print(json.dumps(res, indent=2))

if __name__ == "__main__":
    main()
