# MEN Dark-DM Modules (M-DBBH & M-QdS)

This mini-package plugs two early-universe dark-matter mechanisms into your MEN Cosmogenesis pipeline:

1. **M-DBBH** (Dark-baryon black-hole relics) — collapse-dominated rare events, mapped through MEN's RMT/outlier and tensor-network branches.
2. **M-QdS** (Quasi–de Sitter horizon production) — static-observer thermal radiation during a short fast-expansion era, mapped through MEN's information-bottleneck and conformal/SLE branches.

> Physics kernels are placeholders marked **TODO**. Wire these to your production transfer functions and diagnostics (CMB/LSS anomaly catalogs, ML compressibility, SGWB solvers).

## Install (editable)

```bash
pip install -e .
```

## Quick sweeps

```bash
python -m examples.run_sweeps --mode dbbh --N 20 --Lambda_conf 5 --mq 1 --T_dark 0.5 --kappa 3.5 --out dbbh.csv
python -m examples.run_sweeps --mode qds  --w -0.8 --T_end 1e9 --m_dm 1e5 --out qds.csv
```

## API (short)

```python
from men_dark_dm import (
  DBBHParams, QdSParams,
  compute_dbbh_abundance, compute_qds_abundance,
  anomaly_tail_summary, ib_feature_edge_score,
  forecast_sgwb_fast_expansion, forecast_sgwb_collapse_epoch
)
```

## Wiring into MEN

- Replace `compute_dbbh_abundance` and `compute_qds_abundance` internals with your calibrated transfer kernels.
- Feed outputs to your existing CMB/LSS/SGWB analyzers.
- Use `anomaly_tail_summary()` and `ib_feature_edge_score()` only as placeholders for your production diagnostics.
