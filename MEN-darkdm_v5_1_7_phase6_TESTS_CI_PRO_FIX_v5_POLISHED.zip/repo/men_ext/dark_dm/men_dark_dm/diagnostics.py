from __future__ import annotations
from typing import Dict, Any, Optional
import numpy as np

def anomaly_tail_summary(sky_map: np.ndarray, k_sigma: float = 3.0) -> Dict[str, Any]:
    """
    Simple anomaly-tail diagnostic:
      - fraction of pixels beyond k*sigma
      - max/min z-score
    Replace with your production CMB/LSS pipeline (cold/hot spot catalogs, alignment stats, etc.).
    """
    x = sky_map.ravel().astype(float)
    x = x - x.mean()
    s = x.std() if x.std() > 0 else 1.0
    z = x / s
    tail_frac = float(np.mean(np.abs(z) > k_sigma))
    return {
        "k_sigma": float(k_sigma),
        "tail_fraction": tail_frac,
        "z_max": float(z.max()),
        "z_min": float(z.min()),
        "n": int(x.size)
    }

def ib_feature_edge_score(sky_map: np.ndarray, block: int = 8) -> float:
    """
    Toy 'information bottleneck' edge score:
      - Compute variance explained after PCA-like local compression (here: blockwise mean)
      - Return 1 - (reconstruction_error / signal_var), in [0,1], where higher ~ cleaner compressibility
    Replace with your ML autoencoder/IB diagnostic.
    """
    H, W = sky_map.shape
    h = H // block * block
    w = W // block * block
    x = sky_map[:h, :w].astype(float)
    signal_var = float(x.var() + 1e-12)

    # blockwise coarse-grain (mean)
    xb = x.reshape(h//block, block, w//block, block).mean(axis=(1,3))
    # upsample (nearest) to original size
    xu = np.repeat(np.repeat(xb, block, axis=0), block, axis=1)
    err = float(((x - xu)**2).mean())
    score = float(np.clip(1.0 - err / signal_var, 0.0, 1.0))
    return score
