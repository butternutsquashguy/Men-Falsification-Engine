"""
MEN Dark-DM Modules
-------------------
Plug-in modules for MEN Cosmogenesis pipeline:
 - M-DBBH: Dark-baryon black-hole relics (collapse-dominated rare events)
 - M-QdS : Quasi–de Sitter horizon-produced dark matter

These modules expose:
 - Parameter dataclasses
 - Abundance/yield estimators
 - Hooks for MEN diagnostics: anomaly tails, IB feature edges, SGWB forecasts

Replace TODO sections with your precise physics & transfer kernels.
"""
from .modules import DBBHParams, QdSParams, compute_dbbh_abundance, compute_qds_abundance, rmt_rare_event_kernel
from .diagnostics import anomaly_tail_summary, ib_feature_edge_score
from .sgwb import forecast_sgwb_fast_expansion, forecast_sgwb_collapse_epoch

__all__ = [
    "DBBHParams", "QdSParams",
    "compute_dbbh_abundance", "compute_qds_abundance",
    "rmt_rare_event_kernel",
    "anomaly_tail_summary", "ib_feature_edge_score",
    "forecast_sgwb_fast_expansion", "forecast_sgwb_collapse_epoch"
]
