from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any, Tuple, Optional
import numpy as np

# ---------------------------
# M-DBBH: Dark-baryon BH relics
# ---------------------------

@dataclass
class DBBHParams:
    # Dark SU(N) sector knobs
    N: int                    # number of colors (large-N friendly)
    Lambda_conf: float        # confinement scale [GeV] (order-of-magnitude)
    mq: float                 # dark quark constituent mass [GeV]
    T_dark: float             # dark sector temperature at hadronization [GeV]

    # MEN-side control
    rmt_tail_kappa: float = 3.0   # rare-event tail multiplier (units of sigma)
    seed: Optional[int] = None

def rmt_rare_event_kernel(n_samples: int, kappa: float, seed: Optional[int] = None) -> float:
    """
    Toy rare-event rate: Pr(|X| > kappa*sigma) for X~N(0,1). Replace with RMT/Tracy-Widom tail if desired.
    Returns estimated tail probability.
    """
    rng = np.random.default_rng(seed)
    x = rng.standard_normal(n_samples)
    sigma = x.std()
    tail = np.mean(np.abs(x) > kappa * sigma)
    return float(tail)

def compute_dbbh_abundance(p: DBBHParams, n_mc: int = 20000) -> Dict[str, Any]:
    """
    Returns a dict with:
      - Omega_dbbh: fractional abundance proxy (0..1) [toy]
      - collapse_prob: rare-event probability (proxy for composite collapse channel)
      - notes: text guidance

    TODO: replace with calibrated collapse kernel per dark-baryon mass, binding energy, and formation conditions.
    """
    tail_p = rmt_rare_event_kernel(n_samples=n_mc, kappa=p.rmt_tail_kappa, seed=p.seed)

    # Heuristic mass scale for dark baryon (toy): ~ N * mq
    m_dark_baryon = p.N * p.mq  # GeV

    # Toy collapse efficiency: increases with N and Lambda_conf/T_dark ratio; scaled by rare tail probability
    eff = np.clip((p.N / 10.0) * (p.Lambda_conf / max(p.T_dark, 1e-6)) * (1.0 + 2.0 * tail_p), 0.0, 50.0)

    # Convert to a 0..1 abundance proxy with a saturating map (placeholder for Boltzmann-like freeze-out calc)
    Omega = float(1.0 - np.exp(-0.02 * eff))

    return {
        "params": asdict(p),
        "collapse_prob": tail_p,
        "m_dark_baryon_GeV": m_dark_baryon,
        "efficiency_proxy": eff,
        "Omega_dbbh": Omega,
        "notes": "Toy abundance proxy. Replace with calibrated collapse + relic density calculation."
    }

# ---------------------------
# M-QdS: quasi–de Sitter horizon DM
# ---------------------------

@dataclass
class QdSParams:
    w: float                  # equation-of-state in (-1, -1/3)
    T_end: float              # effective 'end temperature' or scale [GeV]
    m_dm: float               # DM particle mass [GeV]

    # MEN-side/diagnostic control
    ib_scale: int = 512       # map size proxy for IB edge scoring
    seed: Optional[int] = None

def _thermal_yield_static_observer(w: float, T_end: float, m_dm: float) -> float:
    """
    Placeholder for the static-observer thermal yield integral during a fast-expanding phase.
    Monotone with T_end, suppressed when m_dm >> T_end, and sensitive to w.
    """
    w_factor = np.clip((abs(w) - 1/3.0) / (1.0 - 1/3.0), 0.0, 1.0)  # maps w in (-1,-1/3) -> (0,1]
    mass_supp = 1.0 / (1.0 + (m_dm / max(T_end, 1e-6))**1.2)        # suppress heavy masses
    return float(0.5 * w_factor * mass_supp)

def compute_qds_abundance(p: QdSParams) -> Dict[str, Any]:
    """
    Returns a dict with:
      - Omega_qds: fractional abundance proxy (0..1) [toy]
      - yield_proxy: thermal yield proxy from horizon radiation
      - notes: text guidance

    TODO: replace with the exact yield formulae from the quasi–de Sitter calculation (static observer thermality).
    """
    if not (-1.0 < p.w < -1.0/3.0):
        raise ValueError("w must be in (-1, -1/3) for quasi–de Sitter expansion.")
    y = _thermal_yield_static_observer(p.w, p.T_end, p.m_dm)
    # Map yield to abundance proxy with mild saturation
    Omega = float(np.clip(1.5 * y, 0.0, 1.0))
    return {
        "params": asdict(p),
        "yield_proxy": y,
        "Omega_qds": Omega,
        "notes": "Toy abundance proxy. Replace with calibrated horizon-radiation relic density."
    }
