from __future__ import annotations
from typing import Dict, Any
import numpy as np

def forecast_sgwb_fast_expansion(w: float, duration_e_folds: float = 3.0) -> Dict[str, Any]:
    """
    Toy SGWB forecast for a fast-expanding phase (quasi–de Sitter with w in (-1, -1/3)).
    Outputs a crude broken power-law spectrum spec.
    Replace with your GW solver and transfer kernels.
    """
    if not (-1.0 < w < -1.0/3.0):
        raise ValueError("w must be in (-1, -1/3).")
    alpha = 3.0 * (abs(w) - 1/3.0)   # slope proxy
    f = np.logspace(-4, 2, 300)      # Hz (broad; adjust to LISA–aLIGO where appropriate)
    omega = 1e-12 * (f / 1.0)**alpha * np.exp(-f / (10**duration_e_folds))
    return {"f_Hz": f.tolist(), "Omega_GW": omega.tolist(), "alpha": float(alpha), "duration_e_folds": float(duration_e_folds)}

def forecast_sgwb_collapse_epoch(mass_scale_GeV: float, rate_proxy: float) -> Dict[str, Any]:
    """
    Toy SGWB forecast for an early collapse epoch leading to compact relics.
    The spectrum amplitude scales with event 'rate_proxy' and peak frequency with mass_scale.
    Replace with your realistic collapse/merger/plunge spectra.
    """
    peak = 1e2 / (1.0 + mass_scale_GeV**0.25)  # arbitrary frequency scaling
    f = np.logspace(-2, 3, 300)
    omega = (1e-14 * rate_proxy) * np.exp(-0.5 * ((np.log10(f) - np.log10(peak))/0.6)**2)
    return {"f_Hz": f.tolist(), "Omega_GW": omega.tolist(), "peak_Hz": float(peak), "rate_proxy": float(rate_proxy)}
