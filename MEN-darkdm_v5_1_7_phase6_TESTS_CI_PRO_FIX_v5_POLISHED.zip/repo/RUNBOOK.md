Runbook


### Example with guardrails
```bash
python scripts/compute_metrics_healpy.py   --map-fits path/to/map.fits   --mask-fits path/to/mask.fits   --ordering-in auto --force-ordering RING   --rotate-from auto --rotate-to GAL   --nside-target 64   --apodize-mode cosine --apodize-radius-arcmin 60   --pseudo-cl-correct w2   --k 3 --hemi-nside 8 --var-fwhm-deg 20 --lmin 2 --lmax 30   --out metrics/healpy_observables.json
```


## v5.1 data ingestion examples
make fetch-sdss RA0=150 RA1=160 DEC0=-5 DEC1=+5 NSIDE=64
make fetch-kids
python scripts/shear_to_healpix.py --catalog data/raw/kids/KiDS_DR4.1_SOM_gold_WL_cat.fits --nside 64
make fetch-gwosc CAT=GWTC-3 EVENT=GW190814 VER=v3 NSIDE=64
make fetch-icecube NSIDE=64
make fetch-planck PRODUCT=SMICA


## v5.1.1 quick recipes
make fetch-eso-tap
python scripts/fetch_eso_tap_cat.py --table <schema.table> --ra 150 --dec 2 --radius-deg 2 --top 200000 --nside 64
make fetch-tap TAP=https://archive.eso.org/tap_cat ADQL="SELECT TOP 5000 ra,dec FROM some.table" NSIDE=64
make fetch-desi URL=https://data.desi.lbl.gov/public/.../catalog.fits
python scripts/catalog_to_healpix.py --input data/raw/desi/catalog.fits --nside 64 --ra-col RA --dec-col DEC


## v5.1.2 TN slope quick start
# 1) compute standard observables
python scripts/compute_metrics_healpy.py --map-fits <map.fits> --mask-fits <mask.fits> --out metrics/healpy_observables.json

# 2) compute TN slope (B metric)
python scripts/compute_tn_slope.py --map-fits <map.fits> --mask-fits <mask.fits> --nsides 32,64,128,256 --out metrics/tn_slope.json

# 3) merge
make merge-metrics IN="metrics/healpy_observables.json metrics/tn_slope.json" OUT=metrics/observables_merged.json

## v5.1.3 behavior
- `make metrics` now: compute scalar metrics → compute TN slope (B) → merge → `metrics/observables_merged.json`.
- `make run` prefers the merged file automatically, falls back to `metrics/healpy_observables.json` if missing.
