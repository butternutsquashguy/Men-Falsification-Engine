# MEN-OBS Stacking + Envelope Patch (v0.1)

**Date:** 2025-08-17

This patch adds **stack-first + envelope modeling** with **systematics**, **finite-N corrections**, and a **hierarchical stacked likelihood**.
It is designed to be unzipped at the **root of your existing MEN-OBS repo** (same level as `research_pipeline/` and `schemas/`).

---

## What’s included

- `research_pipeline/stacking/`
  - `stacker.py` — stackers for time series (SGWB), spectra (CMB/LSS), and C_ell.
  - `envelopes.py` — compact 2–3 parameter envelopes (EchoEnvelope, PowerEnvelope).
  - `baselines.py` — baseline models (ringdown-ish for SGWB; ΛCDM-like tilt for CMB/LSS).
  - `systematics.py` — instrument/foreground uncertainty propagation utilities.
  - `finite_n.py` — bootstrap + analytic finite-N dispersion.
- `research_pipeline/hierarchical_fit.py` — joint likelihood across datasets with shared envelope.
- Patched modules (drop-in replacements):
  - `research_pipeline/sgwb_echo_module.py` — adds coherent stacking + envelope fit.
  - `research_pipeline/lss_non_gaussian_mapper.py` — supports patch-stacking + envelope overlay.
  - `research_pipeline/cmb_sgwb_correlation.py` — supports stacked cross-C_ell + envelope.
- `tests/` smoke tests for the new utilities.
- `README_PATCH.md` — quick start.
- `schemas/metrics.schema.patch.json` — **non-breaking** extension notes for envelope metadata.
- `examples/mini_demo/` — tiny synthetic example to sanity-check installation.

> NOTE: This patch does **not** remove or overwrite existing data fetchers or orchestrators. If your repo already has these files, back them up before copying, or inspect diffs and merge as needed.

---

## Install / Apply

1. **Back up** your repo (optional but recommended).
2. Unzip this archive in the **repo root**. You should end up with paths like:
   - `research_pipeline/stacking/stacker.py`
   - `research_pipeline/hierarchical_fit.py`
3. (Optional) Inspect and manually merge `sgwb_echo_module.py`, `lss_non_gaussian_mapper.py`, `cmb_sgwb_correlation.py` if you have local edits.
4. Run smoke tests on the new utilities:
   ```bash
   python -m pytest tests/test_stacking.py -q
   ```

---

## Orchestrator integration

No orchestrator changes are strictly required. Modules call into the new utilities if importable.
If your orchestrator lists module names explicitly, no changes are needed.

---

## Outputs & Schema

New modules annotate results JSON with an `envelope` block:
```json
"envelope": {
  "name": "EchoEnvelope",
  "params": {"depth": 0.12, "f0": 160.0, "alpha": 3.0},
  "cov": [[...]],
  "finite_n_sem": {"depth": 0.02, "f0": 5.1, "alpha": 0.4}
}
```
This is **additive** to your existing schema; see `schemas/metrics.schema.patch.json`.

---

## Mini demo

```bash
python examples/mini_demo/run_mini_demo.py
```
This will generate a synthetic stacked fit and print a JSON-like summary.
