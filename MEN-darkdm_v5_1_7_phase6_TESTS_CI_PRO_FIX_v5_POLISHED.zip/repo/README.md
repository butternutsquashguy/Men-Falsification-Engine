# MEN Bundle


Enhanced pipeline docs added.


### New safety rails & options
- `--ordering-in {auto,RING,NEST}` + `--force-ordering {NONE,RING,NEST}` ensure map/mask ordering consistency (uses FITS header when available).
- `--rotate-from {auto,GAL,ECL,EQU}` + `--rotate-to {NONE,GAL,ECL,EQU}` rotate frames as needed (e.g., rotate Equatorial to Galactic).
- `--pseudo-cl-correct {none,fsimple,w2}` optional pseudo-Cℓ correction for the low-ℓ hemispherical power asymmetry.

## v5 highlights
- Conda env file `environment-astro.yml` + `Makefile` (`setup`, `check`, `planck`, `metrics`, `run`, `calibrate`, `report`).
- Guardrailed metrics (`ordering/frame` control, pseudo-Cℓ correction).
- Simulation & calibration suite → empirical p-values.
- Plugin architecture for physics modules (`plugins/`).
- Static HTML report generator (`scripts/make_report.py`).
- CSV export of results (`_rows_with_flags.csv`).


## v5.1 additions
- Fetchers: SDSS DR18, KiDS DR4.1 shears, GWOSC skymaps, IceCube alerts, Planck maps.
- Utility: shear_to_healpix.py
- Deps: astroquery, ligo.skymap, requests
- Make targets: fetch-sdss, fetch-kids, fetch-gwosc, fetch-icecube, fetch-planck


## v5.1.1
- TAP fetchers: generic ADQL + ESO TAP region helper.
- DESI helper + generic catalog->HEALPix binner.
- Env: +pyvo for TAP stack.


## v5.1.2
- **TN slope estimator** (`scripts/compute_tn_slope.py`): multiscale spectral complexity vs resolution; outputs `tn_slope_est` plus detailed PR/SE slopes.
- **JSON merge tool** (`tools/merge_json.py`) and Make targets: `tn-slope`, `merge-metrics`.

## v5.1.3
- Wired **TN slope (B)** into constraints: the runner reads `metrics/observables_merged.json` by default; `metrics` target now computes TN slope and merges automatically.


## Run (canonical CLI)

```bash
python -m research_pipeline.men_obs_pipeline list
python -m research_pipeline.men_obs_pipeline run all --config research_pipeline/config.yaml
```
