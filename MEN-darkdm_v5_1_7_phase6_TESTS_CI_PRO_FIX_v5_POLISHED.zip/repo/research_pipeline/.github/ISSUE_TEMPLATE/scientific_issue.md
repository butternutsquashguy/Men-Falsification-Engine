
name: Scientific/Technical Issue
about: Use this template to report scientific or technical issues or feature requests
title: "[ISSUE] "
labels: "enhancement"
assignees: ""

## Description
A clear and concise description of the issue or feature request.

## Steps to Reproduce
Steps to reproduce the behavior:

1.
2.
3.

## Expected Behavior
Describe what you expected to happen.

## Additional Context
Add any other context about the problem here.
