
import streamlit as st
import yaml
import json
from datetime import datetime

def display_statistics(results):
    st.header('Statistical Significance')
    if 'false_alarm_probability' in results:
        st.write(f"False Alarm Probability (FAP): {results['false_alarm_probability']:.4g}")
    if 'p_value' in results:
        st.write(f"p-value: {results['p_value']:.4g}")
    if 'empirical_trial_factor' in results:
        st.write(f"Empirical Trial Factor: {results['empirical_trial_factor']}")

def log_provenance(run_data, filepath='provenance_log.json'):
    try:
        with open(filepath, 'r') as f:
            log = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        log = []
    log.append(run_data)
    with open(filepath, 'w') as f:
        json.dump(log, f, indent=2)

def main():
    st.title('MEN-OBS-UI Pipeline')
    config_file = 'config.yaml'
    st.sidebar.header('Pipeline Controls')
    if st.sidebar.button('Run Detection'):
        import men_obs_pipeline as pipeline
        results, _ = pipeline.run_pipeline(config_file, n_events=5, stack=False)
        st.write('Detection Results:', results)
        for res in results:
            display_statistics(res)
        # Log provenance
        run_data = {
            'timestamp': datetime.now().isoformat(),
            'config': yaml.safe_load(open(config_file)),
            'results': results
        }
        log_provenance(run_data)
        st.success('Run complete and provenance logged.')

if __name__ == '__main__':
    main()

import json
import streamlit as st

def export_snapshot(run_data, filename='men_obs_snapshot.json'):
    json_str = json.dumps(run_data, indent=2)
    st.download_button('Download Snapshot', json_str, file_name=filename, mime='application/json')

def import_snapshot():
    uploaded_file = st.file_uploader('Import Analysis Snapshot', type=['json'])
    if uploaded_file is not None:
        try:
            snapshot = json.load(uploaded_file)
            st.success('Snapshot loaded successfully.')
            st.json(snapshot)
            return snapshot
        except Exception as e:
            st.error(f'Error loading snapshot: {e}')
    return None

def main():
    st.title('MEN-OBS-UI Pipeline')
    config_file = 'config.yaml'
    st.sidebar.header('Pipeline Controls')
    if st.sidebar.button('Run Detection'):
        import men_obs_pipeline as pipeline
        results, _ = pipeline.run_pipeline(config_file, n_events=5, stack=False)
        st.write('Detection Results:', results)
        for res in results:
            display_statistics(res)
        run_data = {
            'timestamp': datetime.now().isoformat(),
            'config': yaml.safe_load(open(config_file)),
            'results': results
        }
        log_provenance(run_data)
        st.success('Run complete and provenance logged.')
        export_snapshot(run_data)

    st.sidebar.header('Snapshot Management')
    snapshot = import_snapshot()
