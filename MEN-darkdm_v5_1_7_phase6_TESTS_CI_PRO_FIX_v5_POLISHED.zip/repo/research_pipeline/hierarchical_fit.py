import numpy as np
from dataclasses import dataclass
from typing import Callable, List, Dict, Any, Tuple
from scipy.optimize import minimize
from scipy.linalg import inv
from math import log

@dataclass
class Dataset:
    x: np.ndarray
    y: np.ndarray
    sigma: np.ndarray
    nuis_scale: float = 1.0  # simple scale nuisance per dataset

def _pack(params: Dict[str, float], nuis: List[float]) -> np.ndarray:
    return np.array(list(params.values()) + nuis, dtype=float)

def _unpack(theta: np.ndarray, param_keys: List[str], n_datasets: int):
    p = {k: float(theta[i]) for i, k in enumerate(param_keys)}
    nuis = [float(theta[len(param_keys) + j]) for j in range(n_datasets)]
    return p, nuis

def joint_negloglike(
    datasets: List[Dataset],
    baseline: Callable[[np.ndarray], np.ndarray],
    envelope: Callable[[np.ndarray], np.ndarray],
    param_keys: List[str],
    init_params: Dict[str, float],
    init_nuis: List[float],
    priors: Dict[str, Tuple[float, float]] = None
) -> Tuple[np.ndarray, Dict[str, Any]]:
    """Return function NLL(theta) + info for optimizer."""
    if priors is None:
        priors = {}

    def nll(theta: np.ndarray) -> float:
        p, nuis = _unpack(theta, param_keys, len(datasets))
        # set params to baseline/envelope (both dataclasses or callables with attributes)
        for k, v in p.items():
            if hasattr(baseline, k): setattr(baseline, k, v)
            if hasattr(envelope, k): setattr(envelope, k, v)

        total = 0.0
        for d, s in zip(datasets, nuis):
            mu = baseline(d.x) * envelope(d.x) * s
            var = d.sigma**2
            total += 0.5 * np.sum((d.y - mu)**2 / var + np.log(2*np.pi*var))
        # gaussian priors on parameters (mean, sigma)
        for k, (m, s) in priors.items():
            total += 0.5 * ((p[k] - m)/s)**2 + 0.5*np.log(2*np.pi*s**2)
        return float(total)

    theta0 = _pack(init_params, init_nuis)
    return nll, {"theta0": theta0, "param_keys": param_keys}

def fit_joint(datasets, baseline, envelope, init_params, init_nuis, priors=None):
    keys = list(init_params.keys())
    nll, info = joint_negloglike(datasets, baseline, envelope, keys, init_params, init_nuis, priors)
    res = minimize(nll, info["theta0"], method="L-BFGS-B")
    theta_hat = res.x
    # Approximate covariance via inverse Hessian (if provided)
    cov = None
    if hasattr(res, "hess_inv"):
        try:
            cov = res.hess_inv.todense() if hasattr(res.hess_inv, "todense") else res.hess_inv
            cov = np.array(cov, dtype=float)
        except Exception:
            cov = None
    p_hat, nuis_hat = _unpack(theta_hat, keys, len(datasets))
    # Information criteria
    k = len(theta_hat)
    n = sum(len(d.y) for d in datasets)
    ll = -nll(theta_hat)
    aic = 2*k - 2*ll
    bic = k * log(max(n,1)) - 2*ll
    return {
        "success": bool(res.success),
        "message": res.message,
        "params": p_hat,
        "nuis": nuis_hat,
        "cov": cov.tolist() if cov is not None else None,
        "aic": float(aic),
        "bic": float(bic),
        "negloglike": float(-ll)
    }
