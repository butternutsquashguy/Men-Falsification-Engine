
import json, time, uuid, hashlib, pathlib
import numpy as np

REPO_ROOT = pathlib.Path(__file__).resolve().parents[1]
ART_DIR = REPO_ROOT / "artifacts" / "modules" / "high_energy_burst_timing"
ART_DIR.mkdir(parents=True, exist_ok=True)

def simulate_streams(seed=21, n=500, rate=0.05, coincidence_window=0.02):
    rng = np.random.default_rng(seed)
    t_gw = np.cumsum(rng.exponential(1/rate, size=n))
    t_he = np.cumsum(rng.exponential(1/rate, size=n))
    # inject one coincidence
    t_he[rng.integers(0,n)] = t_gw[rng.integers(0,n)] + rng.normal(0, coincidence_window/4)
    return t_gw, t_he

def count_coincidences(a,b,window):
    i=j=0; c=0
    while i < len(a) and j < len(b):
        if abs(a[i]-b[j]) <= window:
            c += 1; i+=1; j+=1
        elif a[i] < b[j]:
            i+=1
        else:
            j+=1
    return c

def scramble(b, rng):
    b2 = np.array(b, copy=True)
    rng.shuffle(b2)
    return b2

def main():
    t0 = time.time()
    window = 0.05
    gw, he = simulate_streams(coincidence_window=window)
    c_obs = count_coincidences(gw, he, window)
    rng = np.random.default_rng(42)
    bg = []
    for _ in range(300):
        he_s = scramble(he, rng)
        bg.append(count_coincidences(gw, he_s, window))
    bg = np.array(bg)
    p = float((bg >= c_obs).sum()/max(1,len(bg)))
    (ART_DIR/"background.json").write_text(json.dumps({"values": bg.tolist()}, indent=2))
    res = {
        "module_name": "high_energy_burst_timing",
        "status": "ok",
        "p_value": p,
        "false_alarm_probability": p,
        "empirical_trial_factor": 1.0,
        "constraints": {"coincidences": int(c_obs)},
        "figures": [],
        "artifacts": [str((ART_DIR/"background.json").relative_to(REPO_ROOT))],
        "metadata": {"data_release":"fixture","runtime_s": round(time.time()-t0,3),"code_version":"v1.0-planA"},
        "seed": 21,
        "data_hash": hashlib.sha256(b"fixture").hexdigest()[:16],
        "run_uuid": str(uuid.uuid4()),
        "provenance": {"env_hash":"local","config_hash":"local","data_sources":[]}
    }
    (ART_DIR / "result.json").write_text(json.dumps(res, indent=2))
    print("high_energy_burst_timing: c_obs=", c_obs, " p≈", p)

if __name__ == "__main__":
    main()
