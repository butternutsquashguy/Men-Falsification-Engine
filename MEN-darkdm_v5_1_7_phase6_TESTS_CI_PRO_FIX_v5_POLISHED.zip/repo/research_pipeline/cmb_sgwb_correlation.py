"""Patched CMB-SGWB correlation with stacked cross-spectrum support (toy)."""
import json, os, numpy as np
from .stacking.stacker import stack_cl

def run(input_dir, out_json, meta=None):
    """Expects NPZ files: each with 'ell' and 'cl' arrays."""
    files = sorted([f for f in os.listdir(input_dir) if f.endswith('.npz')])
    if not files:
        raise FileNotFoundError(f"No NPZ cross-spectra found in {input_dir}")
    cl_list = []
    ells = None
    for f in files:
        d = np.load(os.path.join(input_dir, f))
        if ells is None:
            ells = d['ell']
        cl_list.append(d['cl'])
    ell, m, sem, n = stack_cl(ells, cl_list)
    result = {
        "module_name": "cmb_sgwb_correlation",
        "status": "ok",
        "p_value": 1.0,
        "false_alarm_probability": 1.0,
        "empirical_trial_factor": 1.0,
        "constraints": {},
        "figures": [],
        "artifacts": [],
        "metadata": {"data_release": "synthetic", "runtime_s": 0.0, "code_version": "patch-v0.1"},
        "seed": 0, "data_hash": "", "run_uuid": "",
        "provenance": {"env_hash":"", "config_hash":"", "data_sources":[]}
    }
    with open(out_json, "w") as f:
        json.dump(result, f, indent=2)
    return result
