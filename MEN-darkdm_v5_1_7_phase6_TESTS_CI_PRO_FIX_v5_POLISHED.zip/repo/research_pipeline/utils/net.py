
import os, time, hashlib
from pathlib import Path
try:
    import requests
except Exception:
    requests = None

def sha256_bytes(b: bytes) -> str:
    h = hashlib.sha256(); h.update(b); return h.hexdigest()

def ensure_requests():
    if requests is None:
        raise RuntimeError("The 'requests' package is required for real-data fetch. Please `pip install requests`.")

def download_text(url: str, cache_dir: str, name: str, max_age_s: int = 86400) -> str:
    """Download a small text file with basic caching. Returns path to cached file."""
    ensure_requests()
    Path(cache_dir).mkdir(parents=True, exist_ok=True)
    out = Path(cache_dir) / name
    if out.exists() and (time.time() - out.stat().st_mtime) < max_age_s:
        return str(out)
    headers = {"User-Agent":"MEN-OBS/phase4-realslice"}
    r = requests.get(url, headers=headers, timeout=30)
    r.raise_for_status()
    out.write_bytes(r.content)
    return str(out)

def download_form(url: str, data: dict, cache_dir: str, name: str, max_age_s: int = 86400) -> str:
    """POST form (e.g., TAP sync) and cache response."""
    ensure_requests()
    Path(cache_dir).mkdir(parents=True, exist_ok=True)
    out = Path(cache_dir) / name
    if out.exists() and (time.time() - out.stat().st_mtime) < max_age_s:
        return str(out)
    headers = {"User-Agent":"MEN-OBS/phase4-realslice"}
    r = requests.post(url, data=data, headers=headers, timeout=60, allow_redirects=True)
    r.raise_for_status()
    out.write_bytes(r.content)
    return str(out)
