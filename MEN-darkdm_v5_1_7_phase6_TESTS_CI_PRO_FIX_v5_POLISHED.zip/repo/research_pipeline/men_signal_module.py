class MENSignalModule:
    """
    Abstract base class for all MEN detection modules.
    Enforces detection and result summarization contract.
    """
    def detect(self, data):
        """
        Execute detection logic on input data.

        Args:
            data (Any): Raw or preprocessed domain-specific data.

        Returns:
            Any: Module-specific detection results.
        """
        raise NotImplementedError("detect() must be implemented in subclass.")

    def summarize(self):
        """
        Return a summary of results/statistics/findings.

        Returns:
            dict: Summary information.
        """
        raise NotImplementedError("summarize() must be implemented in subclass.")