
# test_men_obs.py - Phase 2 batch test
from men_obs_pipeline import run_pipeline

def test_batch_efficiency():
    results, stacked = run_pipeline('config.yaml', n_events=30, stack=True)
    assert results is not None
    print('Batch test complete. Results:', results)

if __name__ == '__main__':
    test_batch_efficiency()

from men_obs_pipeline import run_joint_analysis
import numpy as np

def test_joint_meta_analysis():
    sample_data = {
        'gw': np.random.normal(0, 1, 4096),
        'cmb_sgwb': np.random.normal(0, 1, 2048),
        'dark_lensing': np.random.normal(0, 1, 1024),
        'lss': np.random.normal(0, 1, 512),
        'high_energy': np.random.normal(0, 1, 256)
    }
    summary = run_joint_analysis('config.yaml', sample_data)
    assert summary is not None
    print('Joint meta-analysis test complete. Summary:', summary)

if __name__ == '__main__':
    test_joint_meta_analysis()
