# MEN-OBS: Maximally Entangled Nonspace Observability System

A modular pipeline to test and search for MEN boundary signals in astrophysical data—across SGWB, CMB, lensing, neutrinos, and large-scale structure.

## Install

- Python 3.8+
- numpy, scipy, pyyaml

```
pip install numpy scipy pyyaml
```

## Usage

Run with default (synthetic) config:

```
python men_obs_pipeline.py
```

Or with custom config:

```
python men_obs_pipeline.py --config config.yaml
```

Output can be saved as JSON:

```
python men_obs_pipeline.py --output output.json
```

## Structure

- `men_signal_module.py`: Core interface
- `[MODULE]_module.py`: Per-domain logic (SGWB, CMB, lensing, neutrinos, LSS)
- `men_obs_pipeline.py`: Main orchestrator
- `config.yaml`: Example config (edit for your test cases)
- `test_men_obs.py`: Old-style test harness (optional)

## Extending

- Add your real data loader to each module, or set `synthetic: false` and inject data in the pipeline.
- Modules are plug-and-play; write your own and add to the orchestrator list.

## Prompt Directives

- Each module operates independently, with detection kernel and config.
- Pipeline supports YAML/JSON config, CLI, synthetic data for full system smoke test.
- All module results are summarized to stdout and can be exported.

---

**MEN-OBS: For science beyond the event horizon.**

## Upgrading to Real Data

Each module has a `load_real_*_data(config)` stub. To use real data:
- Set `synthetic: false` in your config.yaml for the target module.
- Implement the loader using the documented API pointers inside each function stub.
- Required libraries may include: GWpy, PyCBC, healpy, astropy, h5py, astroquery, pandas, etc.
- If not implemented, pipeline will warn and fallback to synthetic.

For LIGO/PTA data:  
- See [GWpy documentation](https://gwpy.github.io/docs/stable/) and [GWOSC](https://www.gw-openscience.org/)
For Planck/WMAP:  
- Use [healpy](https://healpy.readthedocs.io/en/latest/) to load sky maps from FITS files.
For LSST/Euclid/SDSS:  
- Use [astroquery](https://astroquery.readthedocs.io/) or direct TAP/SQL query.
For IceCube/Hyper-K:  
- Public data available in HDF5/ASCII, see [IceCube data portal](https://icecube.wisc.edu/science/data/).