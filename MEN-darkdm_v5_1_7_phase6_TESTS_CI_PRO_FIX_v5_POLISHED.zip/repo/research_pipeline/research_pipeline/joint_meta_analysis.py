
import math
from typing import List, Dict

def fisher(pvals: List[float]) -> Dict[str, float]:
    # Fisher's method: chi2 statistic with 2k dof
    import scipy.stats as st
    stat = -2.0 * sum(math.log(max(p, 1e-300)) for p in pvals)
    k = len(pvals)
    p_comb = 1 - st.chi2.cdf(stat, 2*k)
    return {"method": "fisher", "statistic": stat, "combined_p_value": p_comb}

def stouffer(pvals: List[float], weights: List[float] = None) -> Dict[str, float]:
    import scipy.stats as st
    if weights is None:
        weights = [1.0] * len(pvals)
    z = sum(w * st.norm.ppf(1 - max(p, 1e-300)) for p, w in zip(pvals, weights))
    z /= math.sqrt(sum(w*w for w in weights))
    p_comb = 1 - st.norm.cdf(z)
    return {"method": "stouffer", "z": z, "combined_p_value": p_comb}

def tippett(pvals: List[float]) -> Dict[str, float]:
    # Tippett method uses min p, exact under independence
    import scipy.stats as st
    m = min(pvals)
    k = len(pvals)
    # P(min P <= m) = 1 - (1-m)^k
    combined = 1 - (1 - m)**k
    return {"method": "tippett", "combined_p_value": combined, "min_p": m}

def benjamini_hochberg_fdr(pvals: List[float]) -> Dict[str, List[float]]:
    m = len(pvals)
    order = sorted(range(m), key=lambda i: pvals[i])
    q = [0.0]*m
    prev = 1.0
    for rank, idx in enumerate(order, start=1):
        val = pvals[idx] * m / rank
        prev = min(prev, val)
        q[idx] = min(prev, 1.0)
    return {"method": "bh_fdr", "q_values": q}

def combine(pvals: List[float], method: str = "fisher", **kwargs) -> Dict:
    method = method.lower()
    if method == "fisher":
        return fisher(pvals)
    if method == "stouffer":
        return stouffer(pvals, kwargs.get("weights"))
    if method == "tippett":
        return tippett(pvals)
    if method == "bh" or method == "bh_fdr" or method == "benjamini_hochberg_fdr":
        return benjamini_hochberg_fdr(pvals)
    raise ValueError(f"Unknown JMA method: {method}")
