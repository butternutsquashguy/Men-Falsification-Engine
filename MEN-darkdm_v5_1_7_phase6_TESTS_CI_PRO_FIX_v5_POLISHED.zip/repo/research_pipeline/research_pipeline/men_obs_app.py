
import json, pathlib, sys
import streamlit as st

REPO_ROOT = pathlib.Path(__file__).resolve().parents[1]
ARTIFACTS = REPO_ROOT / "artifacts" / "modules"
SCHEMAS = REPO_ROOT / "schemas"

st.set_page_config(page_title="MEN-OBS Suite", layout="wide")
st.title("MEN-OBS: Modular Meta-Analysis")

# Load schema
schema = json.loads((SCHEMAS / "metrics.schema.json").read_text())

# Discover modules by directories in artifacts
mods = sorted([p.name for p in ARTIFACTS.glob("*") if p.is_dir()])

method = st.sidebar.selectbox("JMA method", ["fisher","stouffer","tippett","bh_fdr"])
st.sidebar.write("Modules discovered:", mods)

def validate_json(data, schema):
    # minimal validation: check required keys exist
    missing = [k for k in schema.get("required", []) if k not in data]
    return missing

all_p = []
cols = st.columns(2)
for i, m in enumerate(mods):
    with cols[i % 2]:
        st.subheader(m)
        result_path = ARTIFACTS / m / "result.json"
        if result_path.exists():
            data = json.loads(result_path.read_text())
            missing = validate_json(data, schema)
            if missing:
                st.error(f"Missing keys: {missing}")
            else:
                st.success("Schema OK")
            st.json({k: data.get(k) for k in ["module_name","status","p_value","false_alarm_probability","constraints","metadata"]})
            if "p_value" in data:
                all_p.append(data["p_value"])
        else:
            st.warning("No result.json yet")

st.divider()
st.subheader("Joint Meta-Analysis")
if all_p:
    st.write("Collected p-values:", all_p)
    try:
        from . import joint_meta_analysis as jma
    except Exception:
        import importlib
        jma = importlib.import_module("research_pipeline.joint_meta_analysis")
    res = jma.combine(all_p, method=method)
    st.json(res)
else:
    st.info("No p-values yet to combine.")
