import numpy as np
from dataclasses import dataclass

@dataclass
class EchoEnvelope:
    """Multiplicative envelope for stacked SGWB echo correlation traces.
    Params:
      depth: amplitude (0..1)
      f0: turnover frequency (Hz)
      alpha: sharpness (>0)
    E(f) = 1 - depth * (1 - exp(-(f/f0)**alpha))
    """
    depth: float = 0.1
    f0: float = 150.0
    alpha: float = 3.0

    def __call__(self, f):
        f = np.asarray(f)
        return 1.0 - self.depth * (1.0 - np.exp(-np.clip(f, 0, None) / np.maximum(self.f0, 1e-9))**self.alpha)

@dataclass
class PowerEnvelope:
    """Multiplicative envelope for CMB/LSS power-like spectra.
    Params:
      A: amplitude (fractional), k0: pivot, s: slope, beta: smoothness
    E(k) = 1 + A * (1 + (k/k0)**beta)**(-s/beta)
    """
    A: float = 0.05
    k0: float = 0.05
    s: float = 1.2
    beta: float = 2.0

    def __call__(self, k):
        k = np.asarray(k)
        x = np.power(1.0 + np.power(np.maximum(k, 1e-12)/self.k0, self.beta), -self.s/self.beta)
        return 1.0 + self.A * x
