import numpy as np
from dataclasses import dataclass

@dataclass
class RingdownBaseline:
    """Simple SGWB/RD baseline model (toy).
    B(f) = a0 * (f/fp)**-q * exp(-f/fc)
    """
    a0: float = 1.0
    fp: float = 100.0
    q: float = 1.0
    fc: float = 300.0

    def __call__(self, f):
        f = np.asarray(f) + 1e-12
        return self.a0 * np.power(f/self.fp, -self.q) * np.exp(-f/self.fc)

@dataclass
class LCDMTiltBaseline:
    """Toy ΛCDM-like tilt for power spectra (C_ell or P(k)).
    B(x) = A_s * (x/xp)**(n_s-1)
    """
    A_s: float = 1.0
    xp: float = 100.0
    n_s: float = 0.965

    def __call__(self, x):
        x = np.asarray(x) + 1e-12
        return self.A_s * np.power(x/self.xp, self.n_s - 1.0)
