import numpy as np

def _zscore(x, axis=None, eps=1e-9):
    mu = np.mean(x, axis=axis, keepdims=True)
    sd = np.std(x, axis=axis, keepdims=True) + eps
    return (x - mu) / sd

def stack_timeseries(traces, t=None, normalize='zscore', align='peak', peak_window=None):
    """Coherently stack 1D time series.
    Args:
        traces: list/array of 1D arrays of equal length
        t: optional time grid (1D)
        normalize: 'none'|'zscore'|'max'
        align: 'none'|'peak' — aligns trace peaks before stacking
        peak_window: (tmin, tmax) or (imin, imax) to restrict peak search
    Returns:
        stack_mean, stack_sem, n, t
    """
    arr = np.asarray(traces)
    n, L = arr.shape[0], arr.shape[1]
    if normalize == 'zscore':
        arr = _zscore(arr, axis=1)
    elif normalize == 'max':
        maxv = np.max(np.abs(arr), axis=1, keepdims=True) + 1e-12
        arr = arr / maxv

    if align == 'peak':
        aligned = np.zeros_like(arr)
        idx0 = L // 2
        for i in range(n):
            xi = arr[i]
            if peak_window is not None:
                if len(peak_window) == 2 and isinstance(peak_window[0], int):
                    imin, imax = peak_window
                else:
                    # assume times
                    assert t is not None, "time grid required for time-window alignment"
                    tmin, tmax = peak_window
                    imin, imax = np.searchsorted(t, tmin), np.searchsorted(t, tmax)
                j = imin + np.argmax(np.abs(xi[imin:imax]))
            else:
                j = int(np.argmax(np.abs(xi)))
            shift = idx0 - j
            aligned[i] = np.roll(xi, shift)
        arr = aligned

    stack_mean = arr.mean(axis=0)
    stack_sem = arr.std(axis=0) / np.sqrt(n)
    return stack_mean, stack_sem, n, t

def stack_spectra(spectra, weights=None, logspace=False):
    """Stack 1D spectra S(f) or S(k)."""
    S = np.asarray(spectra)
    if weights is None:
        weights = np.ones(S.shape[0])
    w = weights / (np.sum(weights) + 1e-12)
    if logspace:
        S = np.log(np.clip(S, 1e-30, None))
    m = np.average(S, axis=0, weights=w)
    if logspace:
        m = np.exp(m)
    sem = np.sqrt(np.average((S - m)**2, axis=0, weights=w)) / np.sqrt(S.shape[0])
    return m, sem, S.shape[0]

def stack_cl(ells, cl_list, weights=None):
    """Stack angular power spectra C_ell on same ell grid."""
    C = np.asarray(cl_list)
    if weights is None:
        weights = np.ones(C.shape[0])
    w = weights / (np.sum(weights) + 1e-12)
    m = np.average(C, axis=0, weights=w)
    sem = np.sqrt(np.average((C - m)**2, axis=0, weights=w)) / np.sqrt(C.shape[0])
    return ells, m, sem, C.shape[0]
