import numpy as np

def apply_multiplicative_systematic(y, sys_frac):
    """Apply multiplicative systematic uncertainty envelope to y.
    Returns (y, sigma_sys) so that total sigma can be sqrt(sig_stat^2 + sigma_sys^2).
    """
    y = np.asarray(y)
    sys = np.asarray(sys_frac)
    return y, np.abs(y) * sys

def combine_uncertainties(stat_sigma, sys_sigma):
    stat_sigma = np.asarray(stat_sigma)
    sys_sigma = np.asarray(sys_sigma)
    return np.sqrt(stat_sigma**2 + sys_sigma**2)
