import numpy as np

def bootstrap_sem(values, n_boot=1000, rng=None):
    rng = np.random.default_rng(rng)
    values = np.asarray(values)
    N = len(values)
    boots = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, N, size=N)
        boots[i] = np.mean(values[idx])
    return np.std(boots, ddof=1)

def finite_n_sem(single_sigma, n):
    return np.asarray(single_sigma) / np.sqrt(max(n, 1))
