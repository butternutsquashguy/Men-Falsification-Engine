
# Contribution Guidelines

Thank you for considering contributing to MEN-OBS-UI!

## How to Contribute
- Fork the repository and create your feature branch.
- Write clear, concise commit messages.
- Ensure code passes tests and adheres to existing style conventions.
- Document your changes and update the README as needed.
- Submit pull requests with a detailed description.

## Code of Conduct
We expect all contributors to adhere to a code of conduct fostering respectful and constructive collaboration.

## Reporting Issues
Use the issue tracker to report bugs or request features.

