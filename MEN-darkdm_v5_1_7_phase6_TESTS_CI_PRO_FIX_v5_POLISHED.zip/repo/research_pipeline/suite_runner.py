
import os, sys, json, time, importlib, traceback
from pathlib import Path
from datetime import datetime
import argparse, yaml

def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f) or {}

def deep_merge(a, b):
    out = dict(a or {})
    for k, v in (b or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = deep_merge(out[k], v)
        else:
            out[k] = v
    return out

def run_module(mod_name: str, base_cfg: dict, outroot: Path, mods_cfg: dict):
    cfg = dict(base_cfg)
    cfg["module_name"] = mod_name
    if mods_cfg and mod_name in mods_cfg:
        # deep merge
        def _merge(x, y):
            if isinstance(x, dict) and isinstance(y, dict):
                z = dict(x); 
                for kk,vv in y.items():
                    z[kk] = _merge(z.get(kk), vv)
                return z
            return y if y is not None else x
        cfg = _merge(cfg, mods_cfg[mod_name])
    outdir = outroot / mod_name
    outdir.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    status = "ok"; err = None; result_path = None
    try:
        mod = importlib.import_module(f"research_pipeline.modules.{mod_name}")
        result_path = mod.run(cfg, str(outdir))
    except Exception as e:
        status = "error"
        err = f"{type(e).__name__}: {e}"
        traceback.print_exc()
    dur = round(time.time() - t0, 3)
    return {"module": mod_name, "status": status, "result": result_path, "runtime_s": dur, "error": err}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--suite", required=True, help="Path to suite YAML")
    p.add_argument("--config", default="research_pipeline/config.yaml", help="Base config YAML")
    p.add_argument("--out", default=None, help="Artifacts output dir (default artifacts/suites/<suite>/<timestamp>)")
    args = p.parse_args()

    suite = yaml.safe_load(Path(args.suite).read_text())
    base_cfg = load_config(args.config)
    suite_name = suite.get("name", Path(args.suite).stem)
    modules = suite.get("modules", base_cfg.get("modules", []))
    mods_cfg = suite.get("modules_config", {})
    base_overrides = suite.get("config_overrides", {})
    # deep merge base overrides into base cfg
    cfg = deep_merge(base_cfg, base_overrides)

    ts = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
    outroot = Path(args.out) if args.out else Path("artifacts") / "suites" / suite_name / ts
    outroot.mkdir(parents=True, exist_ok=True)

    manifest = {
        "suite_name": suite_name,
        "timestamp_utc": ts,
        "base_config": args.config,
        "suite_file": args.suite,
        "modules": modules,
        "runs": [],
    }

    rc = 0
    for m in modules:
        info = run_module(m, cfg, outroot, mods_cfg)
        manifest["runs"].append(info)
        if info["status"] != "ok":
            rc = 1

    man_path = outroot / "run_manifest.json"
    man_path.write_text(json.dumps(manifest, indent=2))
    print(str(man_path))
    sys.exit(rc)

if __name__ == "__main__":
    main()
