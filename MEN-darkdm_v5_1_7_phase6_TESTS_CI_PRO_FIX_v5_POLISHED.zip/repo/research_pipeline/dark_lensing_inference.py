
import json, time, uuid, hashlib, pathlib
import numpy as np

REPO_ROOT = pathlib.Path(__file__).resolve().parents[1]
ART_DIR = REPO_ROOT / "artifacts" / "modules" / "dark_lensing_inference"
ART_DIR.mkdir(parents=True, exist_ok=True)

def grid_catalog(n=400, seed=3):
    rng = np.random.default_rng(seed)
    # fake "kappa" map with an injected hotspot
    size = 64
    grid = rng.normal(0,1,(size,size))
    x0,y0 = 40, 22
    for x in range(size):
        for y in range(size):
            r2 = (x-x0)**2 + (y-y0)**2
            grid[x,y] += 3.0*np.exp(-r2/30.0)
    return grid

def anomaly_zscore(grid):
    mu = grid.mean()
    sd = grid.std() + 1e-12
    z = (grid - mu)/sd
    maxloc = np.unravel_index(np.argmax(z), z.shape)
    return z, float(z[maxloc]), [int(maxloc[0]), int(maxloc[1])]

def main():
    t0 = time.time()
    grid = grid_catalog()
    zmap, zmax, loc = anomaly_zscore(grid)
    # Write artifact
    artifact = {"zmax": zmax, "loc": loc}
    (ART_DIR / "zmap.json").write_text(json.dumps(artifact, indent=2))
    p = float(math.exp(-0.5*zmax*zmax))  # Gaussian tail (approx two-sided not exact)
    res = {
        "module_name": "dark_lensing_inference",
        "status": "ok",
        "p_value": min(1.0, p*2.0),
        "false_alarm_probability": min(1.0, p*2.0),
        "empirical_trial_factor": 1.0,
        "constraints": {"zmax": zmax, "loc": loc},
        "figures": [],
        "artifacts": [str((ART_DIR/"zmap.json").relative_to(REPO_ROOT))],
        "metadata": {"data_release":"fixture","runtime_s": round(time.time()-t0,3),"code_version":"v1.0-planA"},
        "seed": 3,
        "data_hash": hashlib.sha256(b"fixture").hexdigest()[:16],
        "run_uuid": str(uuid.uuid4()),
        "provenance": {"env_hash":"local","config_hash":"local","data_sources":[]}
    }
    (ART_DIR / "result.json").write_text(json.dumps(res, indent=2))
    print("dark_lensing_inference: zmax=", zmax)

if __name__ == "__main__":
    import math
    main()
