# Thin shim preserved for backward-compatibility. Delegates to joint_meta_analysis.
import warnings
from research_pipeline.joint_meta_analysis import main as jma_main

if __name__ == "__main__":
    warnings.warn("research_pipeline.jma is deprecated; use research_pipeline.joint_meta_analysis", DeprecationWarning)
    jma_main()
