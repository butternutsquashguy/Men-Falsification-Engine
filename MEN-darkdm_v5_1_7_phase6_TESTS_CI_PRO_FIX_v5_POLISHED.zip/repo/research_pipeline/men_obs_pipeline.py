
import argparse, json, os, time, hashlib, uuid, sys, pathlib, random
from typing import List, Dict
import yaml

REPO_ROOT = pathlib.Path(__file__).resolve().parents[1]
ARTIFACTS = REPO_ROOT / "artifacts" / "modules"
SCHEMAS = REPO_ROOT / "schemas"

def _code_version():
    vfile = REPO_ROOT / "VERSION"
    try:
        return vfile.read_text().strip()
    except Exception:
        return "unknown"

DEFAULT_MODULES = [
    "sgwb_echo_module",
    "cmb_sgwb_correlation",
    "dark_lensing_inference",
    "lss_non_gaussian_mapper",
    "high_energy_burst_timing",
    "pbh_evaporation",
    "pbh_frb_lensing",
    "pbh_microlens_joint",
    "pbh_gw_popmix",
    "pbh_energy_injection",
]

def load_config(path: pathlib.Path) -> Dict:
    with open(path, "r") as f:
        cfg = yaml.safe_load(f)
    assert "modules" in cfg and isinstance(cfg["modules"], list), "config.yaml must have 'modules' list"
    assert "cache_dir" in cfg and "n_workers" in cfg, "config.yaml missing cache_dir or n_workers"
    return cfg

def env_hash() -> str:
    items = [sys.version, sys.executable]
    h = hashlib.sha256()
    for it in items:
        h.update(it.encode())
    return h.hexdigest()[:16]

def config_hash(cfg: Dict) -> str:
    h = hashlib.sha256(json.dumps(cfg, sort_keys=True).encode()).hexdigest()
    return h[:16]

def write_run_manifest(root: pathlib.Path, cfg: Dict, modules: List[str]):
    manifest = {
        "run_uuid": str(uuid.uuid4()),
        "code_version": _code_version(),
        "env_hash": env_hash(),
        "config_hash": config_hash(cfg),
        "data_sources": [],
        "modules": modules,
        "ts": time.time()
    }
    (root / "artifacts").mkdir(exist_ok=True, parents=True)
    with open(root / "artifacts" / "run_manifest.json", "w") as f:
        json.dump(manifest, f, indent=2)
    return manifest

def ensure_dir(p: pathlib.Path):
    p.mkdir(exist_ok=True, parents=True)

def skeleton_result(module_name: str, run_uuid: str) -> Dict:
    seed = random.randint(1, 1_000_000)
    random.seed(seed)
    pv = max(min(random.random() * 0.5, 1.0), 0.0)
    fap = pv
    res = {
        "module_name": module_name,
        "status": "ok",
        "p_value": pv,
        "false_alarm_probability": fap,
        "empirical_trial_factor": 1.0,
        "constraints": {},
        "figures": [],
        "artifacts": [],
        "metadata": {
            "data_release": "toy",
            "runtime_s": round(random.random(), 3),
            "code_version": _code_version()
        },
        "seed": seed,
        "data_hash": "placeholder",
        "run_uuid": run_uuid,
        "provenance": {
            "env_hash": env_hash(),
            "config_hash": "unknown",
            "data_sources": []
        }
    }
    return res

def cmd_list(args):
    modules = DEFAULT_MODULES
    print("\\n".join(modules))

def cmd_run(args):
    cfg_path = REPO_ROOT / "research_pipeline" / "config.yaml"
    if args.config:
        cfg_path = pathlib.Path(args.config)
    cfg = load_config(cfg_path)
    modules = DEFAULT_MODULES if args.name == "all" else [m.strip() for m in args.name.split(",")]
    write_run_manifest(REPO_ROOT, cfg, modules)
    for m in modules:
        out_dir = ARTIFACTS / m
        ensure_dir(out_dir)
        # try to execute module as a script
        mod_file = (REPO_ROOT / "research_pipeline" / f"{m}.py")
        if mod_file.exists():
            import subprocess, shlex
            cmd = f"{sys.executable} {mod_file}"
            proc = subprocess.run(shlex.split(cmd), cwd=str(REPO_ROOT), capture_output=True, text=True, timeout=300)
            if proc.returncode != 0:
                print(proc.stdout); print(proc.stderr, file=sys.stderr)
                raise SystemExit(proc.returncode)
            if proc.stdout.strip():
                print(proc.stdout.strip())
        else:
            # fallback to skeleton
            result = skeleton_result(m, run_uuid=str(uuid.uuid4()))
            result["provenance"]["config_hash"] = config_hash(cfg)
            out_file = out_dir / "result.json"
            with open(out_file, "w") as f:
                json.dump(result, f, indent=2)
            print(f"Wrote {out_file}")
    return 0

def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd")
    p_list = sub.add_parser("list", help="List modules")
    p_list.set_defaults(func=cmd_list)

    p_run = sub.add_parser("run", help="Run modules")
    p_run.add_argument("name", help="'all' or comma-separated module names")
    p_run.add_argument("--config", help="Path to config.yaml", default=None)
    p_run.set_defaults(func=cmd_run)

    args = parser.parse_args()
    if not args.cmd:
        parser.print_help()
        return 1
    return args.func(args)

if __name__ == "__main__":
    raise SystemExit(main())
