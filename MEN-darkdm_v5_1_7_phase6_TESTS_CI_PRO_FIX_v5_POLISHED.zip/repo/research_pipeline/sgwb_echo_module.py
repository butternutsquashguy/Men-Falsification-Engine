"""Patched SGWB echo module adding coherent stacking + envelope fit.
This is a drop-in replacement; it will use precomputed correlation traces if available.
"""
import json, os, numpy as np
from .stacking.stacker import stack_timeseries
from .stacking.envelopes import EchoEnvelope
from .stacking.baselines import RingdownBaseline
from .hierarchical_fit import Dataset, fit_joint
from .stacking.finite_n import finite_n_sem

def run(input_dir, out_json, meta=None):
    """Run stacked echo fit.
    Expects .npy files in input_dir: timeseries traces of same length; optional t.npy time grid.
    """
    files = sorted([f for f in os.listdir(input_dir) if f.endswith('.npy') and f != 't.npy'])
    if not files:
        raise FileNotFoundError(f"No .npy traces found in {input_dir}")
    traces = [np.load(os.path.join(input_dir, f)) for f in files]
    t_path = os.path.join(input_dir, 't.npy')
    t = np.load(t_path) if os.path.exists(t_path) else None

    stack_mean, stack_sem, n, t = stack_timeseries(traces, t=t, normalize='zscore', align='peak')
    # Fit baseline * envelope on a single stacked dataset via hierarchical_fit with one dataset
    x = np.linspace(50, 400, stack_mean.size)  # frequency-like axis (toy mapping)
    y = np.abs(np.fft.rfft(stack_mean, n=stack_mean.size*2))[:x.size]  # toy spectrum
    sigma = np.maximum(np.abs(np.fft.rfft(stack_sem, n=stack_sem.size*2))[:x.size], 1e-9)

    baseline = RingdownBaseline()
    envelope = EchoEnvelope()
    ds = [Dataset(x=x, y=y, sigma=sigma, nuis_scale=1.0)]
    init_params = dict(depth=0.1, f0=150.0, alpha=3.0, a0=1.0, fp=100.0, q=1.0, fc=300.0)
    init_nuis = [1.0]
    fit = fit_joint(ds, baseline, envelope, init_params, init_nuis, priors=None)

    finite_sem = {k: float(finite_n_sem(0.1, n)) for k in ['depth','f0','alpha']}  # toy finite-N

    result = {
        "module_name": "sgwb_echo_module",
        "status": "ok" if fit["success"] else "error",
        "p_value": 1.0,  # placeholder; compute via null sims in full pipeline
        "false_alarm_probability": 1.0,
        "empirical_trial_factor": 1.0,
        "constraints": {},
        "figures": [],
        "artifacts": [],
        "metadata": {
            "data_release": "synthetic",
            "runtime_s": 0.0,
            "code_version": "patch-v0.1"
        },
        "seed": 0,
        "data_hash": "",
        "run_uuid": "",
        "provenance": {"env_hash": "", "config_hash": "", "data_sources": []},
        "envelope": {
            "name": "EchoEnvelope",
            "params": fit["params"],
            "cov": fit["cov"],
            "finite_n_sem": finite_sem
        }
    }
    with open(out_json, "w") as f:
        json.dump(result, f, indent=2)
    return result

if __name__ == "__main__":
    # mini self-test: generate synthetic traces
    tmp = os.path.join(os.path.dirname(__file__), "..", "examples", "mini_demo", "sgwb_traces")
    os.makedirs(tmp, exist_ok=True)
    L = 1024
    t = np.linspace(-0.5, 0.5, L)
    for i in range(16):
        x = np.exp(-((t - 0.0)/0.05)**2) * np.cos(2*np.pi*160*t) + 0.2*np.random.normal(size=L)
        np.save(os.path.join(tmp, f"trace_{i:02d}.npy"), x.astype(np.float32))
    np.save(os.path.join(tmp, "t.npy"), t.astype(np.float32))
    out = os.path.join(os.path.dirname(__file__), "..", "examples", "mini_demo", "sgwb_fit.json")
    print(run(tmp, out))
