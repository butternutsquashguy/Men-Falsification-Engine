"""Patched LSS non-Gaussian mapper with optional patch-stacking + envelope overlay."""
import json, os, numpy as np
from .stacking.stacker import stack_spectra
from .stacking.envelopes import PowerEnvelope
import warnings

def run(input_dir, out_json, meta=None):
    """Expects CSV files in input_dir with columns: k, Pk for multiple patches."""
    files = sorted([f for f in os.listdir(input_dir) if f.endswith('.csv')])
    if not files:
        raise FileNotFoundError(f"No CSV spectra found in {input_dir}")
    ks, spectra = None, []
    for f in files:
        arr = np.loadtxt(os.path.join(input_dir, f), delimiter=',', skiprows=1)
        if ks is None:
            ks = arr[:,0]
        spectra.append(arr[:,1])
    m, sem, n = stack_spectra(spectra, weights=None, logspace=True)
    env = PowerEnvelope()
    envelope_vals = env(ks)
    # simple JSON (augment your existing output in real pipeline)
    result = {
        "module_name": "lss_non_gaussian_mapper",
        "status": "ok",
        "p_value": 1.0,
        "false_alarm_probability": 1.0,
        "empirical_trial_factor": 1.0,
        "constraints": {},
        "figures": [],
        "artifacts": [],
        "metadata": {"data_release": "synthetic", "runtime_s": 0.0, "code_version": "patch-v0.1"},
        "seed": 0, "data_hash": "", "run_uuid": "",
        "provenance": {"env_hash":"", "config_hash":"", "data_sources":[]},
        "envelope": {
            "name": "PowerEnvelope",
            "params": {"A": env.A, "k0": env.k0, "s": env.s, "beta": env.beta}
        }
    }
    with open(out_json, "w") as f:
        json.dump(result, f, indent=2)
    return result
