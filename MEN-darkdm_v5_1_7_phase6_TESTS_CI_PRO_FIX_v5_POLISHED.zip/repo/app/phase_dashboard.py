
import json, pathlib
import streamlit as st

st.set_page_config(page_title="MEN Pipeline Dashboard", layout="wide")
st.title("MEN Pipeline — Phase 2 & 3 Results")

ROOT = pathlib.Path(__file__).resolve().parents[1]
schema_path = ROOT/"schemas"/"results.schema.json"

def show_result(label, json_path):
    st.subheader(label)
    p = ROOT/json_path
    if not p.exists():
        st.info(f"Missing: {json_path}")
        return
    data = json.loads(p.read_text())
    cols = st.columns(3)
    with cols[0]: st.json({"module": data.get("module"), "version": data.get("version"), "timestamp": data.get("timestamp")})
    with cols[1]: st.json({"inputs": data.get("inputs")})
    with cols[2]: st.json({"metrics": data.get("metrics")})
    figs = data.get("figures", [])
    for f in figs:
        fp = ROOT/f
        if fp.exists() and fp.suffix.lower() in [".png", ".jpg", ".jpeg", ".webp"]:
            st.image(str(fp), caption=f)

st.header("Phase 2")
show_result("SGWB Echoes", "artifacts/sgwb/result.json")
show_result("CMB Correlation", "artifacts/cmb_correlation/result.json")
show_result("Lensing (Strong/Weak)", "artifacts/lensing/result.json")
show_result("Non-Gaussian Mapper", "artifacts/non_gauss/result.json")
show_result("HE Burst Timing", "artifacts/he_burst/result.json")

st.header("Phase 3")
show_result("PBH Evaporation", "artifacts/pbh_evaporation/result.json")
show_result("PBH FRB Lensing", "artifacts/pbh_frb_lensing/result.json")
show_result("PBH Microlensing", "artifacts/pbh_microlensing/result.json")
show_result("PBH GW Population Mix", "artifacts/pbh_gw_population/result.json")
show_result("PBH Energy Injection", "artifacts/pbh_energy_injection/result.json")
