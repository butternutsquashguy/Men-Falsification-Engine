import os, json, numpy as np
from research_pipeline.sgwb_echo_module import run as run_sgwb

here = os.path.dirname(__file__)
tr_dir = os.path.join(here, "sgwb_traces")
os.makedirs(tr_dir, exist_ok=True)

# generate synthetic traces if none present
L = 1024
t = np.linspace(-0.5, 0.5, L)
if not any(f.endswith('.npy') for f in os.listdir(tr_dir)):
    for i in range(12):
        x = np.exp(-((t - 0.0)/0.05)**2) * np.cos(2*np.pi*160*t) + 0.2*np.random.normal(size=L)
        np.save(os.path.join(tr_dir, f"trace_{i:02d}.npy"), x.astype(np.float32))
    np.save(os.path.join(tr_dir, "t.npy"), t.astype(np.float32))

out_json = os.path.join(here, "sgwb_fit.json")
res = run_sgwb(tr_dir, out_json)
print(json.dumps(res, indent=2)[:800])
print("\nWrote:", out_json)
