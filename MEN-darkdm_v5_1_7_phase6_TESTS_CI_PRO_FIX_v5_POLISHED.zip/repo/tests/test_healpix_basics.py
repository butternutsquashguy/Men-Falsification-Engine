import pytest
import numpy as np
hp = pytest.importorskip('healpy')

@pytest.mark.heavy
def test_udgrade_roundtrip():
    nside = 8
    cl = [1.0]*(3*nside)
    m = hp.synfast(cl=cl, nside=nside, lmax=3*nside-1, new=True, verbose=False)
    hi = hp.ud_grade(m, nside_out=32, order_in='RING', order_out='RING')
    lo = hp.ud_grade(hi, nside_out=nside, order_in='RING', order_out='RING')
    corr = np.corrcoef(m, lo)[0,1]
    assert corr > 0.95