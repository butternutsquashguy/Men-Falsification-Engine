import numpy as np
from research_pipeline.stacking.stacker import stack_timeseries, stack_spectra, stack_cl
from research_pipeline.stacking.envelopes import EchoEnvelope, PowerEnvelope
from research_pipeline.stacking.baselines import RingdownBaseline, LCDMTiltBaseline
from research_pipeline.stacking.finite_n import finite_n_sem, bootstrap_sem

def test_stacker_timeseries():
    rng = np.random.default_rng(0)
    L, N = 256, 8
    t = np.linspace(-1, 1, L)
    traces = [np.exp(-((t)/0.1)**2) + 0.1*rng.normal(size=L) for _ in range(N)]
    m, sem, n, _ = stack_timeseries(traces, t=t, normalize='zscore', align='peak')
    assert n == N
    assert m.shape[0] == L

def test_envelopes_baselines():
    f = np.linspace(10, 300, 200)
    env = EchoEnvelope()(f)
    base = RingdownBaseline()(f)
    assert env.shape == f.shape
    assert base.shape == f.shape
    k = np.linspace(1, 1000, 200)
    pe = PowerEnvelope()(k)
    lb = LCDMTiltBaseline()(k)
    assert pe.shape == k.shape
    assert lb.shape == k.shape

def test_finite_n():
    assert np.isclose(finite_n_sem(1.0, 4), 0.5)
    x = np.arange(10.0)
    s = bootstrap_sem(x, n_boot=128, rng=42)
    assert s >= 0.0
