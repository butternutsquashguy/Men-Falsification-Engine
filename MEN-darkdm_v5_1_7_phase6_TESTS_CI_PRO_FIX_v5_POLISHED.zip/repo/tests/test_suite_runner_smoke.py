
from pathlib import Path
import json, subprocess, sys

def test_suite_runner_smoke(tmp_path):
    suite_path = Path("suites/smoke_fast.yaml")
    assert suite_path.exists(), "smoke suite file missing"
    outdir = tmp_path / "suite_run"
    outdir.mkdir(parents=True, exist_ok=True)
    # run suite
    rc = subprocess.call([sys.executable, "research_pipeline/suite_runner.py", "--suite", str(suite_path), "--out", str(outdir)])
    assert rc == 0, "suite_runner returned non-zero"
    man = outdir / "run_manifest.json"
    assert man.exists(), "run_manifest.json missing"
    data = json.loads(man.read_text())
    assert "runs" in data and len(data["runs"]) >= 1
