from plugins.base import load_plugin

def test_load_qds_plugin():
    p = load_plugin("plugins.qds")
    assert hasattr(p, "enumerate_jobs")
    assert hasattr(p, "evaluate")