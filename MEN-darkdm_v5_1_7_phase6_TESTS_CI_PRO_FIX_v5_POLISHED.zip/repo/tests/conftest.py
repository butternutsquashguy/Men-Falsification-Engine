
import os
import pytest

@pytest.fixture(autouse=True)
def _disable_network(monkeypatch):
    # Default tests use fixtures; modules may still read local files
    monkeypatch.setenv("MEN_ALLOW_NETWORK", "0")
