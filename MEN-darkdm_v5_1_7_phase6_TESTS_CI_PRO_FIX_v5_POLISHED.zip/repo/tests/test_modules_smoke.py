
from pathlib import Path
import json

def _assert_result_json(path):
    p = Path(path)
    assert p.exists(), "result.json path returned must exist"
    data = json.loads(p.read_text())
    # minimal schema keys
    for k in ["module_name","status","p_value","false_alarm_probability","figures","provenance"]:
        assert k in data, f"Missing key: {k}"
    # figure files (at least 1)
    figs = data.get("figures") or []
    assert isinstance(figs, list) and len(figs) >= 1

def test_pbh_evaporation_search(tmp_path):
    from research_pipeline.modules import pbh_evaporation_search as mod
    cfg = {"use_real_data": False, "module_name": "pbh_evaporation_search"}
    out = mod.run(cfg, str(tmp_path))
    _assert_result_json(out)

def test_pbh_frb_lensing(tmp_path):
    from research_pipeline.modules import pbh_frb_lensing as mod
    cfg = {"use_real_data": False, "module_name": "pbh_frb_lensing"}
    out = mod.run(cfg, str(tmp_path))
    _assert_result_json(out)

def test_pbh_microlens_joint(tmp_path):
    from research_pipeline.modules import pbh_microlens_joint as mod
    cfg = {"use_real_data": False, "module_name": "pbh_microlens_joint"}
    out = mod.run(cfg, str(tmp_path))
    _assert_result_json(out)

def test_pbh_gw_popmix(tmp_path):
    from research_pipeline.modules import pbh_gw_popmix as mod
    cfg = {"use_real_data": False, "module_name": "pbh_gw_popmix"}
    out = mod.run(cfg, str(tmp_path))
    _assert_result_json(out)

def test_pbh_energy_injection(tmp_path):
    from research_pipeline.modules import pbh_energy_injection as mod
    cfg = {"use_real_data": False, "module_name": "pbh_energy_injection"}
    out = mod.run(cfg, str(tmp_path))
    _assert_result_json(out)
