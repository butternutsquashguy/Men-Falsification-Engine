
import os, subprocess, sys, json, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]

def run(cmd):
    print(">>>", " ".join(cmd))
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    print(r.stdout)
    if r.returncode != 0:
        print(r.stderr)
        raise SystemExit(r.returncode)

def test_sgwb():
    run([sys.executable, "scripts/sgwb_echoes.py", "--output_json", "artifacts/sgwb/result.json"])
    run([sys.executable, "scripts/validate_json.py", "--schema", "schemas/results.schema.json", "--json", "artifacts/sgwb/result.json"])

def test_cmb():
    run([sys.executable, "scripts/cmb_correlation.py", "--output_json", "artifacts/cmb_correlation/result.json"])
    run([sys.executable, "scripts/validate_json.py", "--schema", "schemas/results.schema.json", "--json", "artifacts/cmb_correlation/result.json"])

def test_lensing():
    run([sys.executable, "scripts/lensing_module.py", "--output_json", "artifacts/lensing/result.json"])
    run([sys.executable, "scripts/validate_json.py", "--schema", "schemas/results.schema.json", "--json", "artifacts/lensing/result.json"])

def test_nongauss():
    run([sys.executable, "scripts/nongauss_mapper.py", "--output_json", "artifacts/non_gauss/result.json"])
    run([sys.executable, "scripts/validate_json.py", "--schema", "schemas/results.schema.json", "--json", "artifacts/non_gauss/result.json"])

def test_heburst():
    run([sys.executable, "scripts/he_burst_timing.py", "--output_json", "artifacts/he_burst/result.json"])
    run([sys.executable, "scripts/validate_json.py", "--schema", "schemas/results.schema.json", "--json", "artifacts/he_burst/result.json"])

if __name__ == "__main__":
    test_sgwb()
    test_cmb()
    test_lensing()
    test_nongauss()
    test_heburst()
    print("ALL TESTS PASSED")
