
import os, subprocess, sys, json, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
def run(cmd):
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    print(r.stdout)
    if r.returncode != 0:
        print(r.stderr)
        raise SystemExit(r.returncode)
def test_evap():
    run([sys.executable, "scripts/pbh_evaporation.py", "--output_json", "artifacts/pbh_evaporation/result.json"])
    run([sys.executable, "scripts/validate_json.py", "--schema", "schemas/results.schema.json", "--json", "artifacts/pbh_evaporation/result.json"])
def test_frb():
    run([sys.executable, "scripts/pbh_frb_lensing.py", "--output_json", "artifacts/pbh_frb_lensing/result.json"])
    run([sys.executable, "scripts/validate_json.py", "--schema", "schemas/results.schema.json", "--json", "artifacts/pbh_frb_lensing/result.json"])
def test_micro():
    run([sys.executable, "scripts/pbh_microlensing.py", "--output_json", "artifacts/pbh_microlensing/result.json"])
    run([sys.executable, "scripts/validate_json.py", "--schema", "schemas/results.schema.json", "--json", "artifacts/pbh_microlensing/result.json"])
def test_gw():
    run([sys.executable, "scripts/pbh_gw_population.py", "--output_json", "artifacts/pbh_gw_population/result.json"])
    run([sys.executable, "scripts/validate_json.py", "--schema", "schemas/results.schema.json", "--json", "artifacts/pbh_gw_population/result.json"])
def test_energy():
    run([sys.executable, "scripts/pbh_energy_injection.py", "--output_json", "artifacts/pbh_energy_injection/result.json"])
    run([sys.executable, "scripts/validate_json.py", "--schema", "schemas/results.schema.json", "--json", "artifacts/pbh_energy_injection/result.json"])
if __name__ == "__main__":
    test_evap(); test_frb(); test_micro(); test_gw(); test_energy(); print("PHASE 3 TESTS PASSED")

# end
