## Experiment Registry (SYSGP-RPE ready)

List, inspect, and run by name:

```bash
python scripts/men_registry.py list
python scripts/men_registry.py info dark_dm_sweeps
python scripts/men_registry.py run dark_dm_sweeps
```
### Environment setup

**Option A – pip (quick, may fail on native deps):**
```bash
python -m venv .venv && source .venv/bin/activate  # or .venv\Scripts\activate on Windows
pip install -r requirements-full.txt
```

**Option B – conda (recommended for heavy native deps like cartopy/healpy):**
```bash
mamba env create -f environment-astro.yml   # or: conda env create -f environment-astro.yml
conda activate men-astro
```

> Note: `pycbc`, `gwpy`, and mapping libs can be finicky on pip-only environments. Prefer conda-forge for reliability.


### Run directly from hyperpriors (no manual grids)
```bash
python scripts/men_registry.py run dark_dm_from_priors_v4
# or explicitly:
python scripts/run_men_experiment.py --from-priors priors/men_hyperpriors_merged_v4.json --grid preferred
```
