#!/usr/bin/env python3
import argparse, json
from pathlib import Path
def deep_merge(a, b):
    for k,v in b.items():
        if k in a and isinstance(a[k], dict) and isinstance(v, dict):
            deep_merge(a[k], v)
        else:
            a[k] = v
    return a
def main():
    ap = argparse.ArgumentParser(description="Merge multiple JSON files into one dict.")
    ap.add_argument("--out", required=True)
    ap.add_argument("inputs", nargs="+")
    a = ap.parse_args()
    acc = {}
    for p in a.inputs:
        with open(p, "r") as f:
            acc = deep_merge(acc, json.load(f))
    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    with open(a.out, "w") as f:
        json.dump(acc, f, indent=2)
    print("Wrote", a.out)
if __name__ == "__main__":
    main()
