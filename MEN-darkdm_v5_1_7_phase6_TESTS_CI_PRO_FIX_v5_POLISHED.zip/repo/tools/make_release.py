#!/usr/bin/env python3
print("Run locally to package release zip.")
