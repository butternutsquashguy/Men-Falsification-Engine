from __future__ import annotations
import json, sys, platform, random
from typing import Mapping, Any
from datetime import datetime
from pathlib import Path
import numpy as np
from plugins.base import load_plugin, JobSpec, Result

def _collect_env():
    try:
        import pkg_resources
        pkgs = {d.project_name: d.version for d in pkg_resources.working_set}
    except Exception:
        pkgs = {}
    return {
        "python": sys.version,
        "platform": platform.platform(),
        "time_utc": datetime.utcnow().isoformat() + "Z",
        "packages": pkgs,
    }

def _write_manifest(outdir: Path, meta):
    outdir.mkdir(parents=True, exist_ok=True)
    with open(outdir / "run_manifest.json", "w") as f:
        json.dump(meta, f, indent=2, sort_keys=True)

def run(plugin_ref: str,
        priors: Mapping[str, Any],
        outdir: str,
        seed: int = 42,
        dry_run: bool = False):
    random.seed(seed); np.random.seed(seed)
    p = load_plugin(plugin_ref)

    outdir_p = Path(outdir)
    env = _collect_env()
    manifest = {
        "plugin": getattr(p, "name", plugin_ref),
        "plugin_ref": plugin_ref,
        "priors": priors,
        "seed": seed,
        "env": env,
    }
    _write_manifest(outdir_p, manifest)

    rows = []
    for idx, job in enumerate(p.enumerate_jobs(priors or {})):
        row = {"job_index": idx, "job": dict(job.params)}
        if dry_run:
            row["dry_run"] = True
        else:
            try:
                res: Result = p.evaluate(job, resources={"outdir": str(outdir_p)})
            except TypeError:
                res: Result = p.evaluate(job)
            row["metrics"] = dict(getattr(res, "metrics", {}) or {})
            row["info"] = dict(getattr(res, "info", {}) or {})
        rows.append(row)

    with open(outdir_p / "results.jsonl", "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")
    return len(rows)