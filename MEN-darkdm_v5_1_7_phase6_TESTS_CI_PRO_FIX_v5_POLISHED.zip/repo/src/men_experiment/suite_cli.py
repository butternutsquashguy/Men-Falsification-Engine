
import click, json
from men_experiment.suite import run_suite

@click.command()
@click.option("--suite", "suite_config", required=True, type=click.Path(exists=True), help="JSON suite config file")
@click.option("--outdir", required=True, type=str, help="Output directory for combined results")
@click.option("--seed", default=42, type=int)
@click.option("--dry-run", is_flag=True, default=False)
def main(suite_config, outdir, seed, dry_run):
    stats = run_suite(suite_config, outdir, seed=seed, dry_run=dry_run)
    click.echo(json.dumps(stats))
