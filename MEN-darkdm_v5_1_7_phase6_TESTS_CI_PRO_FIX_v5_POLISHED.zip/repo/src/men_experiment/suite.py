
from __future__ import annotations
import json, os
from pathlib import Path
from typing import List, Dict, Any, Optional
from men_experiment.runner import run as run_single

def _load_json(p: Path) -> Dict[str, Any]:
    with open(p, "r") as f:
        return json.load(f)

def _read_jsonl(p: Path):
    rows = []
    if not p.exists():
        return rows
    with open(p, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                pass
    return rows

def _write_jsonl(p: Path, rows: List[Dict[str, Any]]):
    with open(p, "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")

def _write_csv(p: Path, rows: List[Dict[str, Any]]):
    # flatten metrics + plugin label
    if not rows:
        with open(p, "w") as f:
            f.write("")
        return
    # collect keys
    fieldnames = set(["plugin", "job_index"])
    for r in rows:
        fieldnames.update([f"m:{k}" for k in (r.get("metrics", {}) or {}).keys()])
    fieldnames = sorted(fieldnames)
    import csv
    with open(p, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        for r in rows:
            row = {"plugin": r.get("plugin"), "job_index": r.get("job_index")}
            for k, v in (r.get("metrics", {}) or {}).items():
                row[f"m:{k}"] = v
            w.writerow(row)

def run_suite(suite_config: str, outdir: str, seed: int = 42, dry_run: bool = False) -> Dict[str, Any]:
    """
    suite_config (JSON file) format:
    {
      "runs": [
        {"plugin": "plugins.stochastic_field", "priors": "priors/stochastic_field_demo.json"},
        {"plugin": "plugins.tensor_network",   "priors": "priors/tensor_network_demo.json"},
        ...
      ]
    }
    """
    outdir_p = Path(outdir); outdir_p.mkdir(parents=True, exist_ok=True)
    conf = _load_json(Path(suite_config))
    runs = conf.get("runs", [])
    combined_rows = []
    manifest = {"suite_config": suite_config, "seed": seed, "dry_run": dry_run, "entries": []}

    for entry in runs:
        plugin_ref = entry["plugin"]
        priors_path = entry.get("priors")
        pri = _load_json(Path(priors_path)) if priors_path else {}
        sub_out = outdir_p / plugin_ref.split(".")[-1]
        sub_out.mkdir(parents=True, exist_ok=True)

        n = run_single(plugin_ref, pri, str(sub_out), seed=seed, dry_run=dry_run)
        # Load the sub results and annotate
        res_path = sub_out / "results.jsonl"
        rows = _read_jsonl(res_path) if res_path.exists() else []
        for r in rows:
            r["plugin"] = plugin_ref.split(".")[-1]
        combined_rows.extend(rows)
        manifest["entries"].append({"plugin": plugin_ref, "priors": priors_path, "outdir": str(sub_out), "jobs": n})

    # Write combined outputs
    _write_jsonl(outdir_p / "suite_results.jsonl", combined_rows)
    _write_csv(outdir_p / "suite_summary.csv", combined_rows)
    with open(outdir_p / "suite_manifest.json", "w") as f:
        json.dump(manifest, f, indent=2, sort_keys=True)
    return {"jobs_total": len(combined_rows), "plugins": len(runs), "outdir": str(outdir_p)}
