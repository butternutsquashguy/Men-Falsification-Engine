import json, click
from men_experiment.runner import run

@click.command()
@click.option("--plugin", "plugin_ref", required=True, help="e.g. plugins.qds or plugins.dbbh:PluginImpl")
@click.option("--priors", type=click.Path(exists=True), required=False, help="JSON file of prior settings")
@click.option("--outdir", type=str, default="runs/latest")
@click.option("--seed", type=int, default=42)
@click.option("--dry-run", is_flag=True, default=False)
def main(plugin_ref, priors, outdir, seed, dry_run):
    pri = {}
    if priors:
        with open(priors) as f:
            pri = json.load(f)
    n = run(plugin_ref, pri, outdir, seed=seed, dry_run=dry_run)
    click.echo(f"[men-experiment] {n} jobs processed → {outdir}")