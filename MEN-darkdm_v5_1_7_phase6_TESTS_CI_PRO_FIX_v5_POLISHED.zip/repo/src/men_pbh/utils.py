
"""
men_pbh.utils - shared helpers for PBH modules (toy implementations).
"""
from __future__ import annotations
import numpy as np

def log_uniform(min_val: float, max_val: float, size: int, rng=None):
    rng = rng or np.random.default_rng()
    u = rng.uniform(0,1,size)
    return np.exp(np.log(min_val) + u * (np.log(max_val)-np.log(min_val)))

def simple_histogram(x, bins=30):
    import numpy as np
    hist, edges = np.histogram(x, bins=bins)
    centers = 0.5*(edges[1:]+edges[:-1])
    return centers.tolist(), hist.tolist()
