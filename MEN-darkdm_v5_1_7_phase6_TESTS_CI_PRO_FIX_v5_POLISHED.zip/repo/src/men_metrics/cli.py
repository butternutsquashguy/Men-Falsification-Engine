import click
@click.command()
def main():
    click.echo("men-metrics placeholder CLI (implement metrics here).")
