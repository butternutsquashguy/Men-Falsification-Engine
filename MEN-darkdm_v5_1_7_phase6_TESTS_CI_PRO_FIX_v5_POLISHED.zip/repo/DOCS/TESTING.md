
# Testing & Quality (Phase 6)

## Local
```bash
# run full unit + smoke tests
make test

# fast smoke-only (fixtures; no network)
make test-smoke

# style
make lint
make format

# coverage
make coverage
```

CI runs lint, unit tests, smoke suite, and daily real-slice suite. Coverage artifact is uploaded per run.
