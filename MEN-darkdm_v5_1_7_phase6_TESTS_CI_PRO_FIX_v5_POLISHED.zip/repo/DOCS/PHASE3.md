
# Phase 3 — PBH Modules (Alpha)

This phase introduces five PBH-related analyses, each producing schema-compliant JSON + at least one figure:

- `pbh_evaporation.py` — toy PBH lifetime fractions and mass histogram.
- `pbh_frb_lensing.py` — toy FRB delay histogram and lensed-event rate proxy.
- `pbh_microlensing.py` — toy microlensing duration distribution and long-event fraction.
- `pbh_gw_population.py` — toy GW mass mixture and bimodality proxy.
- `pbh_energy_injection.py` — toy Compton-y proxy vs PBH fraction.

Run:
```bash
make phase3
python tests/test_phase3.py
```

Replace toy numerics with real estimators and datasets in production. All outputs adhere to `schemas/results.schema.json`.


## Suite Runner
Run all PBH modules and write a manifest:
```bash
python scripts/run_phase3_suite.py
```

## Dashboard
Preview Phase 2 + 3 results:
```bash
streamlit run app/phase_dashboard.py
```
