

## Quick Start: Fetch pinned slices & run
```bash
pip install requests pandas scipy
make fetch-fermi-gbm
make fetch-frb
make fetch-lvk
make fetch-planck
make run-obs-all
```


## Suites (Phase 5)
```bash
make run-suite-pbh      # real-slice suite
make run-suite-smoke    # fast fixtures suite
make jma-modules        # aggregate per-module outputs
make jma-latest         # aggregate most recent suite run
```
