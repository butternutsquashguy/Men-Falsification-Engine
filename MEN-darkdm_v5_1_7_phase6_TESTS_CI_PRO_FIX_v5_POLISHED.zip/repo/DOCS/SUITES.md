
# Suites & Orchestration (Phase 5)

## Running a suite
```bash
python research_pipeline/suite_runner.py --suite suites/pbh_minimal.yaml
# or
make run-suite-pbh
```

## Fast smoke test (fixtures only)
```bash
make run-suite-smoke
```

## Joint Meta-Analysis (JMA)
Aggregate outputs (either from `artifacts/modules` or a suite run dir) into a single summary:
```bash
make jma-modules      # aggregates the current per-module outputs
make jma-latest       # aggregates the most recent suite run
```
Artifacts include `jma_summary.json` and `jma_summary.md`.
