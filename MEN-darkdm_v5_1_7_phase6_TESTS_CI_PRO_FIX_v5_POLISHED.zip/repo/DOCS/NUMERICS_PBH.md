
# Phase 3 PBH Numerics (Current Implementation Notes)

These notes document the toy numerics used in Phase 3 (alpha → complete). Replace with physical estimators as data become available.

## PBH Evaporation
- Draw PBH masses log-uniform in [1e14, 1e18] g (toy).
- Lifetime proxy: τ ∝ M³ (scaled with arbitrary constant to set scale).
- Metric: fraction with τ < H₀⁻¹; histogram of log10(M).

## FRB Lensing
- Sample delays from exponential distribution.
- Define "lensed" proxy as delays > 0.1 s for demonstration.
- Metric: lensed-event rate; delay histogram.

## Microlensing
- Event duration t_E drawn from lognormal.
- Metric: fraction with t_E > 10 days (toy long tail); histogram of log10 t_E.

## GW Population Mix
- Mixture of Gaussian stellar-BH masses and log-uniform PBH-like component.
- Metric: simple bimodality proxy (σ / μ); histogram of masses.

## PBH Energy Injection
- Random PBH DM fraction f_PBH ∈ [0,0.05] (toy).
- y-proxy = 1e-6 + 5e-6 f_PBH.

### Output Contract
Each module writes JSON adhering to `schemas/results.schema.json`, and at least one PNG figure for quick inspection.
