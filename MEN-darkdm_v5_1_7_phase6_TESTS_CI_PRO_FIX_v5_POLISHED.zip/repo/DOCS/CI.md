
# Continuous Integration (Phase 5)

This repo ships a GitHub Actions workflow that runs automatically:

- **Smoke (fixtures)** on every push/PR to `main`/`master`.
- **Real-slice suite** (`pbh_minimal`) daily at 06:00 UTC and on push/PRs (after smoke).

Artifacts (suite outputs + JMA summaries) are uploaded under the workflow run.

### Local parity
```bash
# Same as CI jobs
make ci-smoke
make ci-realslice
```
