
# NUMERICS (Phase 4 Finished — Toy Analyses)

Each PBH module below runs on tiny offline fixtures under `tests/data/phase4/`, emits a schema-compliant `result.json`, and at least one diagnostic figure. These toy computations are placeholders designed to exercise the orchestration, JSON schema, and plotting.

## pbh_evaporation_search
- **Method (toy):** Uses Poisson 90% CL upper limit (2.3 events) with exposure and sky fraction to derive a rate upper limit. Converts to a toy constraint on `f_PBH(M)` assuming an arbitrary scaling.
- **Figures:** `rate_ul_vs_mass.png`
- **Fixture:** `fermi_gbm_lat_tiny.json` with `exposure_s`, `sky_fraction`, and `events`.
- **Validation:** Emits `p_value` and `false_alarm_probability` from background=0 assumption.

## pbh_frb_lensing
- **Method (toy):** Scans FRB MJDs for near-duplicate arrivals (Δt within small window) as lensing candidates; none expected in the toy set. Builds a simple null exclusion curve.
- **Figures:** `frb_exclusion.png`
- **Fixture:** `chime_frb_tiny.json`.

## pbh_microlens_joint
- **Method (toy):** Computes a simple matched-bump statistic on a synthetic OGLE lightcurve; compares to a null to produce a toy posterior and a constraint summary.
- **Figures:** `microlens_bump.png`
- **Fixtures:** `ogle_lightcurve_tiny.csv`, `gaia_astrometry_tiny.json`.

## pbh_gw_popmix
- **Method (toy):** Fits a two-component mixture (broad + narrow) to LVK masses via moment matching; reports a "PBH-like" narrow fraction with uncertainty from bootstrap.
- **Figures:** `mass_hist_mix.png`
- **Fixture:** `lvk_catalog_tiny.json`.

## pbh_energy_injection
- **Method (toy):** Converts Planck residual power into a mock bound curve for energy injection vs. redshift bin index.
- **Figures:** `energy_injection_forecast.png`
- **Fixture:** `planck_residuals_tiny.json`.

**Note:** These are not scientific results; they are scaffolds to confirm plumbing and outputs per Phase 4's definition of done.


---

## Real-data slice notes (Phase 4 conversion)
- **FRB Lensing** now attempts to load a small **CHIME/FRB Catalog** CSV (via chime-frb.ca or open-data mirrors) and converts a tiny slice to the module’s JSON format.
- **GW Population Mix** now pulls **GWOSC** `/eventapi/json/allevents/` and extracts component masses when present.
- **Energy Injection** pulls **Planck 2018 TT power spectrum** ASCII from IRSA and builds a crude residual proxy.
- **Evaporation (GBM)** issues a small **HEASARC TAP** sync query against `fermigbrst` and uses the row count as observed burst events for a toy rate limit.
- **Microlensing** currently retains fixtures; a real-data fetcher for OGLE+Gaia will be wired in Phase 4.1 or Phase 5, subject to a stable tiny endpoint.

Each module still falls back gracefully to the previous fixtures when `use_real_data: false` or on fetch failure.
