# Quick Start (MEN-OBS Stacking + Envelope Patch)

## TL;DR
1. Unzip at repo root.
2. Run the mini demo:
   ```bash
   python examples/mini_demo/run_mini_demo.py
   ```
3. Optional: run smoke tests:
   ```bash
   python -m pytest tests/test_stacking.py -q
   ```

## What this adds
- **Stack-first** processing for SGWB/CMB/LSS
- **Baseline × Envelope** modeling
- **Systematics** injection into fits
- **Finite-N** error bars
- **Hierarchical** stacked likelihood with per-dataset nuisances
