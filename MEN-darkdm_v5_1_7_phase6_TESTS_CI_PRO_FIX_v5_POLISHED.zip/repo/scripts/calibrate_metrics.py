#!/usr/bin/env python3
import argparse, json, numpy as np
from pathlib import Path
def two_sided_p(arr, val):
    arr = np.asarray(arr, float)
    if arr.size==0 or not np.isfinite(val): return float("nan")
    mu = np.nanmean(arr); sigma = np.nanstd(arr)+1e-12
    rank = np.sum(np.abs(arr-mu) >= abs(val-mu))
    return float(rank/arr.size)
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cal", required=True)
    ap.add_argument("--metrics", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    cal = np.load(a.cal)
    obs = json.loads(Path(a.metrics).read_text())
    out = {}
    if "A" in obs and "observed_tail_rate" in obs["A"]:
        out["A_tail_p"] = two_sided_p(cal["A_tail"], obs["A"]["observed_tail_rate"])
    if "C" in obs and "lowell_power_asym" in obs["C"]:
        out["C_lowell_p"] = two_sided_p(cal["C_lowell"], obs["C"]["lowell_power_asym"])
    if "dipole_modulation" in obs and "amplitude" in obs["dipole_modulation"]:
        out["mod_amp_p"] = two_sided_p(cal["mod_amp"], obs["dipole_modulation"]["amplitude"])
    Path(a.out).write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))
if __name__ == "__main__": main()
