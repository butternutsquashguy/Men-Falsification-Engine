#!/usr/bin/env python3
import argparse, json, requests, numpy as np, pandas as pd, healpy as hp
from pathlib import Path
SDSS_SQL = "https://skyserver.sdss.org/dr18/SkyServerWS/SearchTools/SqlSearch"
def build_sql(ra0, ra1, dec0, dec1, extra="TOP 200000 p.ra, p.dec FROM PhotoObj p"):
    box = f"(p.ra BETWEEN {ra0} AND {ra1}) AND (p.dec BETWEEN {dec0} AND {dec1})"
    if "FROM" not in extra.upper(): extra = "SELECT " + extra
    if "WHERE" in extra.upper(): return extra + " AND " + box
    return extra + " WHERE " + box
def sdss_query(sql, fmt="csv"):
    r = requests.get(SDSS_SQL, params={"cmd": sql, "format": fmt}, timeout=60); r.raise_for_status()
    lines = r.text.splitlines(); 
    if lines and lines[0].startswith("SkyServer"): lines = lines[1:]
    return "\n".join(lines)
def bin_to_healpix(df, nside, ra_col="ra", dec_col="dec", weight_col=None):
    theta = np.radians(90.0 - df[dec_col].values); phi = np.radians(df[ra_col].values)
    pix = hp.ang2pix(nside, theta, phi, nest=False)
    w = df[weight_col].values if (weight_col and weight_col in df) else np.ones_like(pix, float)
    m = np.bincount(pix, weights=w, minlength=hp.nside2npix(nside)).astype(float)
    return m
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ra0", type=float, required=True); ap.add_argument("--ra1", type=float, required=True)
    ap.add_argument("--dec0", type=float, required=True); ap.add_argument("--dec1", type=float, required=True)
    ap.add_argument("--nside", type=int, default=64)
    ap.add_argument("--sql", default="TOP 200000 p.ra, p.dec FROM PhotoObj p")
    ap.add_argument("--out-base", default="data/processed/sdss_dr18")
    a = ap.parse_args()
    sql = build_sql(a.ra0, a.ra1, a.dec0, a.dec1, extra=a.sql)
    csv_txt = sdss_query(sql, fmt="csv")
    Path("data/raw/sdss").mkdir(parents=True, exist_ok=True)
    raw_csv = Path("data/raw/sdss/query.csv"); raw_csv.write_text(csv_txt)
    df = pd.read_csv(raw_csv)
    m = bin_to_healpix(df, a.nside)
    hp.write_map(f"{a.out_base}_nside{a.nside}.fits", m, overwrite=True, coord="C")
    Path(f"{a.out_base}_nside{a.nside}.json").write_text(json.dumps({"ra0":a.ra0,"ra1":a.ra1,"dec0":a.dec0,"dec1":a.dec1,"nside":a.nside,"rows":int(df.shape[0])}, indent=2))
    print("OK")
if __name__ == "__main__": main()
