
#!/usr/bin/env python3
"""
Pinned small fetch for MEN-OBS Phase4 real-slice.
Writes to data/.cache and prints the saved path.
"""
import argparse, sys
from pathlib import Path
from research_pipeline.utils import net

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--cache-dir", default="data/.cache")
    p.add_argument("--out", default="planck2018_tt_full.txt")
    args = p.parse_args()
    url = "https://irsa.ipac.caltech.edu/data/Planck/release_3/ancillary-data/cosmoparams/COM_PowerSpect_CMB-TT-full_R3.01.txt"
    path = net.download_text(url, args.cache_dir, args.out, max_age_s=30*86400)
    print(path)

if __name__ == "__main__":
    sys.exit(main() or 0)
