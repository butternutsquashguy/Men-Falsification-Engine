#!/usr/bin/env python3
import argparse, numpy as np
from pathlib import Path
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nside", type=int, default=64)
    ap.add_argument("--lmax", type=int, default=128)
    ap.add_argument("--beam-fwhm-arcmin", type=float, default=0.0)
    ap.add_argument("--noise-rms", type=float, default=0.0)
    ap.add_argument("--mask")
    ap.add_argument("--nsims", type=int, default=300)
    ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    try:
        import healpy as hp
    except Exception as e:
        raise SystemExit("healpy required for simulations") from e
    rng = np.random.default_rng(a.seed)
    ell = np.arange(1, a.lmax+1); cl = np.zeros(a.lmax+1); cl[1:] = 1.0/(ell*(ell+1.0))
    if a.beam-fwhm-arcmin > 0:
        sigma = (a.beam-fwhm-arcmin/60.0)*np.pi/180.0/np.sqrt(8*np.log(2))
        bl = np.exp(-ell*(ell+1)*sigma*sigma/2.0); cl[1:] *= bl
    mask = None
    if a.mask:
        mask = hp.read_map(a.mask, verbose=False)
        if hp.get_nside(mask) != a.nside:
            mask = hp.ud_grade(mask, a.nside, power=-2)
    A_tail=[]; C_lowell=[]; mod_amp=[]
    for i in range(a.nsims):
        m = hp.synfast(cl, a.nside, lmax=a.lmax, new=True, verbose=False)
        if a.noise-rms>0: m += rng.normal(scale=a.noise-rms, size=m.size)
        mm = m if mask is None else np.where(mask>0.5, m, np.nan)
        g = np.isfinite(mm)
        if g.sum()==0: continue
        z = (mm[g]-np.nanmean(mm[g]))/(np.nanstd(mm[g])+1e-12)
        A_tail.append(float(np.mean(np.abs(z)>3.0)))
        # Cheap asymmetry proxy
        nside_scan=4
        vecs = hp.pix2vec(nside_scan, np.arange(hp.nside2npix(nside_scan)))
        pv = np.vstack(vecs).T
        best=0.0
        vx,vy,vz = hp.pix2vec(a.nside, np.arange(mm.size))
        pxyz = np.vstack([vx,vy,vz]).T
        for dv in pv:
            h1 = g & ((pxyz @ dv)>=0); h2 = g & (~((pxyz @ dv)>=0))
            if h1.sum()<10 or h2.sum()<10: continue
            v1 = np.nanvar(mm[h1]); v2 = np.nanvar(mm[h2]); 
            if (v1+v2)<=0: continue
            frac = abs(v1-v2)/(v1+v2); best = max(best, frac)
        C_lowell.append(float(best))
        mod_amp.append(float(np.nanstd(mm)))
    np.savez(a.out, nside=a.nside, lmax=a.lmax, nsims=a.nsims, A_tail=A_tail, C_lowell=C_lowell, mod_amp=mod_amp)
    print("Wrote", a.out)
if __name__ == "__main__": main()
