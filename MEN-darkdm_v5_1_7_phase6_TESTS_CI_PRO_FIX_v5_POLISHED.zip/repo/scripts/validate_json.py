
import json, argparse, sys
from jsonschema import Draft7Validator

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--schema', required=True)
    ap.add_argument('--json', required=True)
    args = ap.parse_args()
    sch = json.loads(open(args.schema).read())
    data = json.loads(open(args.json).read())
    v = Draft7Validator(sch)
    errs = sorted(v.iter_errors(data), key=lambda e: e.path)
    if errs:
        for e in errs:
            print("ERROR:", e.message, "at", list(e.path))
        sys.exit(1)
    print("OK:", args.json, "conforms to", args.schema)
if __name__ == "__main__":
    main()
