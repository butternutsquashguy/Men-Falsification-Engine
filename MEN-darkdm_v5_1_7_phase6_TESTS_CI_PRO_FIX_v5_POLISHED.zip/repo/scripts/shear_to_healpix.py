#!/usr/bin/env python3
import argparse, numpy as np, healpy as hp
from astropy.io import fits
from pathlib import Path
def shear_to_maps(path, nside, e1_col="e1", e2_col="e2", w_col=None, ra_col="ALPHA_J2000", dec_col="DELTA_J2000"):
    with fits.open(path, memmap=True) as hdul:
        data = hdul[1].data
        ra = np.asarray(data[ra_col], float); dec = np.asarray(data[dec_col], float)
        e1 = np.asarray(data[e1_col], float); e2 = np.asarray(data[e2_col], float)
        w = np.asarray(data[w_col], float) if (w_col and w_col in data.names) else np.ones_like(e1)
    theta = np.radians(90.0 - dec); phi = np.radians(ra)
    pix = hp.ang2pix(nside, theta, phi, nest=False); npix = hp.nside2npix(nside)
    wsum = np.bincount(pix, weights=w, minlength=npix).astype(float)
    e1sum = np.bincount(pix, weights=w*e1, minlength=npix).astype(float)
    e2sum = np.bincount(pix, weights=w*e2, minlength=npix).astype(float)
    with np.errstate(divide="ignore", invalid="ignore"):
        g1 = np.where(wsum>0, e1sum/wsum, np.nan); g2 = np.where(wsum>0, e2sum/wsum, np.nan)
    return g1, g2, wsum
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--catalog", required=True); ap.add_argument("--nside", type=int, default=64)
    ap.add_argument("--out-base", default="data/processed/kids_dr41")
    ap.add_argument("--e1-col", default="e1"); ap.add_argument("--e2-col", default="e2")
    ap.add_argument("--w-col", default=None); ap.add_argument("--ra-col", default="ALPHA_J2000"); ap.add_argument("--dec-col", default="DELTA_J2000")
    a = ap.parse_args()
    g1, g2, w = shear_to_maps(a.catalog, a.nside, a.e1_col, a.e2_col, a.w_col, a.ra_col, a.dec_col)
    hp.write_map(f"{a.out_base}_g1_nside{a.nside}.fits", g1, overwrite=True)
    hp.write_map(f"{a.out_base}_g2_nside{a.nside}.fits", g2, overwrite=True)
    hp.write_map(f"{a.out_base}_w_nside{a.nside}.fits", w, overwrite=True)
    print("Wrote", a.out_base)
if __name__ == "__main__": main()
