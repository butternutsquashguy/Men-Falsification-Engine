#!/usr/bin/env python3
import argparse, json, hashlib, os
from pathlib import Path
def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1<<20), b""):
            h.update(chunk)
    return h.hexdigest()
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--map", required=True)
    ap.add_argument("--mask", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    m, k = Path(args.map), Path(args.mask)
    if not m.exists() or not k.exists():
        raise SystemExit("Map or mask path does not exist")
    hdr = {}
    try:
        import healpy as hp
        m_arr, m_hdr = hp.read_map(str(m), h=True, verbose=False)
        hdr = dict(m_hdr); nside = int(hp.get_nside(m_arr))
        ordering = str(hdr.get("ORDERING","RING")).upper()
    except Exception:
        nside, ordering = None, None
    manifest = {
        "map": {"path": str(m), "sha256": sha256(m), "size": os.path.getsize(m)},
        "mask": {"path": str(k), "sha256": sha256(k), "size": os.path.getsize(k)},
        "headers": {"ORDERING": ordering, "NSIDE": nside, **({k: str(v) for k,v in (hdr or {}).items() if k in ("COORDSYS","FRAME")})}
    }
    Path(args.out).write_text(json.dumps(manifest, indent=2))
    print(json.dumps(manifest, indent=2))
if __name__ == "__main__": main()
