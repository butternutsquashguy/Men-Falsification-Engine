
    import numpy as np

import json, time, os, argparse
from pathlib import Path
def write_result(module, version, inputs, metrics, figures, diagnostics, outpath):
    out = {
        "module": module,
        "version": version,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "inputs": inputs,
        "metrics": metrics,
        "figures": figures,
        "diagnostics": diagnostics
    }
    Path(os.path.dirname(outpath)).mkdir(parents=True, exist_ok=True)
    open(outpath, "w").write(json.dumps(out, indent=2))
    print("Wrote", outpath)

import matplotlib.pyplot as plt
def save_simple_plot(x, y, title, out_png, xlabel="x", ylabel="y"):
    plt.figure()
    plt.plot(x, y)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.tight_layout()
    plt.savefig(out_png, dpi=150)
    plt.close()

    def mock_gw_population(seed:int, n:int=3000):
        rng = np.random.default_rng(seed)
        # mixture of stellar BH masses and PBH-like log-uniform
        stellar = rng.normal(30, 5, n//2)
        pbh = 10**rng.uniform(0.5, 2.0, n//2)
        masses = np.concatenate([stellar, pbh])
        masses = masses[masses>0]
        # simple bimodality score (Hartigan dip proxy: variance ratio toy)
        dip_like = float(np.std(masses) / (np.mean(masses)+1e-9))
        hist, edges = np.histogram(masses, bins=50, range=(0,150))
        centers = 0.5*(edges[1:]+edges[:-1])
        return {"bimodality_proxy": dip_like, "mass_centers": centers.tolist(), "hist": hist.tolist()}

    def main():
        import argparse
        ap = argparse.ArgumentParser()
        ap.add_argument("--seed", type=int, default=123)
        ap.add_argument("--output_json", default="artifacts/pbh_gw_population/result.json")
        ap.add_argument("--figure", default="figures/pbh_gw_population.png")
        args = ap.parse_args()
        metrics = mock_gw_population(args.seed)
        save_simple_plot(metrics["mass_centers"], metrics["hist"],
                         "Toy GW Mass Distribution", args.figure, xlabel="mass (Msun)", ylabel="counts")
        diagnostics = {"warnings": [], "notes": ["toy bimodality proxy for PBH mix"]}
        write_result("pbh_gw_population_mix", "3.0.0", {"seed":args.seed}, metrics, [args.figure], diagnostics, args.output_json)
    if __name__ == "__main__":
        main()
