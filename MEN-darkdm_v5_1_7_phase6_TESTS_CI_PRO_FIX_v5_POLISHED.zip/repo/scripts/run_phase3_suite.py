
import subprocess, sys, json, time, pathlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
ART = ROOT/"artifacts"
MANIFEST = ART/"phase3_manifest.json"

CMDS = [
    [sys.executable, "scripts/pbh_evaporation.py", "--output_json", "artifacts/pbh_evaporation/result.json"],
    [sys.executable, "scripts/pbh_frb_lensing.py", "--output_json", "artifacts/pbh_frb_lensing/result.json"],
    [sys.executable, "scripts/pbh_microlensing.py", "--output_json", "artifacts/pbh_microlensing/result.json"],
    [sys.executable, "scripts/pbh_gw_population.py", "--output_json", "artifacts/pbh_gw_population/result.json"],
    [sys.executable, "scripts/pbh_energy_injection.py", "--output_json", "artifacts/pbh_energy_injection/result.json"],
]

def run(cmd):
    print(">>>", " ".join(map(str, cmd)))
    r = subprocess.run(cmd, cwd=ROOT)
    if r.returncode != 0:
        raise SystemExit(r.returncode)

def main():
    ART.mkdir(parents=True, exist_ok=True)
    for c in CMDS:
        run(c)
    manifest = {
        "phase": "3",
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "modules": [
            "pbh_evaporation", "pbh_frb_lensing", "pbh_microlensing", "pbh_gw_population_mix", "pbh_energy_injection"
        ],
        "artifacts": {
            "pbh_evaporation": "artifacts/pbh_evaporation/result.json",
            "pbh_frb_lensing": "artifacts/pbh_frb_lensing/result.json",
            "pbh_microlensing": "artifacts/pbh_microlensing/result.json",
            "pbh_gw_population_mix": "artifacts/pbh_gw_population/result.json",
            "pbh_energy_injection": "artifacts/pbh_energy_injection/result.json"
        }
    }
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(manifest, indent=2))
    print("Wrote", MANIFEST)

if __name__ == "__main__":
    main()
