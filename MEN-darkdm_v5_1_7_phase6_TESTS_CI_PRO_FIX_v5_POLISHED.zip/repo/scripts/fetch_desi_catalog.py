#!/usr/bin/env python3
import argparse
from pathlib import Path
from scripts.common_fetch_utils import stream_download
def main():
    ap = argparse.ArgumentParser(description="DESI catalog fetcher (URL-driven).")
    ap.add_argument("--url", required=True, help="Direct URL to a DESI catalog file (FITS/CSV/Parquet)")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    out = a.out or ("data/raw/desi/" + Path(a.url).name)
    path, size = stream_download(a.url, out)
    print("Downloaded", path, "bytes:", size)
    print("Next: python scripts/catalog_to_healpix.py --input", path, "--nside 64 --ra-col RA --dec-col DEC")
if __name__ == "__main__": main()
