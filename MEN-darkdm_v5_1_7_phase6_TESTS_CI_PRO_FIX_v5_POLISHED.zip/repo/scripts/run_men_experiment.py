#!/usr/bin/env python3
"""
MEN Experiment Runner (Dark DM Modules)
Reads a YAML experiment file and executes sweeps for M-DBBH and M-QdS.
Outputs CSV and JSON per job into the configured output directory.

Usage:
  python scripts/run_men_experiment.py --exp experiments/dark_dm_sweeps.yaml
"""
import argparse, json, itertools, os, csv, sys
# Ensure repo root on import path
sys.path.insert(0, os.path.abspath('.'))

try:
    import yaml
except ModuleNotFoundError:
    print("Please 'pip install pyyaml' to use this runner.", file=sys.stderr)
    sys.exit(1)

from pathlib import Path
from men_ext.dark_dm.men_dark_dm import (
    DBBHParams, QdSParams,
    compute_dbbh_abundance, compute_qds_abundance,
    forecast_sgwb_collapse_epoch, forecast_sgwb_fast_expansion
)

# --- Priors-based grid helpers ---
def _pick_grid_from_param(pd: dict, mode: str):
    # mode: 'preferred' or 'wide'
    if mode == 'preferred' and 'preferred' in pd and isinstance(pd['preferred'], (list, tuple)):
        return list(pd['preferred'])
    # Wide: min/mid/max if available
    mn, mx = pd.get('min'), pd.get('max')
    if isinstance(mn, (int, float)) and isinstance(mx, (int, float)):
        mid = (mn + mx) / 2.0
        return [mn, mid, mx]
    # Fallback
    return pd.get('preferred', []) if isinstance(pd.get('preferred'), (list, tuple)) else []

def _exp_from_priors(priors: dict, mode: str='preferred'):
    exp = {
        'experiment_id': f"dark_dm_from_priors_{mode}",
        'output_dir': f"runs/dark_dm_from_priors_{mode}",
        'jobs': []
    }
    mods = priors.get('modules', {})
    # M-DBBH
    db = mods.get('dark_baryon_bh')
    if db and db.get('enabled', True):
        p = db.get('params', {})
        exp['jobs'].append({
            'name': 'dbbh_from_priors',
            'module': 'dbbh',
            'params': {
                'N': _pick_grid_from_param(p.get('N', {}), mode),
                'Lambda_conf': _pick_grid_from_param(p.get('Lambda_conf_GeV', {}), mode),
                'mq': _pick_grid_from_param(p.get('mq_GeV', {}), mode),
                'T_dark': _pick_grid_from_param(p.get('T_dark_GeV', {}), mode),
                'kappa': _pick_grid_from_param(p.get('rmt_tail_kappa', {}), mode),
                'seed': [123, 456]
            }
        })
    # M-QdS
    qd = mods.get('quasi_de_sitter_dm')
    if qd and qd.get('enabled', True):
        p = qd.get('params', {})
        exp['jobs'].append({
            'name': 'qds_from_priors',
            'module': 'qds',
            'params': {
                'w': _pick_grid_from_param(p.get('w', {}), mode),
                'T_end': _pick_grid_from_param(p.get('T_end_GeV', {}), mode),
                'm_dm': _pick_grid_from_param(p.get('m_dm_GeV', {}), mode),
                'seed': [123, 456]
            }
        })
    return exp

# --- Constraint propagation stub ---
def _propagate_constraints(rows, priors, outdir: Path):
    # Placeholder: write available cross-constraints and suggest next actions.
    cc = priors.get('cross_constraints', {})
    suggestion = {
        'constraints_available': list(cc.keys()),
        'notes': 'Hook your real anomaly/IB/TN metrics here and prune the grid accordingly.'
    }
    with open(outdir / '_constraint_suggestions.json', 'w') as f:
        json.dump(suggestion, f, indent=2)

def cartesian_product(params_dict):
    keys = list(params_dict.keys())
    values = [v if isinstance(v, (list, tuple)) else [v] for v in params_dict.values()]
    for combo in itertools.product(*values):
        yield dict(zip(keys, combo))

def run_job(job, outdir: Path):
    name = job["name"]
    module = job["module"].lower()
    grid = job["params"]

    rows = []
    for p in cartesian_product(grid):
        if module == "dbbh":
            pp = DBBHParams(
                N=int(p["N"]), Lambda_conf=float(p["Lambda_conf"]), mq=float(p["mq"]),
                T_dark=float(p["T_dark"]), rmt_tail_kappa=float(p["kappa"]),
                seed=int(p["seed"])
            )
            res = compute_dbbh_abundance(pp)
            sgwb = forecast_sgwb_collapse_epoch(
                res["m_dark_baryon_GeV"], res["collapse_prob"]
            )
            res["sgwb"] = {"peak_Hz": sgwb["peak_Hz"], "Omega_GW@peak": max(sgwb["Omega_GW"])}
        elif module == "qds":
            pp = QdSParams(
                w=float(p["w"]), T_end=float(p["T_end"]), m_dm=float(p["m_dm"]),
                seed=int(p["seed"])
            )
            res = compute_qds_abundance(pp)
            sgwb = forecast_sgwb_fast_expansion(pp.w)
            import numpy as np
            f = np.array(sgwb["f_Hz"], dtype=float)
            om = np.array(sgwb["Omega_GW"], dtype=float)
            om1 = float(np.interp(1.0, f, om))
            res["sgwb"] = {"alpha": sgwb["alpha"], "Omega_GW@1Hz": om1}
        else:
            raise ValueError(f"Unknown module: {module}")

        flat = {f"param.{k}": v for k, v in res["params"].items()}
        for k, v in res.items():
            if k not in ("params", "sgwb"):
                flat[k] = v
        for k, v in res.get("sgwb", {}).items():
            flat[f"sgwb.{k}"] = v
        rows.append(flat)

    # Write outputs
    outdir.mkdir(parents=True, exist_ok=True)
    csv_path = outdir / f"{name}.csv"
    if rows:
        fieldnames = sorted(rows[0].keys())
        with open(csv_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fieldnames)
            w.writeheader()
            for r in rows:
                w.writerow(r)

    json_path = outdir / f"{name}.json"
    with open(json_path, "w") as f:
        json.dump({"job": job, "n_rows": len(rows)}, f, indent=2)

    return {"csv": str(csv_path), "json": str(json_path), "rows": len(rows)}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exp", required=False, help="Path to experiment YAML")
    ap.add_argument("--from-priors", dest="from_priors", help="Path to hyperpriors JSON to build the experiment")
    ap.add_argument("--grid", choices=["preferred","wide"], default="preferred", help="Grid mode for priors-driven experiments")
    ap.add_argument("--metrics", help="Path to JSON with observed metrics for constraints A/B/C (optional)")
    args = ap.parse_args()

    if args.from_priors:
        with open(args.from_priors, 'r') as f:
            pri = json.load(f)
        exp = _exp_from_priors(pri, mode=args.grid)
    else:
        if not args.exp:
            print('Either --exp or --from-priors must be provided', file=sys.stderr); sys.exit(2)
        with open(args.exp, 'r') as f:
            exp = yaml.safe_load(f)
        pri = {}
    outdir = Path(exp["output_dir"])
    outdir.mkdir(parents=True, exist_ok=True)

    results = []
    for job in exp["jobs"]:
        r = run_job(job, outdir)
        print(f"[OK] {job['name']} rows={r['rows']} -> {r['csv']}")
        results.append(r)

    with open(outdir / "_batch_summary.json", "w") as f:
        json.dump({"experiment": exp["experiment_id"], "results": results}, f, indent=2)

    metrics = None
    if args.metrics and os.path.exists(args.metrics):
        try:
            with open(args.metrics, "r") as mf:
                metrics = json.load(mf)
        except Exception as e:
            print(f"[warn] metrics read failed: {e}")
    rows_with_flags, csum = _evaluate_constraints(results, pri, metrics)
    with open(outdir / "_constraint_eval.json", "w") as f:
        json.dump(csum, f, indent=2)
    with open(outdir / "_rows_with_flags.json", "w") as f:
        json.dump(rows_with_flags, f, indent=2)

    # Constraint propagation stub
    try:
        _propagate_constraints(results, pri, outdir)
    except Exception as e:
        print(f"[warn] constraint propagation stub failed: {e}")

# Constraint evaluation helper
def _evaluate_constraints(rows, priors, metrics):
    Amax = metrics.get("A", {}).get("tail_max") if metrics else None
    if Amax is None:
        Amax = priors.get("modules", {}).get("random_matrix", {}).get("max_outlier_rate_n_le_1600", 0.003) if priors else 0.003
    Cmin = metrics.get("C", {}).get("min_edge") if metrics else 0.55
    Bslope_pref = metrics.get("B", {}).get("slope_pref") if metrics else (priors.get("modules", {}).get("tensor_network", {}).get("entropy_vs_logD_slope_preferred", 0.98) if priors else 0.98)
    out = []
    for r in rows:
        failed = []
        mod = r.get("module") or ""
        tail = None
        if metrics and "A" in metrics and "observed_tail_rate" in metrics["A"]:
            tail = metrics["A"]["observed_tail_rate"]
        if tail is None and mod == "dbbh":
            tail = r.get("collapse_prob", 0.0) * 0.5
        if tail is not None and tail > Amax:
            failed.append("A")
        if metrics and "B" in metrics and "tn_slope_est" in metrics["B"]:
            est = metrics["B"]["tn_slope_est"]; tol = metrics["B"].get("tolerance", 0.05)
            if abs(est - Bslope_pref) > tol: failed.append("B")
        ib = metrics.get("C", {}).get("ib_edge_score") if metrics else None
        if ib is None and mod == "qds":
            w = r.get("param.w") or -0.8
            try: w = float(w)
            except: w = -0.8
            ib = max(0.0, 1.0 - (abs(w) - 0.7))
        if ib is not None and ib < Cmin:
            failed.append("C")
        rr = dict(r); rr["passes_constraints"] = len(failed) == 0
        if failed: rr["failed_constraints"] = failed
        out.append(rr)
    suggest = {}
    return out, {"summary": {"A": {"max_tail": Amax}, "C": {"min_ib_edge": Cmin}, "B": {"tn_slope_pref": Bslope_pref}}, "suggest": suggest}

if __name__ == "__main__":
    main()


