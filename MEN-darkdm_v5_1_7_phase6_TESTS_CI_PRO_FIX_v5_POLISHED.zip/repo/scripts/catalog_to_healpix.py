#!/usr/bin/env python3
import argparse, numpy as np, healpy as hp
from pathlib import Path
def read_table(path):
    p = Path(path); suf = p.suffix.lower()
    if suf in [".fits",".fit",".fz"]:
        from astropy.io import fits
        with fits.open(p, memmap=True) as hdul:
            return {k: hdul[1].data[k] for k in hdul[1].columns.names}
    import pandas as pd
    if suf==".csv": df=pd.read_csv(p)
    elif suf in [".parquet",".pq"]: df=pd.read_parquet(p)
    else: raise SystemExit("Unsupported format: "+suf)
    return {k: df[k].values for k in df.columns}
def main():
    ap = argparse.ArgumentParser(description="Generic RA/Dec catalog -> HEALPix map binner.")
    ap.add_argument("--input", required=True); ap.add_argument("--nside", type=int, default=64)
    ap.add_argument("--ra-col", default="ra"); ap.add_argument("--dec-col", default="dec"); ap.add_argument("--weight-col", default=None)
    ap.add_argument("--out", default="data/processed/catalog_map.fits"); a=ap.parse_args()
    tab = read_table(a.input)
    if a.ra_col not in tab or a.dec_col not in tab: raise SystemExit(f"Columns {a.ra_col}/{a.dec_col} not found")
    ra=np.array(tab[a.ra_col], float); dec=np.array(tab[a.dec_col], float)
    w=np.array(tab[a.weight_col], float) if (a.weight_col and a.weight_col in tab) else np.ones_like(ra,float)
    th=np.radians(90.0-dec); ph=np.radians(ra); pix=hp.ang2pix(a.nside, th, ph, nest=False)
    m=np.bincount(pix, weights=w, minlength=hp.nside2npix(a.nside)).astype(float); hp.write_map(a.out, m, overwrite=True, coord="C"); print("Wrote", a.out)
if __name__=="__main__": main()
