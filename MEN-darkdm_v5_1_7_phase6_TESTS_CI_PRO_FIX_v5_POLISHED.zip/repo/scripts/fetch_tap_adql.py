#!/usr/bin/env python3
import argparse
from pathlib import Path
def main():
    ap = argparse.ArgumentParser(description="Generic TAP ADQL fetcher (async) with optional HEALPix binning.")
    ap.add_argument("--tap-url", required=True); ap.add_argument("--adql", required=True)
    ap.add_argument("--out-csv", default="data/raw/tap/result.csv")
    ap.add_argument("--nside", type=int, default=0); ap.add_argument("--ra-col", default="ra"); ap.add_argument("--dec-col", default="dec")
    ap.add_argument("--out-map", default="data/processed/tap_map.fits")
    a = ap.parse_args()
    from astroquery.utils.tap.core import TapPlus; import pandas as pd, numpy as np, healpy as hp
    tap = TapPlus(url=a.tap_url); job = tap.launch_job_async(a.adql, dump_to_file=False); table = job.get_results(); df = table.to_pandas()
    Path(a.out_csv).parent.mkdir(parents=True, exist_ok=True); df.to_csv(a.out_csv, index=False); print("Wrote CSV:", a.out_csv, "rows:", len(df))
    if a.nside and a.nside>0:
        if a.ra_col not in df or a.dec_col not in df: raise SystemExit("Missing RA/Dec columns")
        th = np.radians(90.0 - df[a.dec_col].values); ph = np.radians(df[a.ra_col].values)
        pix = hp.ang2pix(a.nside, th, ph, nest=False); m = np.bincount(pix, minlength=hp.nside2npix(a.nside)).astype(float)
        Path(a.out_map).parent.mkdir(parents=True, exist_ok=True); hp.write_map(a.out_map, m, overwrite=True, coord="C"); print("Wrote map:", a.out_map)
if __name__ == "__main__": main()
