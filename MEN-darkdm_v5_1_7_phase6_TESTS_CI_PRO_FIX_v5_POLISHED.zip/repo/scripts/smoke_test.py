import tempfile
from pathlib import Path
from men_experiment.runner import run

def main():
    out = Path(tempfile.mkdtemp(prefix="men_smoke_"))
    priors = {"grid": {"dummy_param": [1,2]}, "n_jobs": 2}
    run("plugins.qds", priors, str(out), dry_run=True)
    print(f"Smoke OK → {out}")

if __name__ == "__main__":
    main()