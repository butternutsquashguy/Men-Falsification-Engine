#!/usr/bin/env python3
"""
MEN Experiment Registry CLI
List, inspect, and run registered MEN experiments by name.

Usage:
  python scripts/men_registry.py list
  python scripts/men_registry.py info dark_dm_sweeps
  python scripts/men_registry.py run dark_dm_sweeps
"""
import argparse, json, os, sys, subprocess
from pathlib import Path

def load_registry(registry_file: Path):
    try:
        import yaml
    except ModuleNotFoundError:
        print("Please 'pip install pyyaml' to use the registry.", file=sys.stderr)
        sys.exit(1)
    with open(registry_file, "r") as f:
        return yaml.safe_load(f)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["list", "info", "run"], help="Action")
    ap.add_argument("name", nargs="?", help="Experiment name (for info/run)")
    ap.add_argument("--registry", default="experiments/registry.yaml", help="Path to registry YAML")
    args = ap.parse_args()

    reg_path = Path(args.registry)
    if not reg_path.exists():
        print(f"Registry not found: {reg_path}", file=sys.stderr)
        sys.exit(1)

    reg = load_registry(reg_path)
    exps = reg.get("experiments", {})

    if args.command == "list":
        for k, v in exps.items():
            desc = v.get("description","")
            print(f"{k}: {desc}")
        return

    if not args.name or args.name not in exps:
        print(f"Unknown or missing experiment name. Use 'list' to see options.", file=sys.stderr)
        sys.exit(1)

    info = exps[args.name]
    if args.command == "info":
        print(json.dumps(info, indent=2))
        return

    if args.command == "run":
        runner = Path(info["runner"])
        exp_yaml = Path(info["path"])
        if not runner.exists():
            print(f"Runner not found: {runner}", file=sys.stderr)
            sys.exit(1)
        if not exp_yaml.exists():
            print(f"Experiment YAML not found: {exp_yaml}", file=sys.stderr)
            sys.exit(1)
        extra = info.get('args', [])
        cmd = [sys.executable, str(runner)] + (extra if isinstance(extra, list) else [])
        if str(exp_yaml) not in extra:
            cmd += ["--exp", str(exp_yaml)]
        env = os.environ.copy()
        env['PYTHONPATH'] = str(Path('.').resolve())
        print(f"[RUN] {' '.join(cmd)} (PYTHONPATH={env['PYTHONPATH']})")
        sys.exit(subprocess.call(cmd, env=env))

if __name__ == "__main__":
    main()