#!/usr/bin/env python3
import json, sys, time
from pathlib import Path
def pv(n):
    try:
        import importlib.metadata as md; return md.version(n)
    except Exception:
        try: import pkg_resources as pr; return pr.get_distribution(n).version
        except Exception: return None
def main():
    pkgs = ["numpy","scipy","pandas","healpy","astropy","matplotlib","scikit-learn","gwpy","numba","tqdm"]
    manifest = {"timestamp": time.strftime("%Y-%m-%d %H:%M:%S"), "python": sys.version,
                "packages": {p: pv(p) for p in pkgs}}
    Path("runs").mkdir(exist_ok=True); (Path("runs")/"MANIFEST.json").write_text(json.dumps(manifest, indent=2))
    print(json.dumps(manifest, indent=2))
if __name__ == "__main__": main()
