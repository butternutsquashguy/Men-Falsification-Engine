
-- HEASARC TAP ADQL: small slice of Fermi GBM bursts
SELECT TOP 50 name, trigger_time, ra, dec
FROM fermigbrst
ORDER BY trigger_time DESC
