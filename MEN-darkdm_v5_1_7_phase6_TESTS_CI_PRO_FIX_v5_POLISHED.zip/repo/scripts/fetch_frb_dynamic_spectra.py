
"""
Phase 4 fetcher stub: FRB Dynamic Spectra.
Returns a tiny toy slice and a checksum for determinism.
"""
import json, hashlib
from pathlib import Path

def fetch(outdir: str) -> str:
    Path(outdir).mkdir(parents=True, exist_ok=True)
    data = {{"source": "FRB Dynamic Spectra", "records": 3}}
    p = Path(outdir) / "fetch_frb_dynamic_spectra.json"
    p.write_text(json.dumps(data, indent=2))
    h = hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()
    return str(p)
