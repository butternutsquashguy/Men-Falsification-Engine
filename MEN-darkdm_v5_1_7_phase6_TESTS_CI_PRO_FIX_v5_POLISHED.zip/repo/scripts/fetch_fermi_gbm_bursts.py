
#!/usr/bin/env python3
"""
Pinned small fetch for MEN-OBS Phase4 real-slice.
Writes to data/.cache and prints the saved path.
"""
import argparse, sys
from pathlib import Path
from research_pipeline.utils import net

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--cache-dir", default="data/.cache")
    p.add_argument("--query", default="scripts/queries/fermigbrst_top50.sql")
    p.add_argument("--out", default="fermigbrst_top50.csv")
    args = p.parse_args()
    tap = "https://heasarc.gsfc.nasa.gov/xamin/vo/tap/sync"
    sql = Path(args.query).read_text()
    path = net.download_form(
        tap,
        {"REQUEST":"doQuery","LANG":"ADQL","FORMAT":"csv","QUERY":sql},
        args.cache_dir,
        args.out,
        max_age_s=7*86400
    )
    print(path)

if __name__ == "__main__":
    sys.exit(main() or 0)
