#!/usr/bin/env python3
import argparse, sys
from pathlib import Path
ESO_TAP="https://archive.eso.org/tap_cat"
def list_tables(limit=60):
    from astroquery.utils.tap.core import TapPlus
    tap = TapPlus(url=ESO_TAP)
    tables = tap.load_tables(only_names=True); names = [k for k in tables.keys()]
    return names[:limit], len(names)
def build_region_adql(table, ra, dec, radius_deg, columns="*", ra_col="ra", dec_col="dec", where=None, top=200000):
    topfrag = f"TOP {int(top)} " if top else ""
    adql = f"SELECT {topfrag}{columns} FROM {table} WHERE 1=1 AND CONTAINS(POINT('ICRS',{ra_col},{dec_col}), CIRCLE('ICRS',{ra},{dec},{radius_deg}))=1"
    if where: adql += f" AND ({where})"
    return adql
def main():
    ap = argparse.ArgumentParser(description="ESO TAP_CAT helper: list tables or run a region query and optionally bin to HEALPix.")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--table"); ap.add_argument("--ra", type=float); ap.add_argument("--dec", type=float); ap.add_argument("--radius-deg", type=float)
    ap.add_argument("--columns", default="*"); ap.add_argument("--ra-col", default="ra"); ap.add_argument("--dec-col", default="dec")
    ap.add_argument("--where", default=None); ap.add_argument("--top", type=int, default=200000)
    ap.add_argument("--out-csv", default="data/raw/eso_tap/result.csv"); ap.add_argument("--nside", type=int, default=0); ap.add_argument("--out-map", default="data/processed/eso_tap_map.fits")
    a = ap.parse_args()
    if a.list:
        names,total = list_tables(limit=60); print(f"Sample ESO TAP_CAT tables ({len(names)} of ~{total}):"); [print(' -', n) for n in names]; sys.exit(0)
    if not (a.table and a.ra is not None and a.dec is not None and a.radius_deg is not None): raise SystemExit("Provide --table, --ra, --dec, --radius-deg or use --list")
    from astroquery.utils.tap.core import TapPlus; import pandas as pd, numpy as np, healpy as hp
    tap = TapPlus(url=ESO_TAP); adql = build_region_adql(a.table, a.ra, a.dec, a.radius_deg, a.columns, a.ra_col, a.dec_col, a.where, a.top)
    job = tap.launch_job_async(adql, dump_to_file=False); table = job.get_results(); df = table.to_pandas()
    Path(a.out_csv).parent.mkdir(parents=True, exist_ok=True); df.to_csv(a.out_csv, index=False); print("Wrote CSV:", a.out_csv, "rows:", len(df))
    if a.nside and a.nside>0:
        if a.ra_col not in df or a.dec_col not in df: raise SystemExit("Missing RA/Dec columns")
        th = np.radians(90.0 - df[a.dec_col].values); ph = np.radians(df[a.ra_col].values)
        pix = hp.ang2pix(a.nside, th, ph, nest=False); m = np.bincount(pix, minlength=hp.nside2npix(a.nside)).astype(float)
        Path(a.out_map).parent.mkdir(parents=True, exist_ok=True); hp.write_map(a.out_map, m, overwrite=True, coord="C"); print("Wrote map:", a.out_map)
if __name__ == "__main__": main()
