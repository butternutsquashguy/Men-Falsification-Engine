
    import numpy as np

import json, time, os, argparse
from pathlib import Path
def write_result(module, version, inputs, metrics, figures, diagnostics, outpath):
    out = {
        "module": module,
        "version": version,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "inputs": inputs,
        "metrics": metrics,
        "figures": figures,
        "diagnostics": diagnostics
    }
    Path(os.path.dirname(outpath)).mkdir(parents=True, exist_ok=True)
    open(outpath, "w").write(json.dumps(out, indent=2))
    print("Wrote", outpath)

import matplotlib.pyplot as plt
def save_simple_plot(x, y, title, out_png, xlabel="x", ylabel="y"):
    plt.figure()
    plt.plot(x, y)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.tight_layout()
    plt.savefig(out_png, dpi=150)
    plt.close()

    def mock_frb_lensing(seed:int, n:int=2000):
        rng = np.random.default_rng(seed)
        # toy: random time delays with small tail for lensed doublets
        delays = rng.exponential(0.02, n)
        lensed = delays > 0.1
        rate = float(np.mean(lensed))
        # simple histogram
        import numpy as np
        hist, edges = np.histogram(delays, bins=50, range=(0,0.5))
        centers = 0.5*(edges[1:]+edges[:-1])
        return {"lensed_rate": rate, "delay_centers": centers.tolist(), "delay_hist": hist.tolist()}

    def main():
        import argparse
        ap = argparse.ArgumentParser()
        ap.add_argument("--seed", type=int, default=123)
        ap.add_argument("--output_json", default="artifacts/pbh_frb_lensing/result.json")
        ap.add_argument("--figure", default="figures/pbh_frb_lensing.png")
        args = ap.parse_args()
        metrics = mock_frb_lensing(args.seed)
        save_simple_plot(metrics["delay_centers"], metrics["delay_hist"],
                         "Toy FRB Delay Histogram", args.figure, xlabel="delay (s)", ylabel="counts")
        diagnostics = {"warnings": [], "notes": ["toy FRB lensing proxy"]}
        write_result("pbh_frb_lensing", "3.0.0", {"seed":args.seed}, metrics, [args.figure], diagnostics, args.output_json)
    if __name__ == "__main__":
        main()
