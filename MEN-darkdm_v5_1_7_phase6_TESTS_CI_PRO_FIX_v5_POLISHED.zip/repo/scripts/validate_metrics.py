#!/usr/bin/env python3
import json, sys
from pathlib import Path
REQ = {"A":["observed_tail_rate"], "C":["ib_edge_score"]}
if len(sys.argv)<2: print("Usage: validate_metrics.py <file>"); exit(2)
p = Path(sys.argv[1]); data = json.loads(p.read_text()); errs = []
for s,keys in REQ.items():
    if s not in data: errs.append(f"Missing section {s}"); continue
    for k in keys:
        if k not in data[s]: errs.append(f"Missing key {s}.{k}")
if errs:
    print("VALIDATION FAILED:"); [print(' -',e) for e in errs]; exit(1)
print("VALIDATION OK")
