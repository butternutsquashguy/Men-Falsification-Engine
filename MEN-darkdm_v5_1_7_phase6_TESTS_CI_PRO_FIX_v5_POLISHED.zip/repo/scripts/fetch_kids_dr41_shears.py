#!/usr/bin/env python3
import argparse
from pathlib import Path
from scripts.common_fetch_utils import stream_download
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="https://kids.strw.leidenuniv.nl/DR4/data_files/KiDS_DR4.1_ugriZYJHKs_SOM_gold_WL_cat.fits")
    ap.add_argument("--out", default="data/raw/kids/KiDS_DR4.1_SOM_gold_WL_cat.fits")
    a = ap.parse_args()
    path, size = stream_download(a.url, a.out)
    print("Downloaded", path, "bytes:", size)
    print("Next: python scripts/shear_to_healpix.py --catalog", a.out, "--nside 64")
if __name__ == "__main__": main()
