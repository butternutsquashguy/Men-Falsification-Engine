#!/usr/bin/env python3
import argparse, requests, tempfile, numpy as np, healpy as hp
from pathlib import Path
def discover_skymap_url(catalog, event, version):
    return f"https://gwosc.org/eventapi/fits/{catalog}/{event}/{version}/{event}_{version}_multiorder.fits"
def mof_to_nside(path, nest, nside_out):
    import ligo.skymap.io
    prob, header = ligo.skymap.io.read_sky_map(path, nest=nest)
    nside_in = hp.get_nside(prob)
    if nside_in != nside_out:
        prob_out = hp.ud_grade(prob, nside_out, order_in="NEST" if nest else "RING", order_out="RING", power=-2)
    else:
        prob_out = prob if not nest else hp.reorder(prob, n2r=True)
    s = np.nansum(prob_out)
    if s and np.isfinite(s) and s>0: prob_out = prob_out/s
    return prob_out
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--catalog", required=True); ap.add_argument("--event", required=True)
    ap.add_argument("--version", default="v3"); ap.add_argument("--nside", type=int, default=64)
    ap.add_argument("--nest", action="store_true"); ap.add_argument("--out", default=None)
    a = ap.parse_args()
    url = discover_skymap_url(a.catalog, a.event, a.version)
    with requests.get(url, stream=True, timeout=60) as r:
        r.raise_for_status()
        tmp = Path(tempfile.gettempdir())/f"{a.event}_{a.version}.fits"
        with open(tmp, "wb") as f:
            for ch in r.iter_content(1<<20):
                if ch: f.write(ch)
    prob = mof_to_nside(str(tmp), nest=a.nest, nside_out=a.nside)
    out = a.out or f"data/processed/gwosc_{a.event}_nside{a.nside}.fits"
    hp.write_map(out, prob, overwrite=True)
    print("Wrote", out)
if __name__ == "__main__": main()
