#!/usr/bin/env python3
import argparse
from scripts.common_fetch_utils import stream_download
DEFAULTS = {
  "SMICA": "https://irsa.ipac.caltech.edu/data/Planck/release_3/ancillary-data/HFI_SkyMap_Consolidated_2048_R3.00_full.fits",
  "NILC": "https://irsa.ipac.caltech.edu/data/Planck/release_3/ancillary-data/HFI_SkyMap_Consolidated_2048_R3.00_full.fits"
}
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--product", choices=["SMICA","NILC"], default="SMICA")
    ap.add_argument("--url", default=None); ap.add_argument("--out", default=None)
    a = ap.parse_args()
    url = a.url or DEFAULTS[a.product]
    out = a.out or f"data/raw/planck/{a.product}_map.fits"
    path, size = stream_download(url, out)
    print("Downloaded", path, "bytes:", size)
if __name__ == "__main__":
    main()
