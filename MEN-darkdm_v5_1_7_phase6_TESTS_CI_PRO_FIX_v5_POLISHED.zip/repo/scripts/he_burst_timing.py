
    import numpy as np

import json, time, os, argparse, math, random
from pathlib import Path

def write_result(module, version, inputs, metrics, figures, diagnostics, outpath):
    out = {
        "module": module,
        "version": version,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "inputs": inputs,
        "metrics": metrics,
        "figures": figures,
        "diagnostics": diagnostics
    }
    Path(os.path.dirname(outpath)).mkdir(parents=True, exist_ok=True)
    open(outpath, "w").write(json.dumps(out, indent=2))
    print("Wrote", outpath)

import matplotlib.pyplot as plt

def save_simple_plot(x, y, title, out_png):
    plt.figure()
    plt.plot(x, y)
    plt.title(title)
    plt.xlabel("x")
    plt.ylabel("y")
    plt.tight_layout()
    plt.savefig(out_png, dpi=150)
    plt.close()

    import argparse

    def mock_burst_timing(seed:int, n:int=300):
        rng = np.random.default_rng(seed)
        times = np.sort(rng.uniform(0, 1000, n))
        # toy clustering: add a burst window
        burst = rng.uniform(400, 450, 30)
        times = np.sort(np.concatenate([times, burst]))
        # simple index of dispersion (variance/mean) for counts in bins
        bins = np.linspace(0, 1000, 51)
        counts, _ = np.histogram(times, bins=bins)
        lam = counts.mean()
        iod = float(counts.var() / (lam + 1e-9))
        return {"index_of_dispersion": iod, "n_events": len(times)}

    def main():
        ap = argparse.ArgumentParser()
        ap.add_argument("--seed", type=int, default=123)
        ap.add_argument("--output_json", default="artifacts/he_burst/result.json")
        ap.add_argument("--figure", default="figures/he_burst_timing.png")
        args = ap.parse_args()
        metrics = mock_burst_timing(args.seed)
        x = list(range(50))
        y = [0 if i<20 or i>30 else 1 for i in x]
        save_simple_plot(x, y, "Mock HE Burst Timing Window", args.figure)
        diagnostics = {"warnings": [], "notes": ["toy dispersion index; added burst window"]}
        write_result("he_burst_timing", "2.0.0", {"seed":args.seed}, metrics, [args.figure], diagnostics, args.output_json)

    if __name__ == "__main__":
        main()
