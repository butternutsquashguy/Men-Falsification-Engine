#!/usr/bin/env python3
import argparse, json, numpy as np, healpy as hp
from pathlib import Path

def degrade_mask(mask, nside_out, thresh=0.5):
    m = hp.ud_grade(mask.astype(float), nside_out, order_in="RING", order_out="RING", power=0)
    return (m >= thresh).astype(float)

def spectral_measures(map_in, mask, lmin, lmax):
    mm = map_in * (mask if mask is not None else 1.0)
    cl = hp.anafast(mm, lmax=lmax, use_pixel_weights=False)
    ell = np.arange(len(cl))
    sel = (ell >= lmin) & (ell <= lmax) & np.isfinite(cl) & (cl > 0)
    if not np.any(sel):
        return np.nan, np.nan
    c = cl[sel]
    # participation ratio (PR) across ell
    s1 = np.sum(c); s2 = np.sum(c**2)
    pr = (s1**2 / s2) if (s2 > 0) else np.nan
    # spectral entropy (SE)
    p = c / np.sum(c)
    se = -np.sum(p * np.log(p + 1e-300))
    return pr, se

def main():
    ap = argparse.ArgumentParser(description="TN slope estimator: multiscale spectral complexity vs. resolution.")
    ap.add_argument("--map-fits", required=True)
    ap.add_argument("--mask-fits", default=None)
    ap.add_argument("--nsides", default="32,64,128,256", help="comma list of target NSIDEs (<= native)")
    ap.add_argument("--lmin", type=int, default=2)
    ap.add_argument("--lmax", type=int, default=0, help="0 -> auto 3*Nside-1 per scale")
    ap.add_argument("--coord", default="C", choices=["C","G","E"])
    ap.add_argument("--out", default="metrics/tn_slope.json")
    args = ap.parse_args()

    m = hp.read_map(args.map_fits, verbose=False)
    mask = hp.read_map(args.mask_fits, verbose=False) if args.mask_fits else None
    nside_native = hp.get_nside(m)

    nsides = [int(s.strip()) for s in args.nsides.split(",") if s.strip()]
    nsides = sorted([n for n in nsides if n <= nside_native and n >= 8])
    if not nsides:
        raise SystemExit("No valid NSIDEs (must be >=8 and <= native).")

    pr_list, se_list, ln_n_list = [], [], []
    for nout in nsides:
        # Degrade map
        md = hp.ud_grade(m, nout, order_in="RING", order_out="RING", power=-2)
        mk = None
        if mask is not None:
            mk = degrade_mask(mask, nout, 0.5)
        lmax = args.lmax if args.lmax>0 else min(3*nout-1, 3*nout-1)
        pr, se = spectral_measures(md, mk, args.lmin, lmax)
        pr_list.append(pr); se_list.append(se); ln_n_list.append(np.log(nout))

    pr_arr = np.array(pr_list, float); se_arr = np.array(se_list, float); ln_n = np.array(ln_n_list, float)
    # Robust fit: ignore NaNs
    ok_pr = np.isfinite(pr_arr); ok_se = np.isfinite(se_arr)
    slope_ln_pr = float(np.polyfit(ln_n[ok_pr], np.log(pr_arr[ok_pr]), 1)[0]) if ok_pr.sum()>=2 else float("nan")
    slope_ln_se = float(np.polyfit(ln_n[ok_se], se_arr[ok_se], 1)[0]) if ok_se.sum()>=2 else float("nan")
    slope_log2_pr = slope_ln_pr / np.log(2.0) if np.isfinite(slope_ln_pr) else float("nan")
    slope_log2_se = slope_ln_se / np.log(2.0) if np.isfinite(slope_ln_se) else float("nan")

    
out = {
    "B": {
        "tn_slope_est": slope_ln_pr,
        "tn": {
            "nsides": nsides,
            "participation_ratio": [None if not np.isfinite(x) else float(x) for x in pr_arr],
            "spectral_entropy":   [None if not np.isfinite(x) else float(x) for x in se_arr],
            "slope_ln_PR": slope_ln_pr,
            "slope_ln_SE": slope_ln_se,
            "slope_log2_PR": slope_log2_pr,
            "slope_log2_SE": slope_log2_se,
            "lmin": args.lmin
        }
    },
    "notes": "TN slope defined as slope of log(PR) vs ln(NSIDE). SE slope also provided."
}
Path(args.out).parent.mkdir(parents=True, exist_ok=True)
Path(args.out).write_text(json.dumps(out, indent=2))
print("Wrote", args.out, "B.tn_slope_est=", out["B"]["tn_slope_est"])

if __name__ == "__main__":
    main()
