
    import numpy as np

import json, time, os, argparse, math, random
from pathlib import Path

def write_result(module, version, inputs, metrics, figures, diagnostics, outpath):
    out = {
        "module": module,
        "version": version,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "inputs": inputs,
        "metrics": metrics,
        "figures": figures,
        "diagnostics": diagnostics
    }
    Path(os.path.dirname(outpath)).mkdir(parents=True, exist_ok=True)
    open(outpath, "w").write(json.dumps(out, indent=2))
    print("Wrote", outpath)

import matplotlib.pyplot as plt

def save_simple_plot(x, y, title, out_png):
    plt.figure()
    plt.plot(x, y)
    plt.title(title)
    plt.xlabel("x")
    plt.ylabel("y")
    plt.tight_layout()
    plt.savefig(out_png, dpi=150)
    plt.close()

    import argparse

    def mock_lensing(seed:int, n:int=500):
        rng = np.random.default_rng(seed)
        # toy shear field
        g1 = rng.normal(0, 0.02, n)
        g2 = rng.normal(0, 0.02, n)
        e_t = float(np.sqrt((g1**2 + g2**2).mean()))
        # toy Einstein radius estimator
        theta_e = float(abs(rng.normal(1.2, 0.1)))
        return {"shear_rms": e_t, "einstein_radius_est": theta_e}

    def main():
        ap = argparse.ArgumentParser()
        ap.add_argument("--seed", type=int, default=123)
        ap.add_argument("--output_json", default="artifacts/lensing/result.json")
        ap.add_argument("--figure", default="figures/lensing_diagnostics.png")
        args = ap.parse_args()
        metrics = mock_lensing(args.seed)
        x = list(range(40))
        y = [np.log(i+1) for i in x]
        save_simple_plot(x, y, "Mock Lensing Diagnostic", args.figure)
        diagnostics = {"warnings": [], "notes": ["toy shear RMS + Einstein radius estimator"]}
        write_result("lensing_strong_weak", "2.0.0", {"seed":args.seed}, metrics, [args.figure], diagnostics, args.output_json)

    if __name__ == "__main__":
        main()
