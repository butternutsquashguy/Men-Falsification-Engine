#!/usr/bin/env python3
import argparse, json, numpy as np
from pathlib import Path

def tail_rate(x, k=3.0):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    x = x - x.mean()
    s = x.std() if x.std()>0 else 1.0
    z = x/s
    return float(np.mean(np.abs(z) > k))

def ib_edge_score(x, block=8):
    x = np.asarray(x, float)
    n = x.size
    m = int(np.sqrt(n))
    if m*m != n:
        m = int(np.floor(np.sqrt(n)))
        x = x[:m*m]
    x = x.reshape(m,m)
    H,W = x.shape
    h = H//block*block
    w = W//block*block
    x = x[:h,:w]
    var = float(x.var()+1e-12)
    xb = x.reshape(h//block, block, w//block, block).mean(axis=(1,3))
    xu = np.repeat(np.repeat(xb, block, axis=0), block, axis=1)
    err=float(((x-xu)**2).mean())
    return float(np.clip(1.0 - err/var, 0.0, 1.0))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--map", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--k", type=float, default=3.0)
    ap.add_argument("--block", type=int, default=8)
    a = ap.parse_args()
    arr = np.load(a.map) if a.map.endswith(".npy") else np.loadtxt(a.map)
    out = {"A":{"observed_tail_rate":tail_rate(arr,a.k)},"C":{"ib_edge_score":ib_edge_score(arr,a.block)}}
    Path(a.out).write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))
