
#!/usr/bin/env python3
"""
Pinned small fetch for MEN-OBS Phase4 real-slice.
Writes to data/.cache and prints the saved path.
"""
import argparse, sys
from pathlib import Path
from research_pipeline.utils import net

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--cache-dir", default="data/.cache")
    p.add_argument("--out", default="chime_frb_catalog.csv")
    args = p.parse_args()
    urls = [
        "https://www.chime-frb.ca/catalog/csv",
        "https://www.chime-frb.ca/catalog?format=csv",
        "https://raw.githubusercontent.com/chime-frb-open-data/chime-frb-open-data.github.io/master/docs/catalog/catalog1.csv"
    ]
    last = None
    for i,u in enumerate(urls):
        try:
            last = net.download_text(u, args.cache_dir, f"chime_frb_catalog_{i}.csv", max_age_s=7*86400)
            break
        except Exception:
            continue
    if last is None:
        raise SystemExit("Failed to fetch CHIME FRB CSV from all endpoints.")
    print(last)

if __name__ == "__main__":
    sys.exit(main() or 0)
