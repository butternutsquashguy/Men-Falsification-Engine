
    import numpy as np

import json, time, os, argparse
from pathlib import Path
def write_result(module, version, inputs, metrics, figures, diagnostics, outpath):
    out = {
        "module": module,
        "version": version,
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "inputs": inputs,
        "metrics": metrics,
        "figures": figures,
        "diagnostics": diagnostics
    }
    Path(os.path.dirname(outpath)).mkdir(parents=True, exist_ok=True)
    open(outpath, "w").write(json.dumps(out, indent=2))
    print("Wrote", outpath)

import matplotlib.pyplot as plt
def save_simple_plot(x, y, title, out_png, xlabel="x", ylabel="y"):
    plt.figure()
    plt.plot(x, y)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.tight_layout()
    plt.savefig(out_png, dpi=150)
    plt.close()

    from src.men_pbh.utils import log_uniform, simple_histogram

    def mock_evaporation(seed:int, n:int=5000):
        rng = np.random.default_rng(seed)
        masses = log_uniform(1e14, 1e18, n, rng)  # grams (toy range)
        lifetime = 1e-27 * masses**3  # tau ~ M^3 (toy normalization)
        # fraction evaporated within H0^-1 window (toy proxy)
        t_hubble = 4.3e17  # s
        frac = float(np.mean(lifetime < t_hubble))
        centers, counts = simple_histogram(np.log10(masses), bins=40)
        return {"frac_evaporated": frac, "hist_centers_log10M": centers, "hist_counts": counts}

    def main():
        import argparse
        ap = argparse.ArgumentParser()
        ap.add_argument("--seed", type=int, default=123)
        ap.add_argument("--output_json", default="artifacts/pbh_evaporation/result.json")
        ap.add_argument("--figure", default="figures/pbh_evaporation.png")
        args = ap.parse_args()
        metrics = mock_evaporation(args.seed)
        save_simple_plot(metrics["hist_centers_log10M"], metrics["hist_counts"],
                         "Toy PBH Mass Distribution", args.figure, xlabel="log10(M/g)", ylabel="counts")
        diagnostics = {"warnings": [], "notes": ["toy PBH evaporation fractions"]}
        write_result("pbh_evaporation", "3.0.0", {"seed":args.seed}, metrics, [args.figure], diagnostics, args.output_json)
    if __name__ == "__main__":
        main()
