#!/usr/bin/env python3
import argparse, json, math, sys
from pathlib import Path
import numpy as np

try:
    import healpy as hp
except Exception as e:
    raise SystemExit("healpy not available; install environment-astro.yml") from e

# ----------------- Helpers -----------------
def read_map_with_header(path):
    try:
        m, hdr = hp.read_map(str(path), h=True, verbose=False)
        hdr = dict(hdr)
    except TypeError:
        m, hdr_list = hp.read_map(str(path), h=True, verbose=False)
        hdr = {k:v for (k,v) in hdr_list if isinstance(k, str)}
    nside = hp.get_nside(m)
    return np.asarray(m, float), int(nside), (hdr or {})

def read_mask(path, target_nside):
    mask = hp.read_map(str(path), verbose=False)
    if hp.get_nside(mask) != target_nside:
        mask = hp.ud_grade(mask, target_nside, pess=False, power=-2)
    return np.asarray(mask, float)

def pixel_sz(nside): return (4.0*np.pi/hp.nside2npix(nside))**0.5

def reorder_if_needed(arr, ordering_in, force_ordering):
    if not force_ordering or force_ordering.upper() == "NONE":
        return arr, ordering_in
    # hp.reorder needs nest flags: True if NEST, False if RING
    in_nest = (ordering_in.upper() == "NEST")
    out_nest = (force_ordering.upper() == "NEST")
    if in_nest == out_nest:
        return arr, ordering_in
    return hp.reorder(arr, n2r=out_nest==False, r2n=out_nest==True), force_ordering

def resolve_ordering(header, cli_ordering_in):
    if cli_ordering_in and cli_ordering_in.upper() in ("RING","NEST"):
        return cli_ordering_in.upper(), "cli"
    ord_hdr = None
    for k in ("ORDERING","ORDER","ORDERED"):
        if k in header:
            v = str(header[k]).strip().upper()
            if v in ("RING","NEST"):
                ord_hdr = v; break
    return (ord_hdr or "RING"), ("header" if ord_hdr else "default")

def resolve_frame(header):
    # Map common header keys to GAL/ECL/EQU (galactic/ecliptic/equatorial)
    raw = None
    for k in ("COORDSYS","COORD","FRAME"):
        if k in header:
            raw = str(header[k]).strip().upper()
            break
    if raw in ("G","GAL","GALACTIC"): return "GAL"
    if raw in ("E","ECL","ECLIPTIC"): return "ECL"
    if raw in ("C","EQU","CEL","CELESTIAL","ICRS","J2000"): return "EQU"
    return None

def rotate_map_interp(m, from_frame, to_frame):
    if from_frame == to_frame:
        return m
    # Build rotator and interpolate back to the HEALPix grid
    nside = hp.get_nside(m)
    npix = m.size
    theta, phi = hp.pix2ang(nside, np.arange(npix))
    # Rotator expects code like 'GC', 'GE', 'CE' etc. We'll compose from GAL/ECL/EQU -> 'G','E','C'
    code = {'GAL':'G','ECL':'E','EQU':'C'}
    rot = hp.Rotator(coord=[code[from_frame], code[to_frame]])
    th2, ph2 = rot(theta, phi)
    val = hp.get_interp_val(m, th2, ph2)
    return np.asarray(val, float)

def gaussian_apodize(mask, fwhm_arcmin):
    if fwhm_arcmin <= 0: return mask
    fwhm_rad = (fwhm_arcmin/60.0) * np.pi/180.0
    sm = hp.smoothing(mask, fwhm=fwhm_rad, iter=0, verbose=False)
    return np.clip(sm, 0.0, 1.0)

def cosine_apodize(mask, radius_arcmin, thresh=0.5):
    if radius_arcmin <= 0: return (mask>thresh).astype(float)
    nside = hp.get_nside(mask); pix = pixel_sz(nside); R = (radius_arcmin/60.0)*np.pi/180.0
    hard = (mask>thresh).astype(np.int8); npix = hard.size
    from collections import deque
    dist = np.full(npix, -1, dtype=np.int32); q = deque()
    outside = np.where(hard==0)[0]
    for p in outside: dist[p]=0; q.append(p)
    while q:
        p = q.popleft(); neigh = hp.get_all_neighbours(nside, p)
        for nb in neigh:
            if nb<0: continue
            if dist[nb]==-1: dist[nb]=dist[p]+1; q.append(nb)
    dang = dist * pix
    s = np.clip(dang / R, 0.0, 1.0); w = 0.5*(1.0 - np.cos(np.pi*s))
    w[hard==0]=0.0; w[dang>=R]=1.0
    return np.asarray(w, float)

def apply_mask(m, mask, t=1e-3): return np.where(mask>t, m, np.nan)

def frac_tail_rate(x, k=3.0):
    x = np.asarray(x, float); good = np.isfinite(x)
    if good.sum()==0: return float('nan')
    x = x[good]; x = x - np.nanmean(x); s = np.nanstd(x); s = s if s>0 else 1.0
    z = x/s; return float(np.mean(np.abs(z)>k))

def hemispherical_variance_asymmetry(x, nside_scan=4):
    x = np.asarray(x, float); good = np.isfinite(x)
    if good.sum()==0: return float('nan'), (np.nan,np.nan,np.nan)
    nside = hp.get_nside(x)
    vecs = hp.pix2vec(nside_scan, np.arange(hp.nside2npix(nside_scan)))
    pixvecs = np.vstack(hp.pix2vec(nside, np.arange(x.size))).T; mask_good = good.astype(bool)
    def hemi_mask(dv): d = pixvecs @ dv; return d>=0
    vmax=-1.0; best=None
    for dv in np.vstack(vecs).T:
        h1 = hemi_mask(dv) & mask_good; h2=(~h1) & mask_good
        if h1.sum()<10 or h2.sum()<10: continue
        v1 = np.nanvar(x[h1]); v2 = np.nanvar(x[h2])
        if (v1+v2)<=0: continue
        frac = abs(v1-v2)/(v1+v2)
        if frac>vmax: vmax=frac; best = dv/np.linalg.norm(dv)
    return float(vmax), tuple(best) if best is not None else (np.nan,np.nan,np.nan)

def local_variance_map(m, mask, fwhm_deg=20.0):
    fwhm_rad = np.deg2rad(fwhm_deg); w = np.asarray(mask, float)
    m0 = np.nan_to_num(m)*w; w_s = hp.smoothing(w, fwhm=fwhm_rad, iter=0, verbose=False)
    m_s = hp.smoothing(m0, fwhm=fwhm_rad, iter=0, verbose=False); m2_s = hp.smoothing(m0**2, fwhm=fwhm_rad, iter=0, verbose=False)
    with np.errstate(divide='ignore', invalid='ignore'):
        mu = np.where(w_s>1e-6, m_s/w_s, np.nan); mu2 = np.where(w_s>1e-6, m2_s/w_s, np.nan); var = mu2 - mu**2
    return var

def dipole_fit_field(field, mask):
    good = np.isfinite(field) & (mask>1e-3)
    if good.sum()<100: return float('nan'), (np.nan, np.nan)
    nside = hp.get_nside(field); vx,vy,vz = hp.pix2vec(nside, np.arange(field.size))
    X = np.vstack([np.ones(good.sum()), vx[good], vy[good], vz[good]]).T; y = field[good]
    beta, *_ = np.linalg.lstsq(X, y, rcond=None); c,bx,by,bz = beta
    b = (bx*bx+by*by+bz*bz)**0.5; A = float(b / max(abs(c),1e-12))
    lon = (np.degrees(np.arctan2(by,bx))+360.0)%360.0; lat = np.degrees(np.arctan2(bz, (bx*0+by*0+1e-12)))
    # Use arcsin safely for lat:
    lat = np.degrees(np.arcsin(np.clip(bz/(b+1e-12), -1.0, 1.0)))
    return A, (float(lon), float(lat))

def pseudo_cl_correct(cl, mask, method):
    if method == "none": return cl
    w = np.asarray(mask, float)
    f_sky = np.mean(w>1e-3)
    if method == "fsimple":
        corr = max(f_sky, 1e-6)
        return cl / corr
    if method == "w2":
        f2 = np.mean(w**2)
        corr = max(f2, 1e-6)
        return cl / corr
    return cl  # fallback

def power_asymmetry_lowl(m, mask, axis_vec, lmin=2, lmax=30, pseudo_corr="none"):
    nside = hp.get_nside(m); vx,vy,vz = hp.pix2vec(nside, np.arange(m.size))
    pixvecs = np.vstack([vx,vy,vz]).T; d = pixvecs @ np.asarray(axis_vec)
    hemi1 = d>=0; hemi2 = ~hemi1; mm = np.where(mask>1e-3, m, 0.0)
    m1 = np.where(hemi1, mm, 0.0); m2 = np.where(hemi2, mm, 0.0)
    mask1 = np.where(hemi1, mask, 0.0); mask2 = np.where(hemi2, mask, 0.0)
    cl1 = hp.anafast(m1, lmax=lmax); cl2 = hp.anafast(m2, lmax=lmax)
    if pseudo_corr != "none":
        cl1 = pseudo_cl_correct(cl1, mask1, pseudo_corr)
        cl2 = pseudo_cl_correct(cl2, mask2, pseudo_corr)
    l = np.arange(cl1.size); band = (l>=lmin) & (l<=lmax)
    S1 = float(np.sum(cl1[band]*(2*l[band]+1))); S2 = float(np.sum(cl2[band]*(2*l[band]+1)))
    if (S1+S2)<=0: return float('nan')
    return float(abs(S1-S2)/(S1+S2))

def udgrade_if_needed(arr, current_nside, target_nside):
    if target_nside and int(target_nside) > 0 and int(target_nside) != int(current_nside):
        return hp.ud_grade(arr, int(target_nside), pess=False, power=-2), int(target_nside)
    return arr, current_nside

# ----------------- Main -----------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--map-fits", required=True); ap.add_argument("--mask-fits")
    ap.add_argument("--nside-target", type=int, default=0, help="ud_grade map/mask to this NSIDE before metrics (0=keep)")
    ap.add_argument("--beam-fwhm-arcmin", type=float, default=0.0, help="optional Gaussian smoothing of map")
    ap.add_argument("--mask-threshold", type=float, default=0.5)

    ap.add_argument("--ordering-in", choices=["auto","RING","NEST"], default="auto", help="Assumed input ordering (auto uses FITS header or RING)")
    ap.add_argument("--force-ordering", choices=["NONE","RING","NEST"], default="NONE", help="Reorder map/mask to this before analysis")
    ap.add_argument("--rotate-from", choices=["auto","GAL","ECL","EQU"], default="auto", help="Frame to assume if header missing")
    ap.add_argument("--rotate-to", choices=["NONE","GAL","ECL","EQU"], default="NONE", help="Rotate map/mask to this frame before analysis")

    ap.add_argument("--apodize-mode", choices=["gaussian","cosine","none"], default="gaussian")
    ap.add_argument("--apodize-fwhm-arcmin", type=float, default=20.0)
    ap.add_argument("--apodize-radius-arcmin", type=float, default=60.0)

    ap.add_argument("--k", type=float, default=3.0)
    ap.add_argument("--hemi-nside", type=int, default=4)
    ap.add_argument("--edge-factor", type=int, default=4)
    ap.add_argument("--var-fwhm-deg", type=float, default=20.0)
    ap.add_argument("--lmin", type=int, default=2); ap.add_argument("--lmax", type=int, default=30)
    ap.add_argument("--pseudo-cl-correct", choices=["none","fsimple","w2"], default="none", help="Approx. pseudo-C_ell correction (fsimple=f_sky, w2=mean mask^2)")

    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    m, nside, hdr = read_map_with_header(args.map_fits)
    header_ordering, ordering_src = resolve_ordering(hdr, args.ordering_in)
    map_ordering_used = header_ordering

    # Read + align mask
    if args.mask_fits:
        mask = read_mask(args.mask_fits, nside)
    else:
        mask = np.ones_like(m, float)

    # Beam smoothing
    if args.beam_fwhm_arcmin > 0:
        fwhm_rad = (args.beam_fwhm_arcmin/60.0)*np.pi/180.0
        m = hp.smoothing(m, fwhm=fwhm_rad, iter=0, verbose=False)

    # Thresholding before apodization
    mask = (mask > args.mask_threshold).astype(float)

    # Reorder if requested
    m, map_ordering_used = reorder_if_needed(m, header_ordering, args.force_ordering)
    mask, _ = reorder_if_needed(mask, header_ordering, args.force_ordering)

    # Frame rotation (optional)
    frame_hdr = resolve_frame(hdr)
    frame_in = (frame_hdr or (args.rotate_from if args.rotate_from != "auto" else "GAL"))
    frame_out = args.rotate_to
    if frame_out != "NONE":
        # Rotate both map and mask via interpolation
        m = rotate_map_interp(m, frame_in, frame_out)
        mask = rotate_map_interp(mask, frame_in, frame_out)

    # Apodize
    if args.apodize_mode=="gaussian":
        mask_apo = gaussian_apodize(mask, args.apodize_fwhm_arcmin)
    elif args.apodize_mode=="cosine":
        mask_apo = cosine_apodize(mask, args.apodize_radius_arcmin, thresh=args.mask_threshold)
    else:
        mask_apo = mask.astype(float)

    # nside target
    m, nside = udgrade_if_needed(m, nside, args.nside_target)
    mask_apo, _ = udgrade_if_needed(mask_apo, hp.get_nside(mask_apo), nside)

    # Mask and metrics
    m_masked = apply_mask(m, mask_apo)

    A_tail = frac_tail_rate(m_masked, k=args.k)
    A_hemi, best_dir = hemispherical_variance_asymmetry(m_masked, nside_scan=args.hemi_nside)
    C_edge = ib_edge_score_udgrade(m_masked, factor=args.edge_factor)

    var_map = local_variance_map(m_masked, mask_apo, fwhm_deg=args.var_fwhm_deg)
    mod_amp, (mod_lon, mod_lat) = dipole_fit_field(var_map, mask_apo)

    C_lowell = power_asymmetry_lowl(m_masked, mask_apo, best_dir, lmin=args.lmin, lmax=args.lmax, pseudo_corr=args.pseudo_cl_correct) if not np.isnan(best_dir[0]) else float('nan')

    # QC
    good = np.isfinite(m_masked)
    qc = {
        "mean": float(np.nanmean(m_masked[good])) if np.any(good) else float('nan'),
        "std": float(np.nanstd(m_masked[good])) if np.any(good) else float('nan'),
        "frac_nan": float(np.mean(~good)),
        "f_sky": float(np.mean(mask_apo > 1e-3)),
        "used_l_band": [int(args.lmin), int(args.lmax)],
        "input_header": {k: str(v) for k,v in (hdr or {}).items() if k in ("NSIDE","ORDERING","COORDSYS","FRAME")},
        "ordering_source": ordering_src,
        "ordering_used": map_ordering_used,
        "frame_in": frame_in,
        "frame_out": frame_out
    }

    out = {
        "meta": {
            "nside": int(nside),
            "apodize_mode": args.apodize_mode,
            "apodize_fwhm_arcmin": float(args.apodize_fwhm_arcmin),
            "apodize_radius_arcmin": float(args.apodize_radius_arcmin),
            "var_fwhm_deg": float(args.var_fwhm_deg),
            "nside_target": int(args.nside_target),
            "beam_fwhm_arcmin": float(args.beam_fwhm_arcmin),
            "mask_threshold": float(args.mask_threshold),
            "qc": qc
        },
        "A":{"observed_tail_rate": float(A_tail), "hemi_variance_asym": float(A_hemi), "tail_max": 0.003, "tail_k_sigma": float(args.k)},
        "C":{"ib_edge_score": float(C_edge), "min_edge": 0.55, "lowell_power_asym": float(C_lowell)},
        "dipole_modulation":{"amplitude": float(mod_amp),
                              "direction_gal": {"lon_deg": float(mod_lon), "lat_deg": float(mod_lat)}}
    }
    Path(args.out).write_text(json.dumps(out, indent=2))
    print(json.dumps(out, indent=2))

def ib_edge_score_udgrade(x, factor=4):
    nside = hp.get_nside(x); nside_low = max(1, nside//factor)
    x_low = hp.ud_grade(x, nside_low, pess=False, power=-2)
    x_up  = hp.ud_grade(x_low, nside, pess=False, power=-2)
    good = np.isfinite(x); num = np.nanmean((x[good]-x_up[good])**2); den = np.nanvar(x[good])+1e-12
    rel = num/den; return float(np.clip(1.0 - rel, 0.0, 1.0))

if __name__ == "__main__":
    main()
