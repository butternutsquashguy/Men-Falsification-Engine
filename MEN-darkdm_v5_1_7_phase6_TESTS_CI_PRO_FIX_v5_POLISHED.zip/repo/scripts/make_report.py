#!/usr/bin/env python3
import argparse, json, os, base64, io
from pathlib import Path

def b64png_from_series(series, title, xlabel, ylabel):
    import matplotlib.pyplot as plt
    import numpy as np
    fig = plt.figure()
    x = np.asarray(series, float)
    plt.hist(x, bins=30)
    plt.title(title); plt.xlabel(xlabel); plt.ylabel(ylabel)
    bio = io.BytesIO(); fig.savefig(bio, format="png", bbox_inches="tight"); plt.close(fig)
    return "data:image/png;base64," + base64.b64encode(bio.getvalue()).decode("ascii")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--metrics", required=True)
    ap.add_argument("--cal", required=False)
    ap.add_argument("--runs-dir", default="runs")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    obs = json.loads(Path(args.metrics).read_text())
    pvals = {}
    if args.cal and Path(args.cal).exists():
        pvals = json.loads(Path(args.cal).read_text())
    Path(args.out).mkdir(parents=True, exist_ok=True)

    imgs = {}
    npz_guess = Path("calibration/null_suite.npz")
    if npz_guess.exists():
        import numpy as np
        cal = np.load(npz_guess)
        imgs["A_tail"] = b64png_from_series(cal["A_tail"], "Null A_tail", "A_tail", "count")
        imgs["C_lowell"] = b64png_from_series(cal["C_lowell"], "Null C_lowell", "C_lowell", "count")
        imgs["mod_amp"] = b64png_from_series(cal["mod_amp"], "Null modulation amplitude", "amp", "count")

    style = "body{{font-family:system-ui, -apple-system, Segoe UI, Roboto, Arial; margin:24px;}} .card{{border:1px solid #ddd;border-radius:12px;padding:16px;margin-bottom:16px;}}"
    html = "<!doctype html><html><head><meta charset='utf-8'><title>MEN v5 Report</title><style>"+style+"</style></head><body>"
    html += "<h1>MEN v5 Report</h1>"
    html += "<div class='card'><h2>Observed metrics</h2><pre>"+json.dumps(obs, indent=2)+"</pre></div>"
    html += "<div class='card'><h2>Calibration p-values</h2><pre>"+json.dumps(pvals, indent=2)+"</pre></div>"
    html += "<div class='card'><h2>Null histograms</h2>"
    for k,v in imgs.items():
        html += "<h3>"+k+"</h3><img src='"+v+"' style='max-width:480px;'/>"
    html += "</div></body></html>"
    (Path(args.out)/"index.html").write_text(html)
    print("Wrote", Path(args.out)/"index.html")

if __name__ == "__main__":
    main()
