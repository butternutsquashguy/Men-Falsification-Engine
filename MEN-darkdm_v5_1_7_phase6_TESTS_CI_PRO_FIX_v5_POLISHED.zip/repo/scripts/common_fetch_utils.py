#!/usr/bin/env python3
import time, hashlib, requests
from pathlib import Path
def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1<<20), b""):
            h.update(chunk)
    return h.hexdigest()
def stream_download(url, out_path, chunk=1<<20, max_retries=5, timeout=60):
    out = Path(out_path); out.parent.mkdir(parents=True, exist_ok=True)
    attempt = 0
    while attempt < max_retries:
        try:
            with requests.get(url, stream=True, timeout=timeout) as r:
                r.raise_for_status()
                with open(out, "wb") as f:
                    for chunk_bytes in r.iter_content(chunk_size=chunk):
                        if chunk_bytes: f.write(chunk_bytes)
            return str(out), int(r.headers.get("Content-Length", "0") or 0)
        except Exception:
            attempt += 1
            if attempt >= max_retries: raise
            time.sleep(2*attempt)
