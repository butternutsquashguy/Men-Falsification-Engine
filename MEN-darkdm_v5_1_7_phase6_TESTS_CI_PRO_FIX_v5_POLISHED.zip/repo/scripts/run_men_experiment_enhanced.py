#!/usr/bin/env python3
import argparse, json, itertools, os, sys, yaml, time, importlib, csv
from pathlib import Path
PLUGINS=["dbbh","qds"]
def _ensure_dir(p: Path): p.mkdir(parents=True, exist_ok=True)
def _log(fp, msg):
    ts=time.strftime("%Y-%m-%d %H:%M:%S"); fp.write(f"[{ts}] {msg}\n"); fp.flush()
def _load_json(path):
    try: return json.loads(Path(path).read_text())
    except Exception: return {}
def _load_plugins():
    loaded={}
    for nm in PLUGINS:
        try:
            mod=importlib.import_module(f"plugins.{nm}"); loaded[nm]=mod
        except Exception as e:
            print(f"WARN: failed to load plugin {nm}: {e}")
    return loaded
def _enumerate_all_jobs(priors, mode, loaded):
    jobs=[]
    for nm,mod in loaded.items():
        if hasattr(mod, "enumerate_jobs"): jobs.extend(mod.enumerate_jobs(priors, mode))
    return jobs
def _evaluate_job(job, loaded):
    modname=job["module"]; params=job["params"]; seeds=params.get("seed",[123])
    grid={k:(v if isinstance(v,list) else [v]) for k,v in params.items() if k!="seed"}
    keys=list(grid.keys()); rows=[]
    for combo in itertools.product(*[grid[k] for k in keys]):
        p=dict(zip(keys, combo))
        for s in seeds:
            flat={f"param.{k}":v for k,v in p.items()}; flat["param.seed"]=s; flat["module"]=modname
            obs={}
            try:
                mod=loaded.get(modname)
                if mod and hasattr(mod,"evaluate"): obs=mod.evaluate(p, s) or {}
            except Exception as e:
                obs={"error":str(e)}
            rows.append({**flat, **obs})
    return rows
def _evaluate_constraints(rows, priors, metrics, strict=False):
    Amax=(metrics.get("A",{}) or {}).get("tail_max")
    Cmin=(metrics.get("C",{}) or {}).get("min_edge")
    Bslope_pref=(metrics.get("B",{}) or {}).get("slope_pref") or (priors.get("modules",{}).get("tensor_network",{}) or {}).get("entropy_vs_logD_slope_preferred")
    tol=(metrics.get("B",{}) or {}).get("tolerance",0.05)
    if Amax is None: Amax=(priors.get("modules",{}).get("random_matrix",{}) or {}).get("max_outlier_rate_n_le_1600",0.003)
    if Cmin is None: Cmin=0.55
    if Bslope_pref is None: Bslope_pref=0.98
    if strict:
        miss=[]
        if "A" not in metrics or "observed_tail_rate" not in metrics["A"]: miss.append("A.observed_tail_rate")
        if "C" not in metrics or "ib_edge_score" not in metrics["C"]: miss.append("C.ib_edge_score")
        if miss: raise SystemExit("Strict metrics mode: missing "+", ".join(miss))
    out=[]
    for r in rows:
        failed=[]
        obs_tail=metrics.get("A",{}).get("observed_tail_rate")
        if obs_tail is not None and obs_tail>Amax: failed.append("A")
        if "B" in metrics and "tn_slope_est" in metrics["B"]:
            if abs(metrics["B"]["tn_slope_est"]-Bslope_pref)>tol: failed.append("B")
        ib_edge=metrics.get("C",{}).get("ib_edge_score")
        if ib_edge is not None and ib_edge<Cmin: failed.append("C")
        rr=dict(r); rr["passes_constraints"]=len(failed)==0
        if failed: rr["failed_constraints"]=failed
        out.append(rr)
    summary={"A":{"max_tail":Amax},"B":{"tn_slope_pref":Bslope_pref,"tolerance":tol},"C":{"min_ib_edge":Cmin}}
    return out, summary
def _weighted_prune(rows_with_flags, priors, topk=5):
    def score(r): return 1.0*(r.get("passes_constraints")) - 0.2*len(r.get("failed_constraints",[]))
    passing=[r for r in rows_with_flags if r.get("passes_constraints")]
    import time as _t
    if not passing:
        return {"experiment_id":f"next_from_constraints_{int(_t.time())}","output_dir":f"runs/next_from_constraints_{int(_t.time())}",
                "jobs":[{"name":"dbbh_nudge","module":"dbbh","params":{"N":[12,20],"Lambda_conf":[2.0,3.0],"mq":[0.5],"T_dark":[0.3,0.5],"kappa":[3.5,4.0],"seed":[123,456]}},
                        {"name":"qds_nudge","module":"qds","params":{"w":[-0.9,-0.85],"T_end":[1e8,3e8],"m_dm":[1e3,1e5],"seed":[123,456]}}]}
    passing=sorted(passing, key=lambda r:-score(r))[:topk]
    def around(vals):
        vals=sorted(set(float(v) for v in vals))
        return vals if len(vals)<=3 else [vals[0], vals[len(vals)//2], vals[-1]]
    def get(r,k): return r.get(f"param.{k}")
    Ns=[get(r,"N") for r in passing if get(r,"N") is not None]
    Ls=[get(r,"Lambda_conf") for r in passing if get(r,"Lambda_conf") is not None]
    mqs=[get(r,"mq") for r in passing if get(r,"mq") is not None]
    Ts=[get(r,"T_dark") for r in passing if get(r,"T_dark") is not None]
    ks=[get(r,"kappa") for r in passing if get(r,"kappa") is not None]
    ws=[get(r,"w") for r in passing if get(r,"w") is not None]
    Te=[get(r,"T_end") for r in passing if get(r,"T_end") is not None]
    md=[get(r,"m_dm") for r in passing if get(r,"m_dm") is not None]
    import time as _tt
    exp2={"experiment_id":f"next_from_constraints_{int(_tt.time())}","output_dir":f"runs/next_from_constraints_{int(_tt.time())}","jobs":[]}
    if any([Ns,Ls,mqs,Ts,ks]):
        exp2["jobs"].append({"name":"dbbh_refine","module":"dbbh","params":{"N":around(Ns) or [12,20,30],"Lambda_conf":around(Ls) or [3.0,5.0],
                                                                             "mq":around(mqs) or [0.5,1.0],"T_dark":around(Ts) or [0.3,0.8],
                                                                             "kappa":around(ks) or [3.0,3.5],"seed":[123,456]}})
    if any([ws,Te,md]):
        exp2["jobs"].append({"name":"qds_refine","module":"qds","params":{"w":around(ws) or [-0.9,-0.8,-0.7],
                                                                          "T_end":around(Te) or [1e8,1e9],
                                                                          "m_dm":around(md) or [1e3,1e5,1e10],
                                                                          "seed":[123,456]}})
    return exp2
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--from-priors")
    ap.add_argument("--grid", choices=["preferred","wide"], default="preferred")
    ap.add_argument("--metrics")
    ap.add_argument("--strict-metrics", action="store_true")
    ap.add_argument("--auto-next", action="store_true")
    args = ap.parse_args()
    pri = _load_json(args.from_priors) if args.from_priors else {}
    loaded = _load_plugins()
    exp = {"experiment_id": f"dark_dm_from_priors_{args.grid}", "output_dir": f"runs/dark_dm_from_priors_{args.grid}",
           "jobs": _enumerate_all_jobs(pri, args.grid, loaded)}
    outdir = Path(exp["output_dir"]); _ensure_dir(outdir)
    logfp = open(outdir/"run.log","a"); _log(logfp, f"Start exp_id={exp['experiment_id']} grid={args.grid}")
    metrics = _load_json(args.metrics) if args.metrics else {}
    if args.strict_metrics:
        if not metrics or "A" not in metrics or "C" not in metrics:
            _log(logfp, "Strict metrics failed: A/C missing"); sys.exit(2)
    rows=[]
    for job in exp["jobs"]:
        rows.extend(_evaluate_job(job, loaded))
    (outdir/"_batch_summary.json").write_text(json.dumps({"experiment":exp["experiment_id"],"results_count":len(rows)}, indent=2))
    rows_with_flags, csum = _evaluate_constraints(rows, pri, metrics or {}, strict=args.strict_metrics)
    (outdir/"_rows_with_flags.json").write_text(json.dumps(rows_with_flags, indent=2))
    (outdir/"_constraint_eval.json").write_text(json.dumps(csum, indent=2))
    with open(outdir/"_rows_with_flags.csv","w",newline="") as f:
        writer = csv.DictWriter(f, fieldnames=sorted({k for r in rows_with_flags for k in r.keys()}))
        writer.writeheader(); writer.writerows(rows_with_flags)
    if args.auto-next:
        exp2=_weighted_prune(rows_with_flags, pri)
        (outdir/"_suggest_next_experiment.yaml").write_text(yaml.safe_dump(exp2, sort_keys=False))
        (outdir/"_suggest_next_experiment.json").write_text(json.dumps(exp2, indent=2))
        _log(logfp, "Wrote next-experiment suggestions.")
    _log(logfp, "Done."); logfp.close()
if __name__ == "__main__": main()
